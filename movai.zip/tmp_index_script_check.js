
    const dashboard = {};
    const STAGES = [
      { key: 'Source_Ingester', label: '数据采集', en: 'Data Ingest' },
      { key: 'Director_Engine', label: '世界观导演', en: 'Director Engine' },
      { key: 'Writer_Engine', label: '分镜编剧', en: 'Writer Engine' },
      { key: 'Audio_Anchor_Forge', label: '音频锚点', en: 'Audio Anchor' },
      { key: 'Visual_Asset_Foundry', label: '视觉资产', en: 'Visual Foundry' },
      { key: 'Render_Engine', label: '2.5D 渲染', en: '2.5D Render' },
      { key: 'Global_Distributor', label: '全球分发', en: 'Global Distributor' },
      { key: 'Master_Hub', label: '总控台', en: 'Master Hub' }
    ];

    const currentStage = dashboard.current_stage || dashboard.manifest?.current_stage || 'Source_Ingester';
    const currentStageIndex = Math.max(0, STAGES.findIndex((stage) => stage.key === currentStage));
    const outline = dashboard.documents?.raw_outline || { volumes: [] };
    const sourceProgress = dashboard.documents?.source_progress || { processed_story_uids: [], story_episode_map: {} };
    const processedStorySet = new Set(sourceProgress.processed_story_uids || []);
    const processedEpisodeMap = sourceProgress.story_episode_map || {};
    const hasRawSource = Boolean(dashboard.documents?.raw_source);
    const hasValidText = Boolean((dashboard.documents?.raw_source?.source_partitions || []).some((partition) =>
      (partition.text_chunks || []).some((chunk) => String(chunk.text || '').trim().length > 0)
    ));
    const stage1Ready = hasValidText && outline.volumes.length > 0;
    const effectiveStageIndex = currentStageIndex > 0 && !stage1Ready ? 0 : currentStageIndex;
    const effectiveStage = STAGES[effectiveStageIndex]?.key || 'Source_Ingester';

    let rawSourceData = JSON.parse(JSON.stringify(dashboard.documents?.raw_source || {}));
    let selectedVolumeId = '';
    let selectedStoryUid = '';
    let selectedSubstoryUid = '';
    let selectedStoryUids = new Set();
    let expandedVolumes = new Set();
    let logOpen = true;
    let logDetailOpen = false;

    function el(id) {
      return document.getElementById(id);
    }

    function escapeHtml(value) {
      return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('\"', '&quot;')
        .replaceAll("'", '&#39;');
    }

    function escapeTextarea(value) {
      return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;');
    }

    function readControls() {
      const value = (el('source-uri')?.value || '').trim();
      const isUrl = /^https?:\/\//i.test(value);
      return {
        project_id: dashboard.project_id || 'default',
        episode_id: dashboard.episode_id || 'EP_01',
        run_id: dashboard.run_id || 'web_ui',
        source_uri: isUrl ? value : '',
        source_keywords: isUrl ? '' : value,
        source_type_hint: isUrl ? 'web_url' : undefined,
        chapter_range: dashboard.chapter_range || '',
        style_label: dashboard.style_label || '',
        visual_lut: dashboard.visual_lut || '',
        narrator_voice_id: dashboard.narrator_voice_id || '',
        execution_mode: dashboard.execution_mode || 'local'
      };
    }

    async function fetchJson(url, options = {}) {
      const response = await fetch(url, options);
      let payload = {};
      try {
        payload = await response.json();
      } catch {
        payload = {};
      }
      if (!response.ok) {
        throw new Error(payload.detail || payload.message || response.statusText || 'Request failed');
      }
      return payload;
    }

    function buildTrack() {
      const root = el('track-stages');
      if (!root) return;
      root.innerHTML = STAGES.map((stage, index) => {
        const active = index === effectiveStageIndex;
        const complete = index < effectiveStageIndex;
        const clickable = index <= effectiveStageIndex;
        const classes = ['track-stage'];
        if (active) classes.push('active');
        if (complete) classes.push('complete');
        if (clickable) classes.push('clickable');
        return `
          <button class="${classes.join(' ')}" type="button" data-stage="${escapeHtml(stage.key)}" ${clickable ? '' : 'disabled'}>
            <span class="track-icon ${active ? 'pulse' : ''}"></span>
            <div class="track-labels" style="text-align:center;">
              <div class="track-label">${escapeHtml(stage.label)}</div>
              <div class="preview-meta" style="font-size:12px;">${escapeHtml(stage.en)}</div>
            </div>
          </button>`;
      }).join('');
      root.querySelectorAll('[data-stage]').forEach((btn) => {
        btn.addEventListener('click', () => scrollToStage(btn.dataset.stage));
      });
    }

    function stageSectionId(stageKey) {
      return {
        Source_Ingester: 'stage1-view',
        Director_Engine: 'stage2-view',
        Writer_Engine: 'section-writer',
        Audio_Anchor_Forge: 'section-audio',
        Visual_Asset_Foundry: 'section-visual',
        Render_Engine: 'section-render',
        Global_Distributor: 'section-global',
        Master_Hub: 'section-master',
      }[stageKey] || 'stage1-view';
    }

    function scrollToStage(stageKey) {
      const index = STAGES.findIndex((stage) => stage.key === stageKey);
      if (index < 0 || index > currentStageIndex) return;
      const target = document.getElementById(stageSectionId(stageKey));
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }

    function ensureDefaultSelection() {
      if (outline.volumes.length > 0 && !selectedVolumeId) {
        const firstVolume = outline.volumes[0];
        selectedVolumeId = firstVolume.partition_id;
        expandedVolumes.add(firstVolume.partition_id);
        const firstStory = (firstVolume.stories || []).find((story) => !processedStorySet.has(story.story_uid)) || (firstVolume.stories || [])[0];
        if (firstStory) {
          selectedStoryUid = firstStory.story_uid;
          selectedStoryUids.add(firstStory.story_uid);
        }
      }
    }

    function renderTree() {
      const root = el('chapter-tree');
      if (!root) return;
      ensureDefaultSelection();

      if (!outline.volumes.length) {
        root.innerHTML = `
          <div class="tree-empty">
            <strong>等待素材进入</strong>
            <p>采集完成后，这里会自动生成“卷 / 故事 / 片段”多级目录。</p>
          </div>`;
        return;
      }

      root.innerHTML = outline.volumes.map((volume) => {
        const expanded = expandedVolumes.has(volume.partition_id);
        const volumeSelected = selectedVolumeId === volume.partition_id;
        const storiesHtml = (volume.stories || []).map((story) => {
          const checked = selectedStoryUids.has(story.story_uid);
          const done = processedStorySet.has(story.story_uid);
          const episode = processedEpisodeMap[story.story_uid] || '';
          const substoriesHtml = (story.substories || []).map((sub) => `
            <button class="tree-node tree-substory ${selectedSubstoryUid === sub.substory_uid ? 'selected' : ''}" type="button" data-substory="${escapeHtml(sub.substory_uid)}" data-story="${escapeHtml(story.story_uid)}" data-volume="${escapeHtml(volume.partition_id)}">
              <span class="tree-checkbox ${selectedSubstoryUid === sub.substory_uid ? 'checked' : ''}"></span>
              <span class="tree-copy"><strong>${escapeHtml(sub.label)}</strong><small>${escapeHtml(sub.chunk_id || '')}</small></span>
            </button>`).join('');

          return `
            <button class="tree-node tree-story ${selectedStoryUid === story.story_uid ? 'selected' : ''}" type="button" data-story="${escapeHtml(story.story_uid)}" data-volume="${escapeHtml(volume.partition_id)}">
              <span class="tree-checkbox ${checked ? 'checked' : ''}"></span>
              <span class="tree-copy"><strong>${escapeHtml(story.label)}${done ? ` <span class="story-done">已处理${episode ? ` · ${escapeHtml(episode)}` : ''}</span>` : ''}</strong><small>${story.chunk_count} 片段</small></span>
            </button>
            ${expanded ? `<div class="tree-children">${substoriesHtml}</div>` : ''}`;
        }).join('');

        return `
          <div class="tree-group">
            <button class="tree-node ${volumeSelected ? 'selected' : ''}" type="button" data-volume="${escapeHtml(volume.partition_id)}">
              <span class="tree-checkbox ${expanded ? 'checked' : ''}"></span>
              <span class="tree-copy"><strong>${escapeHtml(volume.label)}</strong><small>${volume.chunk_count} 段</small></span>
            </button>
            ${expanded ? `<div class="tree-children">${storiesHtml}</div>` : ''}
          </div>`;
      }).join('');

      root.querySelectorAll('[data-volume]').forEach((btn) => {
        if (btn.dataset.story || btn.dataset.substory) return;
        btn.addEventListener('click', (event) => {
          event.preventDefault();
          const volumeId = btn.dataset.volume;
          if (expandedVolumes.has(volumeId)) expandedVolumes.delete(volumeId);
          else expandedVolumes.add(volumeId);
          selectedVolumeId = volumeId;
          const volume = outline.volumes.find((item) => item.partition_id === volumeId);
          if (volume && !selectedStoryUid) {
            const firstStory = (volume.stories || [])[0];
            if (firstStory) {
              selectedStoryUid = firstStory.story_uid;
              selectedStoryUids.add(firstStory.story_uid);
            }
          }
          renderTree();
          renderPreview();
          renderStatus();
        });
      });

      root.querySelectorAll('[data-story]').forEach((btn) => {
        if (btn.dataset.substory) return;
        btn.addEventListener('click', (event) => {
          event.preventDefault();
          selectedVolumeId = btn.dataset.volume;
          selectedStoryUid = btn.dataset.story;
          selectedSubstoryUid = '';
          if (selectedStoryUids.has(selectedStoryUid)) selectedStoryUids.delete(selectedStoryUid);
          else selectedStoryUids.add(selectedStoryUid);
          expandedVolumes.add(selectedVolumeId);
          renderTree();
          renderPreview();
          renderStatus();
        });
      });

      root.querySelectorAll('[data-substory]').forEach((btn) => {
        btn.addEventListener('click', (event) => {
          event.preventDefault();
          event.stopPropagation();
          selectedVolumeId = btn.dataset.volume;
          selectedStoryUid = btn.dataset.story;
          selectedSubstoryUid = btn.dataset.substory;
          selectedStoryUids.add(selectedStoryUid);
          expandedVolumes.add(selectedVolumeId);
          renderTree();
          renderPreview();
          renderStatus();
        });
      });
    }

    function currentStory() {
      for (const volume of outline.volumes) {
        for (const story of volume.stories || []) {
          if (story.story_uid === selectedStoryUid) return { volume, story };
        }
      }
      return null;
    }

    function renderPreview() {
      const title = el('preview-title');
      const meta = el('preview-meta');
      const count = el('preview-count');
      const content = el('preview-content');
      if (!title || !meta || !count || !content) return;

      const selected = currentStory();
      if (!selected) {
        title.textContent = '请先在左侧选择一个故事';
        meta.textContent = '-';
        count.textContent = '0 段';
        content.innerHTML = '<div class="preview-empty"><p>选中一个故事后，这里会显示正文并支持直接编辑校对。</p></div>';
        return;
      }

      title.textContent = selected.story.label;
      meta.textContent = selected.volume.label;
      count.textContent = `${selected.story.chunk_count} 段`;

      const partition = (rawSourceData.source_partitions || []).find((item) => item.partition_id === selected.volume.partition_id);
      const ids = new Set(selected.story.chunk_ids || []);
      let chunks = (partition?.text_chunks || []).filter((chunk) => ids.has(chunk.chunk_id));
      if (selectedSubstoryUid) {
        const sub = (selected.story.substories || []).find((item) => item.substory_uid === selectedSubstoryUid);
        if (sub) chunks = chunks.filter((chunk) => (chunk.chunk_id || '') === (sub.chunk_id || ''));
      }

      if (!chunks.length) {
        content.innerHTML = '<div class="preview-empty"><p>这个故事目前还没有可显示的正文片段。</p></div>';
        return;
      }

      content.innerHTML = chunks.map((chunk) => `
        <article class="text-fragment">
          <header>
            <span>${escapeHtml(chunk.chapter_label || selected.story.label)}</span>
            <small>${escapeHtml(chunk.chunk_id || '')}</small>
          </header>
          <textarea class="proofread-editor" data-chunk-id="${escapeHtml(chunk.chunk_id || '')}">${escapeTextarea(chunk.text || '')}</textarea>
        </article>`).join('');

      content.querySelectorAll('.proofread-editor').forEach((node) => {
        node.addEventListener('input', () => {
          const cid = node.dataset.chunkId;
          for (const partitionItem of rawSourceData.source_partitions || []) {
            for (const chunk of partitionItem.text_chunks || []) {
              if ((chunk.chunk_id || '') === cid) {
                chunk.text = node.value;
                return;
              }
            }
          }
        });
      });
    }

    function renderStatus() {
      const title = el('status-title');
      const body = el('status-body');
      const sourceStatus = el('source-status');
      if (!title || !body || !sourceStatus) return;

      if (currentStage !== 'Source_Ingester' && !stage1Ready) {
        sourceStatus.textContent = '前置资产未就绪';
        sourceStatus.className = 'status-chip';
      } else if (currentStage !== 'Source_Ingester') {
        sourceStatus.textContent = '已进入导演阶段';
        sourceStatus.className = 'status-chip ready';
      } else if (stage1Ready) {
        sourceStatus.textContent = '可进入下一步';
        sourceStatus.className = 'status-chip ready';
      } else if (hasRawSource) {
        sourceStatus.textContent = '已采集';
        sourceStatus.className = 'status-chip running';
      } else {
        sourceStatus.textContent = '待处理';
        sourceStatus.className = 'status-chip';
      }

      const selectedCount = selectedStoryUids.size;
      const processedCount = processedStorySet.size;
      if (!selectedCount) {
        title.textContent = '请先选择一个或多个具体故事，再确认进入下一步。';
        body.textContent = '系统会把你选中的故事写入进度记录，并在下一次启动时自动续跑。';
      } else if (selectedCount === 1) {
        title.textContent = '已选择 1 个故事，可以推进到导演引擎。';
        body.textContent = `当前已处理 ${processedCount}/${Math.max(processedCount, outline.story_count || 0)} 个故事。`;
      } else {
        title.textContent = `已选择 ${selectedCount} 个故事，可以批量推进。`;
        body.textContent = `当前已处理 ${processedCount} 个故事，批量确认后会为每个故事生成独立的 episode 记录。`;
      }

      const confirmButton = el('confirm-next-button');
      if (confirmButton) {
        confirmButton.disabled = !stage1Ready || selectedStoryUids.size === 0;
      }
    }

    async function extractAndClean() {
      const button = el('extract-button');
      const status = el('upload-status');
      if (!button) return;
      const controls = readControls();
      if (!controls.source_uri && !controls.source_keywords) {
        alert('请先输入 URL 或书名 / 关键词。');
        return;
      }

      button.disabled = true;
      button.textContent = '处理中...';
      if (status) status.textContent = '正在提取并清洗，请稍候...';

      try {
        await fetchJson('/api/source/extract', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(controls),
        });
        if (status) status.textContent = '内容已采集并清洗完成。页面正在刷新。';
        window.location.reload();
      } catch (error) {
        if (status) status.textContent = `采集失败：${error.message}`;
        alert(`采集失败：${error.message}`);
      } finally {
        button.disabled = false;
        button.textContent = '提取并清洗';
      }
    }

    async function uploadSelectedFile(file) {
      const controls = readControls();
      const uploadStatus = el('upload-status');
      if (uploadStatus) uploadStatus.textContent = `正在上传 ${file.name}...`;

      const formData = new FormData();
      formData.append('project_id', controls.project_id);
      formData.append('episode_id', controls.episode_id);
      formData.append('run_id', controls.run_id);
      formData.append('file', file);

      try {
        const payload = await fetchJson('/api/source/upload', { method: 'POST', body: formData });
        if (uploadStatus) {
          uploadStatus.textContent = payload.supported ? `已上传并解析：${file.name}` : payload.message || '文件已上传。';
        }
        if (!payload.supported) alert(payload.message || '文件已上传，但当前类型还未自动解析。');
        window.setTimeout(() => window.location.reload(), 350);
      } catch (error) {
        if (uploadStatus) uploadStatus.textContent = `上传失败：${error.message}`;
        alert(`上传失败：${error.message}`);
      }
    }

    function bindFileTray() {
      const fileInput = el('file-input');
      const pickButton = el('pick-file-button');
      const dropzone = el('file-dropzone');
      if (!fileInput || !pickButton || !dropzone) return;

      pickButton.addEventListener('click', () => fileInput.click());
      dropzone.addEventListener('click', (event) => {
        if (event.target === pickButton) return;
        fileInput.click();
      });
      dropzone.addEventListener('dragenter', (event) => {
        event.preventDefault();
        dropzone.classList.add('dragover');
      });
      dropzone.addEventListener('dragover', (event) => {
        event.preventDefault();
        dropzone.classList.add('dragover');
      });
      dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
      dropzone.addEventListener('drop', (event) => {
        event.preventDefault();
        dropzone.classList.remove('dragover');
        const file = event.dataTransfer?.files?.[0];
        if (file) uploadSelectedFile(file);
      });
      fileInput.addEventListener('change', () => {
        const file = fileInput.files?.[0];
        if (file) uploadSelectedFile(file);
      });
    }

    async function saveProofread() {
      try {
        await fetchJson('/api/source/update', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...readControls(),
            source_partitions: rawSourceData.source_partitions || []
          })
        });
        alert('校对内容已保存。');
        window.location.reload();
      } catch (error) {
        alert(`保存失败：${error.message}`);
      }
    }

    async function confirmNextStep() {
      try {
        if (!stage1Ready) {
          alert('上一个阶段资产还没有就绪，请先完成采集、清洗和故事选择。');
          return;
        }
        if (!selectedStoryUids.size) {
          alert('请先选择一个具体故事。');
          return;
        }
        const payload = {
          ...readControls(),
          selected_story_uid: selectedStoryUid,
          selected_story_uids: Array.from(selectedStoryUids),
        };

        if (selectedStoryUids.size > 1) {
          await fetchJson('/api/source/confirm-batch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          });
          alert(`已批量确认 ${selectedStoryUids.size} 个故事。`);
        } else {
          const result = await fetchJson('/api/source/confirm', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...payload, auto_start_next: true }),
          });
          alert(result.next_job ? '已确认并自动启动 Director_Engine。' : '已确认，流程可以进入 Director_Engine。');
        }
        window.location.reload();
      } catch (error) {
        alert(`确认失败：${error.message}`);
      }
    }

    async function resetSource() {
      if (!window.confirm('确定要清空当前采集结果吗？')) return;
      if (!window.confirm('二次确认：这会删除当前结果并重置 Stage 1。继续吗？')) return;
      try {
        await fetchJson('/api/source/reset', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...readControls(), confirmed: true }),
        });
        window.location.reload();
      } catch (error) {
        alert(`重置失败：${error.message}`);
      }
    }

    function renderLogs() {
      const logs = dashboard.logs || [];
      const compact = el('log-compact');
      const full = el('log-full');
      if (!compact || !full) return;
      const recent = logs.slice(0, 3);
      compact.innerHTML = recent.map((item) => `<div class="progress-float__log"><strong>${escapeHtml(item.module_name || 'System')}</strong><span>${escapeHtml(item.status || '')}</span><p>${escapeHtml(item.message || '')}</p></div>`).join('') || '<div class="progress-float__log"><p>暂无日志</p></div>';
      full.innerHTML = logs.map((item) => `<div class="progress-float__log"><strong>${escapeHtml(item.module_name || 'System')} · ${escapeHtml(item.status || '')}</strong><span>${escapeHtml(item.created_at || '')}</span><p>${escapeHtml(item.message || '')}</p></div>`).join('') || '<div class="progress-float__log"><p>暂无详细日志</p></div>';
    }

    function setLogState() {
      const panel = el('log-panel');
      const content = el('log-content');
      const toggle = el('toggle-log-button');
      const compact = el('log-compact');
      const full = el('log-full');
      const detailBtn = el('expand-log-detail');
      if (!panel || !content || !toggle || !compact || !full || !detailBtn) return;

      panel.classList.toggle('collapsed', !logOpen);
      content.style.display = logOpen ? 'block' : 'none';
      toggle.textContent = logOpen ? '▾' : '▸';
      toggle.title = logOpen ? '隐藏日志' : '显示日志';
      detailBtn.style.display = logOpen ? 'inline-flex' : 'none';
      full.style.display = logDetailOpen && logOpen ? 'block' : 'none';
      compact.style.display = logDetailOpen && logOpen ? 'none' : 'block';
      detailBtn.textContent = logDetailOpen ? '收起详情' : '展开详情';
    }

    function toggleLogPanel() {
      logOpen = !logOpen;
      if (!logOpen) logDetailOpen = false;
      setLogState();
    }

    function toggleLogDetail() {
      logDetailOpen = !logDetailOpen;
      setLogState();
    }

    function updateStageViews() {
      const goStage1Button = el('go-stage1-button');
      if (goStage1Button) goStage1Button.style.display = effectiveStageIndex === 0 ? 'none' : 'inline-flex';
    }

    function setLongPageSectionState() {
      const stageOrder = {
        source: 0,
        director: 1,
        writer: 2,
        audio: 3,
        visual: 4,
        render: 5,
        global: 6,
        master: 7,
      };
      Object.entries(stageOrder).forEach(([id, index]) => {
        const section = el(`section-${id}`);
        if (!section) return;
        const enabled = index <= effectiveStageIndex;
        section.style.opacity = enabled ? '1' : '0.52';
        section.style.pointerEvents = enabled ? 'auto' : 'none';
      });
    }

    function init() {
      fillStaticText();
      buildTrack();
      updateStageViews();
      setLongPageSectionState();
      renderTree();
      renderPreview();
      bindFileTray();
      if (effectiveStage !== 'Source_Ingester') {
        const job = dashboard.job || {};
        const statusNode = el('director-job-status');
        if (statusNode) statusNode.textContent = job.status || 'running';
      }
      renderLogs();
      renderStatus();
      setLogState();

      const uploadStatus = el('upload-status');
      if (uploadStatus && !stage1Ready) {
        uploadStatus.textContent = '???????? URL / ??????????????';
      }

      el('extract-button')?.addEventListener('click', extractAndClean);
      el('save-proofread-button')?.addEventListener('click', saveProofread);
      el('confirm-next-button')?.addEventListener('click', confirmNextStep);
      el('reset-button')?.addEventListener('click', resetSource);
      el('reload-button')?.addEventListener('click', () => window.location.reload());
      el('go-stage1-button')?.addEventListener('click', () => {
        const stage1View = el('stage1-view');
        const stage2View = el('stage2-view');
        if (stage1View) stage1View.style.display = '';
        if (stage2View) stage2View.style.display = 'none';
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
      el('toggle-log-button')?.addEventListener('click', toggleLogPanel);
      el('expand-log-detail')?.addEventListener('click', toggleLogDetail);
      el('source-uri')?.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
          event.preventDefault();
          extractAndClean();
        }
      });
    }

    document.addEventListener('DOMContentLoaded', init);
  