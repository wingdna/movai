﻿
    const dashboard = {};
    const stageOrder = [
      "Source_Ingester",
      "Director_Engine",
      "Writer_Engine",
      "Audio_Anchor_Forge",
      "Visual_Asset_Foundry",
      "Render_Engine",
      "Global_Distributor",
      "Master_Hub"
    ];
    const stageLabels = {
      Source_Ingester: "Data Ingest",
      Director_Engine: "Director Engine",
      Writer_Engine: "Writer Engine",
      Audio_Anchor_Forge: "Audio Anchor",
      Visual_Asset_Foundry: "Visual Assets",
      Render_Engine: "Render Engine",
      Global_Distributor: "Global Distribution",
      Master_Hub: "Master Hub"
    };

    const currentStage = dashboard.manifest?.current_stage || "Source_Ingester";
    const outline = dashboard.documents?.raw_outline || { volumes: [], story_count: 0 };
    const sourceProgress = dashboard.documents?.source_progress || { processed_story_uids: [], story_episode_map: {} };
    const processedStorySet = new Set(sourceProgress.processed_story_uids || []);
    const el = (id) => document.getElementById(id);
    const hasValidText = Boolean(dashboard.source_ready);

    let selectedVolumeId = "";
    let selectedStoryUid = "";
    let selectedSubstoryUid = "";
    let selectedStoryUids = new Set();
    let rawSourceData = JSON.parse(JSON.stringify(dashboard.documents?.raw_source || {}));
    let expandedVolumes = new Set();
    let logOpen = false;
    let logDetailOpen = false;

    if (outline.volumes.length > 0) {
      const firstVolume = outline.volumes[0];
      expandedVolumes.add(firstVolume.partition_id);
      const firstStory = (firstVolume.stories || []).find((story) => !processedStorySet.has(story.story_uid)) || (firstVolume.stories || [])[0];
      if (firstStory) {
        selectedVolumeId = firstVolume.partition_id;
        selectedStoryUid = firstStory.story_uid;
        selectedStoryUids.add(firstStory.story_uid);
      }
    }

    function readControls() {
      const value = (el("source-uri").value || "").trim();
      const isUrl = /^https?:\/\//i.test(value);
      return {
        project_id: dashboard.project_id,
        episode_id: dashboard.episode_id,
        run_id: dashboard.run_id || "web_ui",
        source_uri: isUrl ? value : "",
        source_keywords: isUrl ? "" : value,
        source_type_hint: "web_url"
      };
    }

    async function fetchJson(url, options) {
      const response = await fetch(url, options);
      const text = await response.text();
      let data = {};
      try {
        data = text ? JSON.parse(text) : {};
      } catch {
        data = { detail: text || response.statusText };
      }
      if (!response.ok) {
        throw new Error(data.detail || data.message || "Request failed");
      }
      return data;
    }

    function escapeHtml(text) {
      return String(text)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll("\"", "&quot;")
        .replaceAll("'", "&#39;")
        .replaceAll("\n", "<br>");
    }

    function escapeTextarea(text) {
      return String(text)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll("\"", "&quot;")
        .replaceAll("'", "&#39;");
    }

    function buildTrack() {
      const root = el("track-stages");
      root.innerHTML = "";
      stageOrder.forEach((name) => {
        const node = document.createElement("div");
        node.className = "track-stage";
        if (name === currentStage) node.classList.add("active");
        if (stageOrder.indexOf(name) < stageOrder.indexOf(currentStage)) node.classList.add("complete");
        node.innerHTML = `<span class="track-icon ${name === currentStage ? "pulse" : ""}"></span><span class="track-label">${stageLabels[name]}</span>`;
        root.appendChild(node);
      });
    }

    function renderTree() {
      const root = el("chapter-tree");
      if (!outline.volumes.length) {
        root.innerHTML = `<div class="tree-empty"><strong>绛夊緟绱犳潗杩涘叆</strong><p>閲囬泦瀹屾垚鍚庯紝杩欓噷浼氳嚜鍔ㄧ敓鎴愨€滃嵎 / 鏁呬簨 / 鐗囨鈥濆绾х洰褰曘€?/p></div>`;
        return;
      }

      root.innerHTML = outline.volumes.map((volume) => {
        const expanded = expandedVolumes.has(volume.partition_id);
        const volumeHeader = `
          <button class="tree-node ${selectedVolumeId === volume.partition_id ? "selected" : ""}" type="button" data-volume="${volume.partition_id}">
            <span class="tree-checkbox ${expanded ? "checked" : ""}"></span>
            <span class="tree-copy"><strong>${escapeHtml(volume.label)}</strong><small>${volume.chunk_count} 娈?/small></span>
          </button>`;

        const stories = (volume.stories || []).map((story) => {
          const checked = selectedStoryUids.has(story.story_uid);
          const done = processedStorySet.has(story.story_uid);
          const episode = sourceProgress.story_episode_map?.[story.story_uid] || "";
          const doneLabel = done ? `<em class="story-done">done${episode ? ` 路 ${escapeHtml(episode)}` : ""}</em>` : "";
          const substories = (story.substories || []).map((sub) => `
            <button class="tree-node tree-substory ${selectedSubstoryUid === sub.substory_uid ? "selected" : ""}" type="button" data-substory="${sub.substory_uid}" data-story="${story.story_uid}" data-volume="${volume.partition_id}">
              <span class="tree-checkbox ${selectedSubstoryUid === sub.substory_uid ? "checked" : ""}"></span>
              <span class="tree-copy"><strong>${escapeHtml(sub.label)}</strong><small>${escapeHtml(sub.chunk_id || "")}</small></span>
            </button>`).join("");

          return `
            <button class="tree-node tree-story ${selectedStoryUid === story.story_uid ? "selected" : ""}" type="button" data-story="${story.story_uid}" data-volume="${volume.partition_id}">
              <span class="tree-checkbox ${checked ? "checked" : ""}"></span>
              <span class="tree-copy"><strong>${escapeHtml(story.label)} ${doneLabel}</strong><small>${story.chunk_count} items</small></span>
            </button>
            ${expanded ? `<div class="tree-children">${substories}</div>` : ""}`;
        }).join("");

        return `<div class="tree-group">${volumeHeader}${expanded ? `<div class="tree-children">${stories}</div>` : ""}</div>`;
      }).join("");

      root.querySelectorAll("[data-volume]").forEach((btn) => {
        if (btn.dataset.story) return;
        btn.addEventListener("click", (event) => {
          event.preventDefault();
          if (expandedVolumes.has(btn.dataset.volume)) expandedVolumes.delete(btn.dataset.volume);
          else expandedVolumes.add(btn.dataset.volume);
          renderTree();
        });
      });

      root.querySelectorAll("[data-story]").forEach((btn) => {
        if (btn.dataset.substory) return;
        btn.addEventListener("click", (event) => {
          event.preventDefault();
          selectedVolumeId = btn.dataset.volume;
          selectedStoryUid = btn.dataset.story;
          selectedSubstoryUid = "";
          if (selectedStoryUids.has(selectedStoryUid)) selectedStoryUids.delete(selectedStoryUid);
          else selectedStoryUids.add(selectedStoryUid);
          renderTree();
          renderPreview();
          renderStatus();
        });
      });

      root.querySelectorAll("[data-substory]").forEach((btn) => {
        btn.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          selectedVolumeId = btn.dataset.volume;
          selectedStoryUid = btn.dataset.story;
          selectedSubstoryUid = btn.dataset.substory;
          if (!selectedStoryUids.has(selectedStoryUid)) selectedStoryUids.add(selectedStoryUid);
          renderTree();
          renderPreview();
          renderStatus();
        });
      });
    }

    function currentStory() {
      for (const volume of outline.volumes) {
        for (const story of volume.stories || []) {
          if (story.story_uid === selectedStoryUid) return { volume, story };
        }
      }
      return null;
    }

    function renderPreview() {
      const title = el("preview-title");
      const meta = el("preview-meta");
      const count = el("preview-count");
      const content = el("preview-content");
      const selected = currentStory();

      if (!selected) {
        title.textContent = "No story selected";
        meta.textContent = "Waiting for ingest";
        count.textContent = "0 chunks";
        content.innerHTML = `<div class="preview-empty"><p>Please select a story from the left tree.</p></div>`;
        return;
      }

      title.textContent = selected.story.label;
      meta.textContent = selected.volume.label;
      count.textContent = `${selected.story.chunk_count} chunks`;

      const partition = (rawSourceData.source_partitions || []).find((item) => item.partition_id === selected.volume.partition_id);
      const ids = new Set(selected.story.chunk_ids || []);
      let chunks = (partition?.text_chunks || []).filter((chunk) => ids.has(chunk.chunk_id));
      if (selectedSubstoryUid) {
        const sub = (selected.story.substories || []).find((item) => item.substory_uid === selectedSubstoryUid);
        if (sub) chunks = chunks.filter((chunk) => (chunk.chunk_id || "") === (sub.chunk_id || ""));
      }

      content.innerHTML = chunks.map((chunk) => `
        <article class="text-fragment">
          <header>
            <span>${escapeHtml(chunk.chapter_label || selected.story.label)}</span>
            <small>${escapeHtml(chunk.chunk_id || "")}</small>
          </header>
          <textarea class="proofread-editor" data-chunk-id="${escapeHtml(chunk.chunk_id || "")}">${escapeTextarea(chunk.text || "")}</textarea>
        </article>`).join("");

      content.querySelectorAll(".proofread-editor").forEach((node) => {
        node.addEventListener("input", () => {
          const cid = node.dataset.chunkId;
          for (const partitionItem of rawSourceData.source_partitions || []) {
            for (const chunk of partitionItem.text_chunks || []) {
              if ((chunk.chunk_id || "") === cid) {
                chunk.text = node.value;
                return;
              }
            }
          }
        });
      });
    }

    function renderStatus() {
      const sourceStatus = el("source-status");
      const dockStatus = el("dock-status");
      const confirmButton = el("confirm-next-button");
      const canConfirm = hasValidText && selectedStoryUids.size > 0;

      if (canConfirm) {
        sourceStatus.textContent = "Ready";
        sourceStatus.className = "status-chip ready";
        dockStatus.textContent = `Selected ${selectedStoryUids.size} stories. Done ${processedStorySet.size}/${outline.story_count || 0}.`;
        confirmButton.disabled = false;
        confirmButton.classList.remove("disabled");
        confirmButton.textContent = selectedStoryUids.size > 1 ? `Batch start ${selectedStoryUids.size}` : "Confirm next step";
      } else {
        sourceStatus.textContent = hasValidText ? "Select story" : "Pending";
        sourceStatus.className = hasValidText ? "status-chip running" : "status-chip";
        dockStatus.textContent = hasValidText ? "Please select at least one story from the left." : "No valid raw_source.json yet.";
        confirmButton.disabled = true;
        confirmButton.classList.add("disabled");
        confirmButton.textContent = "Confirm next step";
      }
    }

    async function extractAndClean() {
      const controls = readControls();
      if (!controls.source_uri && !controls.source_keywords) {
        alert("Enter a URL or keyword.");
        return;
      }
      const button = el("extract-button");
      button.disabled = true;
      button.textContent = "Extracting...";
      try {
        await fetchJson("/api/source/extract", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(controls)
        });
        window.location.reload();
      } catch (error) {
        alert(`Extract failed: ${error.message}`);
      } finally {
        button.disabled = false;
        button.textContent = "鎻愬彇骞舵竻娲?;
      }
    }

    async function uploadSelectedFile(file) {
      const controls = readControls();
      const uploadStatus = el("upload-status");
        if (uploadStatus) uploadStatus.textContent = `Uploading ${file.name}...`;

      const formData = new FormData();
      formData.append("project_id", controls.project_id);
      formData.append("episode_id", controls.episode_id);
      formData.append("run_id", controls.run_id);
      formData.append("file", file);

      try {
        const response = await fetch("/api/source/upload", { method: "POST", body: formData });
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.detail || "Upload failed");
        if (uploadStatus) {
          uploadStatus.textContent = payload.supported
            ? `Uploaded and parsed: ${file.name}`
            : payload.message || "Uploaded, but not auto-parsed yet.";
        }
        if (!payload.supported) alert(payload.message || "Uploaded, but not auto-parsed.");
        window.setTimeout(() => window.location.reload(), 400);
      } catch (error) {
        if (uploadStatus) uploadStatus.textContent = `Upload failed: ${error.message}`;
        alert(`Upload failed: ${error.message}`);
      }
    }

    async function saveProofread() {
      try {
        await fetchJson("/api/source/update", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...readControls(),
            source_partitions: rawSourceData.source_partitions || []
          })
        });
        alert("Proofread text saved.");
        window.location.reload();
      } catch (error) {
        alert(`Save failed: ${error.message}`);
      }
    }

    async function confirmNextStep() {
      try {
        const payload = {
          ...readControls(),
          selected_story_uid: selectedStoryUid,
          selected_story_uids: Array.from(selectedStoryUids)
        };
        if (selectedStoryUids.size > 1) {
          await fetchJson("/api/source/confirm-batch", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
          });
          alert(`Batch confirmed ${selectedStoryUids.size} stories.`);
        } else {
          const result = await fetchJson("/api/source/confirm", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ...payload, auto_start_next: true })
          });
          alert(result.next_job ? "Confirmed and started Director_Engine." : "Confirmed. Director_Engine is ready.");
        }
        window.location.reload();
      } catch (error) {
        alert(`Confirm failed: ${error.message}`);
      }
    }

    async function resetSource() {
      if (!window.confirm("Erase current ingest and reset stage 1?")) return;
      if (!window.confirm("Second confirm: this will delete current ingest. Continue?")) return;
      try {
        await fetchJson("/api/source/reset", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...readControls(), confirmed: true })
        });
        window.location.reload();
      } catch (error) {
        alert(`Reset failed: ${error.message}`);
      }
    }

    function bindFileTray() {
      const fileInput = el("file-input");
      const pickButton = el("pick-file-button");
      const dropzone = el("file-dropzone");
      if (!fileInput || !pickButton || !dropzone) return;

      pickButton.addEventListener("click", () => fileInput.click());
      dropzone.addEventListener("click", (event) => {
        if (event.target === pickButton) return;
        fileInput.click();
      });
      dropzone.addEventListener("dragenter", (event) => {
        event.preventDefault();
        dropzone.classList.add("dragover");
      });
      dropzone.addEventListener("dragover", (event) => {
        event.preventDefault();
        dropzone.classList.add("dragover");
      });
      dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
      dropzone.addEventListener("drop", (event) => {
        event.preventDefault();
        dropzone.classList.remove("dragover");
        const file = event.dataTransfer?.files?.[0];
        if (file) uploadSelectedFile(file);
      });
      fileInput.addEventListener("change", () => {
        const file = fileInput.files?.[0];
        if (file) uploadSelectedFile(file);
      });
    }

    function renderLogs() {
      const logs = dashboard.logs || [];
      const compact = el("log-compact");
      const full = el("log-full");
      const recent = logs.slice(0, 3);
      compact.innerHTML = recent.map((item) => `<div class="progress-float__item"><strong>${escapeHtml(item.module_name || "System")}</strong><p>${escapeHtml(item.message || "")}</p></div>`).join("") || "<p>No logs</p>";
      full.innerHTML = logs.map((item) => `<div class="progress-float__item"><strong>${escapeHtml(item.module_name || "System")} 路 ${escapeHtml(item.status || "")}</strong><p>${escapeHtml(item.message || "")}</p></div>`).join("") || "<p>No logs</p>";
    }

    function setLogState() {
      const panel = el("log-panel");
      const content = el("log-content");
      const toggle = el("toggle-log-button");
      const compact = el("log-compact");
      const full = el("log-full");
      const detailBtn = el("expand-log-detail");
      if (!panel || !content || !toggle || !compact || !full || !detailBtn) return;

      panel.classList.toggle("collapsed", !logOpen);
      content.style.display = logOpen ? "block" : "none";
      toggle.textContent = logOpen ? "鈻? : "鈼€";
      toggle.title = logOpen ? "Hide logs" : "Show logs";
      full.style.display = logDetailOpen ? "block" : "none";
      compact.style.display = logDetailOpen ? "none" : "block";
      detailBtn.textContent = logDetailOpen ? "Hide detail" : "Show detail";
    }

    function toggleLogPanel() {
      logOpen = !logOpen;
      if (!logOpen) logDetailOpen = false;
      setLogState();
    }

    function toggleLogDetail() {
      logDetailOpen = !logDetailOpen;
      setLogState();
    }

    function init() {
      const stage1View = el("stage1-view");
      const stage2View = el("stage2-view");
      const isStage1 = currentStage === "Source_Ingester";
      if (stage1View) stage1View.style.display = isStage1 ? "" : "none";
      if (stage2View) stage2View.style.display = isStage1 ? "none" : "";

      buildTrack();
      if (isStage1) {
        renderTree();
        renderPreview();
        renderStatus();
        bindFileTray();
      } else {
        const job = dashboard.job || {};
        const statusNode = el("director-job-status");
        if (statusNode) statusNode.textContent = job.status || "running";
      }

      renderLogs();
      setLogState();

      const uploadStatus = el("upload-status");
      if (uploadStatus && currentStage === "Source_Ingester" && !hasValidText) {
        uploadStatus.textContent = "Drag files here or click Select Local File.";
      }

      el("extract-button")?.addEventListener("click", extractAndClean);
      el("save-proofread-button")?.addEventListener("click", saveProofread);
      el("confirm-next-button")?.addEventListener("click", confirmNextStep);
      el("reset-button")?.addEventListener("click", resetSource);
      el("reload-button")?.addEventListener("click", () => window.location.reload());
      el("go-stage1-button")?.addEventListener("click", () => {
        if (stage1View) stage1View.style.display = "";
        if (stage2View) stage2View.style.display = "none";
      });
      el("toggle-log-button")?.addEventListener("click", toggleLogPanel);
      el("hide-log-button")?.addEventListener("click", toggleLogPanel);
      el("expand-log-detail")?.addEventListener("click", toggleLogDetail);
    }

    init();
  
