cd C:\Users\Administrator\.windsurf\worktrees\movai\movai-9501c3f2
movai-web