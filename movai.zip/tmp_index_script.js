﻿
    const dashboard = {{ dashboard | tojson }};
    const stageOrder = ["Source_Ingester","Director_Engine","Writer_Engine","Audio_Anchor_Forge","Visual_Asset_Foundry","Render_Engine","Global_Distributor","Master_Hub"];
    const stageLabels = {
      Source_Ingester: "鏁版嵁閲囬泦",
      Director_Engine: "涓栫晫瑙傚婕?,
      Writer_Engine: "鍒嗛暅缂栧墽",
      Audio_Anchor_Forge: "闊抽閿氱偣",
      Visual_Asset_Foundry: "瑙嗚璧勪骇",
      Render_Engine: "2.5D 娓叉煋",
      Global_Distributor: "鍏ㄧ悆鍒嗗彂",
      Master_Hub: "涓ぎ鎬绘帶"
    };
    const currentStage = dashboard.manifest?.current_stage || "Source_Ingester";
    const outline = dashboard.documents?.raw_outline || { volumes: [], story_count: 0 };
    const sourceProgress = dashboard.documents?.source_progress || { processed_story_uids: [], story_episode_map: {} };
    const processedStorySet = new Set(sourceProgress.processed_story_uids || []);

    let selectedStoryUid = "";
    let selectedSubstoryUid = "";
    let selectedStoryUids = new Set();
    let selectedVolumeId = "";
    let expandedVolumes = new Set();
    let rawSourceData = JSON.parse(JSON.stringify(dashboard.documents?.raw_source || {}));
    let logOpen = false;
    let logDetailOpen = false;

    if (outline.volumes.length > 0) {
      const first = outline.volumes[0];
      expandedVolumes.add(first.partition_id);
      const firstUnprocessed = (first.stories || []).find((s) => !processedStorySet.has(s.story_uid));
      const initial = firstUnprocessed || (first.stories || [])[0];
      if (initial) {
        selectedStoryUid = initial.story_uid;
        selectedStoryUids.add(initial.story_uid);
        selectedVolumeId = first.partition_id;
      }
    }

    const el = (id) => document.getElementById(id);
    const hasValidText = Boolean(dashboard.source_ready);
    const hasStorySelection = () => selectedStoryUids.size > 0;

    function readControls() {
      const value = (el("source-uri").value || "").trim();
      const isUrl = /^https?:\/\//i.test(value);
      return {
        project_id: dashboard.project_id,
        episode_id: dashboard.episode_id,
        run_id: dashboard.run_id || "web_ui",
        source_uri: isUrl ? value : "",
        source_keywords: isUrl ? "" : value,
        source_type_hint: "web_url",
      };
    }

    async function fetchJson(url, options) {
      const response = await fetch(url, options);
      const text = await response.text();
      let data = {};
      try { data = text ? JSON.parse(text) : {}; } catch { data = { detail: text || response.statusText }; }
      if (!response.ok) throw new Error(data.detail || data.message || "Request failed");
      return data;
    }

    function escapeHtml(text) {
      return String(text)
        .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
        .replaceAll("\"", "&quot;").replaceAll("'", "&#39;").replaceAll("\n", "<br>");
    }

    function escapeTextarea(text) {
      return String(text)
        .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
        .replaceAll("\"", "&quot;").replaceAll("'", "&#39;");
    }

    function buildTrack() {
      const root = el("track-stages");
      root.innerHTML = "";
      stageOrder.forEach((name, idx) => {
        const node = document.createElement("div");
        node.className = "track-stage";
        if (name === currentStage) node.classList.add("active");
        const done = stageOrder.indexOf(name) < stageOrder.indexOf(currentStage);
        if (done) node.classList.add("complete");
        node.innerHTML = `<span class="track-icon ${name === currentStage ? "pulse" : ""}"></span><span class="track-label">${stageLabels[name]}</span>`;
        root.appendChild(node);
      });
    }

    function toggleVolume(partitionId) {
      if (expandedVolumes.has(partitionId)) expandedVolumes.delete(partitionId);
      else expandedVolumes.add(partitionId);
      renderTree();
    }

    function selectStory(volumeId, storyUid, withToggle = true) {
      selectedVolumeId = volumeId;
      selectedStoryUid = storyUid;
      selectedSubstoryUid = "";
      if (withToggle) {
        if (selectedStoryUids.has(storyUid)) {
          selectedStoryUids.delete(storyUid);
          if (selectedStoryUid === storyUid) {
            selectedStoryUid = Array.from(selectedStoryUids)[0] || "";
          }
        } else {
          selectedStoryUids.add(storyUid);
        }
      } else {
        selectedStoryUids = new Set([storyUid]);
      }
      renderTree();
      renderPreview();
      renderStatus();
    }

    function selectSubstory(volumeId, storyUid, substoryUid) {
      selectedVolumeId = volumeId;
      selectedStoryUid = storyUid;
      selectedSubstoryUid = substoryUid;
      if (!selectedStoryUids.has(storyUid)) selectedStoryUids = new Set([storyUid]);
      renderTree();
      renderPreview();
      renderStatus();
    }

    function renderTree() {
      const root = el("chapter-tree");
      if (!outline.volumes.length) {
        root.innerHTML = `<div class="tree-empty"><strong>绛夊緟绱犳潗杩涘叆</strong><p>閲囬泦瀹屾垚鍚庯紝杩欓噷浼氳嚜鍔ㄧ敓鎴愨€滃嵎 / 鏁呬簨 / 鐗囨鈥濆绾х洰褰曘€?/p></div>`;
        return;
      }
      root.innerHTML = outline.volumes.map((volume) => {
        const expanded = expandedVolumes.has(volume.partition_id);
        const volumeHeader = `<button class="tree-node ${selectedVolumeId === volume.partition_id ? "selected" : ""}" type="button" data-volume="${volume.partition_id}">
          <span class="tree-checkbox ${expanded ? "checked" : ""}"></span>
          <span class="tree-copy"><strong>${escapeHtml(volume.label)}</strong><small>${volume.chunk_count} 娈?/small></span>
        </button>`;
        const stories = (volume.stories || []).map((story) => {
          const checked = selectedStoryUids.has(story.story_uid);
          const done = processedStorySet.has(story.story_uid);
          const episode = sourceProgress.story_episode_map?.[story.story_uid] || "";
          const subs = (story.substories || []).map((sub) => `<button class="tree-node tree-substory ${selectedSubstoryUid === sub.substory_uid ? "selected" : ""}" type="button" data-substory="${sub.substory_uid}" data-story="${story.story_uid}" data-volume="${volume.partition_id}" data-chunk="${escapeHtml(sub.chunk_id || "")}"><span class="tree-checkbox ${selectedSubstoryUid === sub.substory_uid ? "checked" : ""}"></span><span class="tree-copy"><strong>${escapeHtml(sub.label)}</strong><small>${escapeHtml(sub.chunk_id || "")}</small></span></button>`).join("");
          return `<button class="tree-node tree-story ${selectedStoryUid === story.story_uid ? "selected" : ""}" type="button" data-story="${story.story_uid}" data-volume="${volume.partition_id}">
            <span class="tree-checkbox ${checked ? "checked" : ""}"></span>
            <span class="tree-copy"><strong>${escapeHtml(story.label)} ${done ? `<em class="story-done">宸插鐞?{episode ? ` 路 ${escapeHtml(episode)}` : ""}</em>` : ""}</strong><small>${story.chunk_count} 娈?/small></span>
          </button>${expanded ? `<div class="tree-children">${subs}</div>` : ""}`;
        }).join("");
        return `<div class="tree-group">${volumeHeader}${expanded ? `<div class="tree-children">${stories}</div>` : ""}</div>`;
      }).join("");

      root.querySelectorAll("[data-volume]").forEach((btn) => {
        if (btn.dataset.story) return;
        btn.addEventListener("click", () => toggleVolume(btn.dataset.volume));
      });
      root.querySelectorAll("[data-story]").forEach((btn) => {
        if (btn.dataset.substory) return;
        btn.addEventListener("click", () => {
          selectStory(btn.dataset.volume, btn.dataset.story, true);
        });
      });
      root.querySelectorAll("[data-substory]").forEach((btn) => {
        btn.addEventListener("click", (event) => {
          event.stopPropagation();
          selectSubstory(btn.dataset.volume, btn.dataset.story, btn.dataset.substory);
        });
      });
    }

    function currentStory() {
      for (const volume of outline.volumes) {
        for (const story of (volume.stories || [])) {
          if (story.story_uid === selectedStoryUid) return { volume, story };
        }
      }
      return null;
    }

    function renderPreview() {
      const title = el("preview-title");
      const meta = el("preview-meta");
      const count = el("preview-count");
      const content = el("preview-content");
      const selected = currentStory();
      if (!selected) {
        title.textContent = "灏氭湭閫夋嫨鏁呬簨";
        meta.textContent = "绛夊緟閲囬泦缁撴灉";
        count.textContent = "0 娈垫枃鏈?;
        content.innerHTML = `<div class="preview-empty"><p>璇蜂粠宸︿晶鐩綍鏍戜腑閫夋嫨涓€涓叿浣撴晠浜嬨€?/p></div>`;
        return;
      }
      title.textContent = selected.story.label;
      meta.textContent = selected.volume.label;
      count.textContent = `${selected.story.chunk_count} 娈垫枃鏈琡;
      const partition = (rawSourceData.source_partitions || []).find((p) => p.partition_id === selected.volume.partition_id);
      const ids = new Set(selected.story.chunk_ids || []);
      let chunks = (partition?.text_chunks || []).filter((c) => ids.has(c.chunk_id));
      if (selectedSubstoryUid) {
        const sub = (selected.story.substories || []).find((x) => x.substory_uid === selectedSubstoryUid);
        if (sub) chunks = chunks.filter((c) => (c.chunk_id || "") === (sub.chunk_id || ""));
      }
      content.innerHTML = chunks.map((chunk) => `<article class="text-fragment"><header><span>${escapeHtml(chunk.chapter_label || selected.story.label)}</span><small>${escapeHtml(chunk.chunk_id || "")}</small></header><textarea class="proofread-editor" data-chunk-id="${escapeHtml(chunk.chunk_id || "")}">${escapeTextarea(chunk.text || "")}</textarea></article>`).join("");
      content.querySelectorAll(".proofread-editor").forEach((node) => {
        node.addEventListener("input", () => {
          const cid = node.dataset.chunkId;
          for (const p of (rawSourceData.source_partitions || [])) {
            for (const c of (p.text_chunks || [])) {
              if ((c.chunk_id || "") === cid) { c.text = node.value; return; }
            }
          }
        });
      });
    }

    function renderStatus() {
      const sourceStatus = el("source-status");
      const dockStatus = el("dock-status");
      const confirmButton = el("confirm-next-button");
      const canConfirm = hasValidText && hasStorySelection();
      if (canConfirm) {
        sourceStatus.textContent = "寰呯‘璁?;
        sourceStatus.className = "status-chip ready";
        dockStatus.textContent = `宸查€夋嫨 ${selectedStoryUids.size} 涓晠浜嬨€傚凡澶勭悊 ${processedStorySet.size}/${outline.story_count || 0}銆俙;
        confirmButton.disabled = false;
        confirmButton.classList.remove("disabled");
        confirmButton.textContent = selectedStoryUids.size > 1 ? `鎵归噺鐢熸垚 ${selectedStoryUids.size} 闆哷 : "纭杩涘叆涓嬩竴姝?;
      } else {
        sourceStatus.textContent = hasValidText ? "璇烽€夋嫨鏁呬簨" : "寰呭鐞?;
        sourceStatus.className = hasValidText ? "status-chip running" : "status-chip";
        dockStatus.textContent = hasValidText ? "璇峰厛鍦ㄥ乏渚ч€夋嫨鑷冲皯涓€涓晠浜嬨€? : "灏氭湭妫€娴嬪埌鏈夋晥 raw_source.json锛屾祦绋嬩笉浼氳嚜鍔ㄦ帹杩涖€?;
        confirmButton.disabled = true;
        confirmButton.classList.add("disabled");
        confirmButton.textContent = "纭杩涘叆涓嬩竴姝?;
      }
    }

    async function extractAndClean() {
      const controls = readControls();
      if (!controls.source_uri && !controls.source_keywords) {
        alert("璇疯緭鍏?URL 鎴栧叧閿瘝銆?);
        return;
      }
      const button = el("extract-button");
      button.disabled = true;
      button.textContent = "姝ｅ湪鎻愬彇...";
      try {
        await fetchJson("/api/source/extract", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(controls) });
        window.location.reload();
      } catch (error) {
        alert(`鎻愬彇澶辫触: ${error.message}`);
      } finally {
        button.disabled = false;
        button.textContent = "鎻愬彇骞舵竻娲?;
      }
    }

    async function uploadSelectedFile(file) {
      const controls = readControls();
      const formData = new FormData();
      formData.append("project_id", controls.project_id);
      formData.append("episode_id", controls.episode_id);
      formData.append("run_id", controls.run_id);
      formData.append("file", file);
      try {
        const response = await fetch("/api/source/upload", { method: "POST", body: formData });
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.detail || "Upload failed");
        if (!payload.supported) alert(payload.message || "鏂囦欢宸蹭笂浼狅紝褰撳墠绫诲瀷鏆備笉鑷姩瑙ｆ瀽銆?);
        window.location.reload();
      } catch (error) {
        alert(`涓婁紶澶辫触: ${error.message}`);
      }
    }

    async function saveProofread() {
      try {
        await fetchJson("/api/source/update", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...readControls(), source_partitions: rawSourceData.source_partitions || [] }),
        });
        alert("鏍″鍐呭宸蹭繚瀛樸€?);
        window.location.reload();
      } catch (error) {
        alert(`淇濆瓨澶辫触: ${error.message}`);
      }
    }

    async function confirmNextStep() {
      try {
        const payload = { ...readControls(), selected_story_uid: selectedStoryUid, selected_story_uids: Array.from(selectedStoryUids) };
        if (selectedStoryUids.size > 1) {
          await fetchJson("/api/source/confirm-batch", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
          alert(`宸叉壒閲忕‘璁?${selectedStoryUids.size} 涓晠浜嬨€俙);
        } else {
          const result = await fetchJson("/api/source/confirm", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...payload, auto_start_next: true }) });
          if (result.next_job) {
            alert("宸茬‘璁ゅ苟鑷姩鍚姩 Director_Engine銆?);
          } else {
            alert("宸茬‘璁わ紝Director_Engine 宸插噯澶囧氨缁€?);
          }
        }
        window.location.reload();
      } catch (error) {
        alert(`纭澶辫触: ${error.message}`);
      }
    }

    async function resetSource() {
      if (!window.confirm("纭畾鎿﹂櫎褰撳墠閲囬泦缁撴灉骞堕噸缃涓€闃舵鍚楋紵")) return;
      if (!window.confirm("浜屾纭锛氭摝闄ゅ悗闇€瑕侀噸鏂伴噰闆嗭紝鏄惁缁х画锛?)) return;
      try {
        await fetchJson("/api/source/reset", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...readControls(), confirmed: true }) });
        window.location.reload();
      } catch (error) {
        alert(`鎿﹂櫎澶辫触: ${error.message}`);
      }
    }

    function bindFileTray() {
      const fileInput = el("file-input");
      const pickButton = el("pick-file-button");
      const dropzone = el("file-dropzone");
      if (!fileInput || !pickButton || !dropzone) return;
      pickButton.addEventListener("click", () => fileInput.click());
      fileInput.addEventListener("change", () => {
        const file = fileInput.files?.[0];
        if (file) uploadSelectedFile(file);
      });
      dropzone.addEventListener("dragover", (event) => { event.preventDefault(); dropzone.classList.add("dragover"); });
      dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
      dropzone.addEventListener("drop", (event) => {
        event.preventDefault();
        dropzone.classList.remove("dragover");
        const file = event.dataTransfer?.files?.[0];
        if (file) uploadSelectedFile(file);
      });
    }

    function renderLogs() {
      const logs = dashboard.logs || [];
      const compact = el("log-compact");
      const full = el("log-full");
      const recent = logs.slice(0, 3);
      compact.innerHTML = recent.map((x) => `<div class="progress-float__item"><strong>${escapeHtml(x.module_name || "绯荤粺")}</strong><p>${escapeHtml(x.message || "")}</p></div>`).join("") || "<p>鏆傛棤鏃ュ織</p>";
      full.innerHTML = logs.map((x) => `<div class="progress-float__item"><strong>${escapeHtml(x.module_name || "绯荤粺")} 路 ${escapeHtml(x.status || "")}</strong><p>${escapeHtml(x.message || "")}</p></div>`).join("") || "<p>鏆傛棤鏃ュ織</p>";
    }

    function setLogState() {
      const panel = el("log-panel");
      const content = el("log-content");
      const toggle = el("toggle-log-button");
      const compact = el("log-compact");
      const full = el("log-full");
      const detailBtn = el("expand-log-detail");
      if (!panel || !content || !toggle || !compact || !full || !detailBtn) return;
      panel.classList.toggle("collapsed", !logOpen);
      content.style.display = logOpen ? "block" : "none";
      toggle.textContent = logOpen ? "鈻? : "鈼€";
      toggle.title = logOpen ? "闅愯棌鏃ュ織" : "灞曞紑鏃ュ織";
      full.style.display = logDetailOpen ? "block" : "none";
      compact.style.display = logDetailOpen ? "none" : "block";
      detailBtn.textContent = logDetailOpen ? "鏀惰捣璇︽儏" : "灞曞紑璇︽儏";
    }

    function toggleLogPanel() {
      logOpen = !logOpen;
      if (!logOpen) logDetailOpen = false;
      setLogState();
    }

    function toggleLogDetail() {
      logDetailOpen = !logDetailOpen;
      setLogState();
    }

    function init() {
      const stage1View = el("stage1-view");
      const stage2View = el("stage2-view");
      const isStage1 = currentStage === "Source_Ingester";
      if (stage1View) stage1View.style.display = isStage1 ? "" : "none";
      if (stage2View) stage2View.style.display = isStage1 ? "none" : "";

      buildTrack();
      if (isStage1) {
        renderTree();
        renderPreview();
        renderStatus();
        bindFileTray();
      } else {
        const job = dashboard.job || {};
        const statusNode = el("director-job-status");
        if (statusNode) statusNode.textContent = job.status || "running";
      }
      renderLogs();
      setLogState();
      el("extract-button")?.addEventListener("click", extractAndClean);
      el("save-proofread-button")?.addEventListener("click", saveProofread);
      el("confirm-next-button")?.addEventListener("click", confirmNextStep);
      el("reset-button")?.addEventListener("click", resetSource);
      el("reload-button")?.addEventListener("click", () => window.location.reload());
      el("go-stage1-button")?.addEventListener("click", () => {
        if (stage1View) stage1View.style.display = "";
        if (stage2View) stage2View.style.display = "none";
      });
      el("toggle-log-button")?.addEventListener("click", toggleLogPanel);
      el("hide-log-button")?.addEventListener("click", toggleLogPanel);
      el("expand-log-detail")?.addEventListener("click", toggleLogDetail);
    }
    init();
  
