# GEMINI_HANDOVER

## Current System Snapshot

MOVAI is an episode-first 2.5D cinematic production pipeline built around strict JSON contracts, resumable orchestration, and staged human review.

Current real modules:
1. `Source_Ingester`
2. `Director_Engine`

Current scaffolded modules:
1. `Writer_Engine`
2. `Audio_Anchor_Forge`
3. `Visual_Asset_Foundry`
4. `Render_Engine`
5. `Global_Distributor`
6. `Master_Hub`

The orchestration layer already supports:
1. Manifest-driven state transitions
2. Review gates
3. Resumability
4. Pre-flight dependency checks
5. Pydantic input validation
6. Output verification

## Core Directory Layout

- `F:\scd\movai\src\movai`
  Runtime package, modules, web app, LLM client
- `F:\scd\movai\src\schemas`
  Installable Pydantic contracts and enums
- `F:\scd\movai\data\staged\<episode_id>`
  Stage outputs for each episode
- `F:\scd\movai\data\final\<episode_id>\manifest.json`
  Central run state
- `F:\scd\movai\reports\<episode_id>`
  Module reports

## Data Flow

### 1. Source_Ingester

Input:
- local TXT or public-domain URL

Output:
- `raw_source.json`

Responsibilities:
- read source text
- cleanse boilerplate/noise
- partition by chapter/volume heuristics
- chunk partitions into `RawTextChunk`

### 2. Director_Engine

Input:
- `raw_source.json`

Output:
- `project_bible.json`
- `beat_sheet.json`

Responsibilities:
- build style matrix
- infer stable entity anchors
- produce episode beat plan
- use OpenAI-compatible LLM when configured
- fallback to deterministic heuristics when no LLM is configured or validation fails

### 3. Master_Hub

Input:
- project/episode/run context
- staged files from upstream modules

Output:
- `manifest.json`
- stage reports

Responsibilities:
- enforce dependency graph
- validate upstream JSON with Pydantic before stage execution
- verify outputs after stage execution
- stop and resume at review gates

### 4. Web UI

Routes:
- `GET /`
- `POST /run/source`
- `POST /run/director`
- `POST /api/approve`
- `GET /api/raw-source/{episode_id}`
- `GET /api/director/{episode_id}`

Responsibilities:
- run Module 1 and Module 2
- display editable JSON for review
- write approved Bible/BeatSheet back to disk
- clear `manifest.review_gate_pending`
- advance `manifest.current_stage` to `Writer_Engine`

## LLM Integration

File:
- `F:\scd\movai\src\movai\llm_client.py`

Environment variables:
- `MOVAI_LLM_BASE_URL`
- `MOVAI_LLM_API_KEY`
- `MOVAI_LLM_MODEL`

Compatible with OpenAI-style `/chat/completions` APIs.

Key behavior:
- sends prompt with JSON-only instructions
- parses returned content
- retries automatically when:
  - content is not valid JSON
  - content does not match the target Pydantic model
- feeds validation error text back into the next retry turn

## Contract Highlights

Project-scoped immutable asset:
- `ProjectBible`

Episode-scoped contracts:
- `BeatSheet`
- `StateLedger`
- `MasterScript`
- `TimedScript`
- `Manifest`
- `ModuleReport`

Important identifiers:
- `project_id`
- `episode_id`
- `run_id`

## What Gemini Should Know Next

Highest-value next implementation targets:
1. Turn `Writer_Engine` into a real sliding-window scene generator
2. Add a proper `EpisodeContext` or recap object for cross-episode carry-over
3. Upgrade Web UI with save/run/approve timeline controls
4. Unify duplicated `schemas` directory ownership if needed
5. Add stronger text language detection in `Source_Ingester`
6. Add a richer LLM plan prompt for beat pacing and entity extraction

## Pseudo-Documentary Narrator Prompt Recommendation

Use this as the core style prompt for Gemini:

```text
You are the narrative director for a pseudo-documentary science-fiction horror adaptation pipeline.

Your narration must feel like recovered observational footage being analyzed by a calm, highly trained field archivist.
Do not speak like an omniscient novelist.
Do not explain emotions directly unless they are inferable from evidence.
Do not use sentimental, lyrical, or melodramatic language.

Voice rules:
- observational, forensic, restrained
- describe what can be seen, heard, measured, inferred, or logged
- tension should come from anomalies, contradictions, and incomplete evidence
- prefer concrete signals over abstract fear
- every line should feel camera-adjacent or sensor-adjacent
- maintain dread through understatement

World rules:
- preserve continuity of character identity and world physics
- threats emerge through evidence trails, sound signatures, damaged environments, radar anomalies, procedural logs, and visual inconsistencies
- avoid cartoon villain language or exaggerated horror clich?s

Output rules:
- return strict JSON only
- keep entity anchors stable
- generate beats that escalate through observation, discovery, pressure, and irreversible reveal
```

## Prompt Addendum For Director Planning

```text
Generate a project bible and beat sheet for one episode.
The project bible must define immutable world rules, stable entity IDs, locked visual prompt fragments, and voice mapping hints.
The beat sheet must contain 3 to 8 beats with escalating tension, objective clarity, and episode-local continuity.
Every beat should be filmable, not abstract.
If uncertain, choose specificity over vagueness.
```

## Prompt Addendum For Writer Stage

```text
You are writing scenes for a pseudo-documentary observer.
Only use the current ledger, the last three scenes, the current beat, and approved global anchors.
Narration should report evidence, not inner monologue.
Dialogue should be sparse, pressured, and situational.
Visual prompts must rely on stable entity IDs and scene action, not rewritten character identity.
```
