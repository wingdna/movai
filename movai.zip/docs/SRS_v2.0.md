# Software Requirements Specification

## Project

`MOVAI - "Phantom Scroll" Episodic 2.5D Cinematic Production Pipeline`

## Version

`v2.0`

## Date

`2026-03-24`

## 1. Purpose

This document defines the software requirements for a modular production pipeline that adapts source literature into episodic 2.5D cinematic video content. Version 2.0 extends the system to support ultra-long source texts, episode-based rolling production, and decoupled cloud rendering workflows for compute-intensive stages.

## 2. Scope

The system covers the following workflow:

1. Source text ingestion from public websites or local files
2. Hierarchical partitioning of long-form source text into volumes, ranges, and chunks
3. Episode-scoped creative adaptation into a project bible and beat sheet
4. Scene-by-scene script generation with rolling state management and cross-episode continuity
5. Audio generation and audio-anchored timing calculation
6. Visual asset generation and depth map production in local or cloud execution modes
7. 2.5D scene rendering and final Chinese master composition in local or cloud execution modes
8. Multilingual packaging and publishing
9. Central orchestration with review gates, resumable execution, and payload packaging

The system does not initially require:

1. Real-time collaboration
2. Multi-user auth
3. Full cloud-native orchestration services
4. Autonomous publishing without human review

## 3. Product Goals

The product shall:

1. Convert long-form narrative inputs into reproducible, episode-based audio-visual production runs.
2. Minimize LLM drift through strong schemas, immutable anchor assets, and bounded working context.
3. Keep each module independently executable and replaceable.
4. Allow human review at major quality gates.
5. Support reruns, partial recovery, output traceability, and asynchronous cloud execution.

## 4. Architectural Style

### 4.1 Design Pattern

The system shall follow a local microservice-inspired architecture in which modules are independently executable programs that exchange data through JSON contracts, media files, manifests, and execution reports on disk.

### 4.2 Communication Model

Modules shall not directly depend on each other's internal functions as a hard integration requirement. The primary integration contract shall be:

1. Versioned JSON files
2. Local or packaged media assets
3. Execution reports
4. A manifest-driven state machine

### 4.3 Core Timing Principle

The final duration of each scene shall be anchored to generated audio duration. Video generation must conform to measured audio timing, not estimated text timing.

### 4.4 Review Gate Principle

The orchestrator shall pause execution at predefined milestones and require explicit human approval before continuing.

### 4.5 Episodic Production Model

The system shall support episodic production for ultra-long source material. A single source work may be partitioned into multiple episodes, each with its own planning, script, timing, and render lifecycle, while inheriting approved global anchors from the same project.

The architecture shall distinguish between:

1. Project scope
   Shared immutable assets, style rules, and long-lived entity anchors.
2. Episode scope
   A bounded production unit under a shared `project_id`, identified by `episode_id`.

### 4.6 Compute Decoupling & Payload Packaging

The system shall support decoupled execution for compute-intensive stages.

Modules with heavy compute requirements, especially `Visual_Asset_Foundry` and `Render_Engine`, shall support:

1. `execution_mode = local`
2. `execution_mode = cloud`

When `execution_mode = cloud`, the pipeline shall package all required downstream inputs into a portable payload so that cloud execution can run independently from the local authoring environment.

## 5. Core Data Principles

### 5.1 Immutable Assets

Immutable assets shall include:

1. World rules
2. Character identity anchors
3. Locked visual prompt fragments
4. Voice assignment defaults
5. Style matrix

These assets shall be stored in `project_bible.json` and treated as read-only after approval. `project_bible.json` remains project-scoped and shall not require `episode_id`.

### 5.2 Mutable State

Mutable state shall include:

1. Character condition
2. Inventory
3. Scene location
4. Threat level
5. Time cursor
6. Cross-episode carry-over summaries

These assets shall be stored in `state_ledger.json` and updated after each scene or beat.

### 5.3 Strong Typing

All machine-readable contracts shall be validated with Pydantic models. The implementation should reject malformed or out-of-schema data before passing it to downstream modules.

### 5.4 Pointer Composition

Scene records shall reference entities by ID. Visual prompt assembly shall be performed in code by combining scene-level action descriptions with locked descriptors from `project_bible.json`.

### 5.5 Episode Identity

All episode-scoped contracts shall include:

1. `episode_id: str`

The `episode_id` field identifies the current production unit under a shared `project_id`.

## 6. System Inputs and Outputs

### 6.1 Supported Primary Inputs

The system shall accept:

1. Public-domain source URLs
2. Local `TXT` files
3. Local `EPUB` files
4. Style configuration parameters
5. Episode planning parameters
6. Local or cloud execution mode configuration
7. Manual operator approvals at review gates

### 6.2 Primary Outputs

The system shall produce:

1. Structured JSON contracts
2. Audio files
3. Render images and depth maps
4. Final MP4 renders
5. Poster and subtitle assets
6. Upload-ready platform packages
7. `render_payload.zip` for cloud-executable render workflows

## 7. Functional Requirements by Module

### 7.1 Module 1: Source_Ingester

#### Purpose

Acquire and normalize input text.

#### Inputs

1. Source URL or local file path
2. Optional chapter range or page range
3. Optional parser configuration
4. Optional partitioning strategy

#### Processing Requirements

The module shall:

1. Fetch source content from supported websites or local files.
2. Remove boilerplate, HTML tags, redundant whitespace, and unrelated site notices.
3. Split long text into hierarchical source partitions, including volume-level, range-level, or section-level partitions when configured.
4. Split each partition into logical chunks of approximately 2000 Chinese characters or equivalent length.
5. Preserve source metadata including title, author, and chapter labels when available.

#### Outputs

The module shall produce `raw_source.json`.

#### Acceptance Criteria

1. Output must contain clean text blocks with source metadata.
2. Output must validate against the `RawSource` schema.
3. Empty or malformed sections must be excluded or flagged in a report.
4. Partition boundaries must be explicitly represented when configured.

### 7.2 Module 2: Director_Engine

#### Purpose

Generate project-level creative rules and episode-scoped structural adaptation plans.

#### Inputs

1. `raw_source.json`
2. Style profile parameters
3. System prompt templates
4. Current `episode_id`
5. Optional prior episode continuity summary

#### Processing Requirements

The module shall:

1. Call the configured LLM to produce a world adaptation aligned to the target style.
2. Generate or reuse a locked character visual dictionary in `project_bible.json`.
3. Generate an episode-scoped beat sheet containing high-level scene intent, emotional direction, and task decomposition.
4. Support streaming planning for long-form source text, allowing the system to plan `EP_01`, `EP_02`, and later episodes incrementally from approved source partitions.
5. Read project-level immutable anchors and optional carry-over state from the previous episode when continuity is required.
6. Enforce strict JSON output validation with retries on invalid responses.

#### Outputs

The module shall produce:

1. `project_bible.json`
2. `beat_sheet.json`

#### Acceptance Criteria

1. Output must contain stable entity IDs and visual locks.
2. Beat sheet items must be sequential and complete.
3. Output must validate against `ProjectBible` and `BeatSheet` schemas.
4. Episode planning must not require the full historical novel text in a single prompt.

### 7.3 Module 3: Writer_Engine

#### Purpose

Expand beat-level structure into an episode-scoped scene script with production annotations.

#### Inputs

1. `project_bible.json`
2. `beat_sheet.json`
3. `state_ledger.json` or initial empty episode state
4. Optional previous-episode carry-over summary

#### Processing Requirements

The module shall:

1. Use a sliding window context strategy that includes:
   - Fixed system prompt
   - Relevant global anchors
   - Current mutable state
   - Last three scene outputs
   - Current target beat
2. Generate narration, dialogue, and scene action in structured form.
3. Assign `entity_ids` instead of inlining full appearance descriptions.
4. Generate scene-level SFX and VFX tags.
5. Update `state_ledger.json` after each scene.
6. Update `production_ledger.json` with generation status.
7. Preserve continuity across episodes without requiring the full prior script in context.

#### Outputs

The module shall produce:

1. `master_script.json`
2. Updated `state_ledger.json`
3. Updated `production_ledger.json`

#### Acceptance Criteria

1. Each scene must reference beat lineage.
2. Scene objects must validate against schema.
3. State updates must be sequential and recoverable.
4. Episode-scoped continuity fields must be preserved.

### 7.4 Module 4: Audio_Anchor_Forge

#### Purpose

Generate audio assets, compute authoritative scene durations, and prepare cloud-ready render payloads when configured.

#### Inputs

1. `master_script.json`
2. TTS voice mapping from `project_bible.json`
3. Optional sound effect API credentials
4. Optional `execution_mode` for downstream rendering

#### Processing Requirements

The module shall:

1. Generate narration and dialogue audio per scene.
2. Resolve SFX tags into downloadable or local sound assets.
3. Measure precise audio durations in milliseconds.
4. Backfill duration data into a timed script contract.
5. Save generated files with deterministic naming.
6. When downstream rendering is configured for cloud execution, package a `render_payload.zip` containing at minimum:
   - `timed_script.json`
   - `artifacts/audio/`
   - any required render configuration files
   - relative-path-normalized references only

#### Outputs

The module shall produce:

1. `artifacts/audio/*`
2. `timed_script.json`
3. `render_payload.zip` when cloud rendering is enabled

#### Acceptance Criteria

1. All referenced audio files must exist.
2. Duration fields must be numeric and non-negative.
3. Scene duration must equal or exceed the mixed audio duration for that scene.
4. Cloud payload references must not contain workstation-specific absolute paths.

### 7.5 Module 5: Visual_Asset_Foundry

#### Purpose

Generate still images, depth maps, and poster source art.

#### Inputs

1. `timed_script.json`
2. `project_bible.json`
3. Image model configuration
4. `execution_mode: local | cloud`

#### Processing Requirements

The module shall:

1. Construct final prompts from scene actions plus immutable entity prompt locks.
2. Generate scene RGB images.
3. Retry on API rate limits and transient failures.
4. Generate a depth map for each RGB image.
5. Generate a poster source image from a chosen climax scene or poster prompt.
6. In cloud mode, operate entirely from the unpacked payload and declared runtime dependencies.

#### Outputs

The module shall produce:

1. `artifacts/visuals/*_rgb.png`
2. `artifacts/visuals/*_depth.png`
3. `artifacts/posters/raw_poster.png`

#### Acceptance Criteria

1. Each scene requiring a visual must have both RGB and depth outputs.
2. Failed scenes must be reported with retry counts.
3. Output file references must be written back to the relevant scene records or report file.
4. In cloud mode, the module must not require access to the original local workspace.

### 7.6 Module 6: Render_Engine

#### Purpose

Render 2.5D motion video from still images and depth maps, then composite synchronized audio.

#### Inputs

1. `timed_script.json`
2. Audio artifacts
3. RGB images
4. Depth maps
5. Optional overlay VFX assets
6. `execution_mode: local | cloud`

#### Processing Requirements

The module shall:

1. Convert each scene into a timed motion clip using depth-informed parallax or camera motion.
2. Respect scene durations from `timed_script.json`.
3. Overlay VFX masks or effects according to scene metadata.
4. Mix narration, dialogue, and SFX into aligned scene audio.
5. Concatenate scenes into the final Chinese master render.
6. In cloud mode, execute entirely from the unpacked payload plus produced visual outputs.

#### Outputs

The module shall produce `final_render_zh.mp4`.

#### Acceptance Criteria

1. Final render duration must match aggregate scene timing within implementation tolerance.
2. No scene may render shorter than its measured audio duration.
3. Missing required assets must fail validation before final render begins.
4. In cloud mode, the module shall be executable in isolation after payload extraction.

### 7.7 Module 7: Global_Distributor

#### Purpose

Create multilingual derivative assets and upload-ready platform packages.

#### Inputs

1. `final_render_zh.mp4`
2. `timed_script.json`
3. `raw_poster.png`
4. Platform credentials and metadata templates
5. Optional `episode_id`

#### Processing Requirements

The module shall:

1. Translate subtitle and dialogue content into target languages.
2. Generate multilingual subtitle files.
3. Generate multilingual audio tracks when configured.
4. Produce text-overlaid poster variants.
5. Upload packaged outputs to YouTube or another configured platform using official APIs.

#### Outputs

The module shall produce:

1. Localized subtitle files
2. Localized audio tracks
3. Poster variants
4. Upload report including final platform URL when available

#### Acceptance Criteria

1. Upload attempts must produce a success or failure report.
2. Localized asset file names must be deterministic.
3. Subtitle timing must align with the timed script.

### 7.8 Module 8: Master_Hub

#### Purpose

Coordinate execution, validation, review pauses, recovery, episode-aware orchestration, and operator interaction.

#### Inputs

1. Project configuration
2. `episode_id`
3. Module enablement flags
4. Force-rerun options
5. Operator approval input
6. Local or cloud execution mode configuration

#### Processing Requirements

The module shall:

1. Execute modules in configured sequence.
2. Maintain a manifest-driven state machine in `manifest.json`.
3. Resume from the last successful stage when rerun.
4. Stop at the following review gates:
   - Gate 1: After `project_bible.json` and `beat_sheet.json`
   - Gate 2: After script, audio, and visuals are generated
   - Gate 3: After `final_render_zh.mp4` is generated
5. Announce review steps via CLI and optional TTS.
6. Validate required inputs before each stage begins.
7. Record episode identity, execution mode, payload status, and cloud-return state in the manifest.

#### Outputs

The module shall produce:

1. Execution logs
2. `manifest.json`
3. Module report files
4. Review-gate status transitions

#### Acceptance Criteria

1. Operator must be able to stop after any gate and resume later.
2. Failed stages must not silently continue downstream.
3. The current pipeline state must be visible from `manifest.json`.
4. Episode-scoped runs must be restartable without corrupting other episodes.

## 8. Data Contracts

### 8.1 Contract Requirements

Every JSON contract shall include:

1. `schema_version`
2. `project_id`
3. `run_id`
4. `created_at`
5. `source_hash` when applicable

Every episode-scoped contract shall additionally include:

1. `episode_id`

### 8.2 Minimum Contract Set

The initial implementation shall define schemas for:

1. `RawSource`
2. `SourcePartition`
3. `ProjectBible`
4. `BeatSheet`
5. `StateLedger`
6. `SceneScript`
7. `MasterScript`
8. `TimedScript`
9. `Manifest`
10. `ModuleReport`
11. `RenderPayloadManifest`

### 8.3 Example: Project Bible

```json
{
  "schema_version": "2.0",
  "project_id": "YN_SciFi_001",
  "run_id": "run_20260324_001",
  "style_matrix": {
    "visual_lut": "cyberpunk_horror",
    "narrator_voice_id": "zh-CN-YunzeNeural"
  },
  "entities": {
    "CHAR_WANG_01": {
      "name": "???",
      "visual_prompt_lock": "silver-grey mechanical suit #SF-012, purple scar on left cheek, exhausted face",
      "audio_tts_id": "zh-CN-YunxiNeural"
    }
  }
}
```

### 8.4 Example: Episode Beat Sheet

```json
{
  "schema_version": "2.0",
  "project_id": "YN_SciFi_001",
  "episode_id": "EP_01",
  "run_id": "run_20260324_001",
  "beats": [
    {
      "beat_id": "EP01_B_001",
      "episode_id": "EP_01",
      "sequence_no": 1,
      "summary": "The observer detects an impossible signal near the market ruins.",
      "objective": "Introduce the threat.",
      "mood": "Tension"
    }
  ]
}
```

### 8.5 Example: State Ledger

```json
{
  "schema_version": "2.0",
  "project_id": "YN_SciFi_001",
  "episode_id": "EP_01",
  "run_id": "run_20260324_001",
  "current_time_ms": 124500,
  "episode_time_ms": 124500,
  "active_scene": "SCENE_004",
  "inherited_from_episode_id": null,
  "entity_states": {
    "CHAR_WANG_01": {
      "sanity_level": 45,
      "inventory": ["broken_helmet"],
      "posture": "kneeling"
    }
  },
  "environment_state": {
    "location": "Mars_Market_Zone_B",
    "threat_level": "High"
  }
}
```

### 8.6 Example: Render Payload Manifest

```json
{
  "schema_version": "2.0",
  "project_id": "YN_SciFi_001",
  "episode_id": "EP_01",
  "run_id": "run_20260324_001",
  "execution_mode": "cloud",
  "payload_file": "render_payload.zip",
  "root_dir": "payload/",
  "included_files": [
    "timed_script.json",
    "artifacts/audio/nar_S001.wav"
  ]
}
```

## 9. Context Management Requirements

### 9.1 Sliding Window Policy

The script-writing engine shall not ingest the full historical script for every generation step. It shall use a bounded context packet containing:

1. Fixed system prompt
2. Relevant global anchors for active entities
3. Current mutable state
4. Last three scenes
5. Current target beat
6. Optional previous-episode carry-over summary

### 9.2 Token Efficiency

The implementation should keep scene-generation prompts compact and avoid redundant visual description payloads when those can be reconstructed by entity ID.

## 10. Validation and Error Handling

### 10.1 Validation

Each module shall validate:

1. Presence of required upstream inputs
2. JSON schema compliance
3. File existence for referenced media assets
4. Reportable status outcome
5. Episode identity consistency across scoped contracts

### 10.2 Retries

The system should support retries for:

1. LLM format failures
2. Rate-limited media API calls
3. Transient network failures

Retries should be bounded and logged.

### 10.3 Module Reports

Each module shall emit a machine-readable report containing:

1. `module_name`
2. `status`
3. `started_at`
4. `finished_at`
5. `retry_count`
6. `error_message`
7. `output_files`
8. `episode_id` when the run is episode-scoped
9. `execution_mode` when relevant

## 11. Recovery and Idempotency

### 11.1 Resumability

The system shall support restarting from the last successful checkpoint without rerunning all upstream modules.

### 11.2 Snapshotting

The implementation should store scene-level or beat-level state snapshots in addition to the latest `state_ledger.json`.

### 11.3 Deterministic Output Naming

Generated file names should be deterministic so the system can safely detect existing outputs and skip unnecessary regeneration.

### 11.4 Review-Gate Resumption

If execution stops at a review gate, the next `Master_Hub` run shall load `manifest.json`, detect the pending gate, and continue only after explicit operator approval.

## 12. Human Review Requirements

### 12.1 Review Gate 1

The operator shall review:

1. `project_bible.json`
2. `beat_sheet.json`

### 12.2 Review Gate 2

The operator shall review:

1. `master_script.json`
2. Generated audio assets
3. Generated visual assets

The operator may manually replace assets using the same file names before resuming.

### 12.3 Review Gate 3

The operator shall review `final_render_zh.mp4` and explicitly confirm whether globalization and upload should proceed.

### 12.4 Review Presentation

The system should offer a human-friendly representation of machine contracts for review, preferably as:

1. YAML
2. Markdown tables
3. Simple summary dashboards

## 13. Non-Functional Requirements

### 13.1 Reliability

The system shall fail loudly on schema errors, missing files, and invalid intermediate outputs.

### 13.2 Maintainability

Each module shall be independently testable and should expose a clear CLI entry point.

### 13.3 Portability

The primary development target is Python 3.10+ on a local workstation environment, while cloud-executable stages shall remain portable across hosted notebook environments such as Kaggle and Colab.

### 13.4 Observability

The system shall write logs, reports, and a current manifest sufficient to diagnose failed runs.

### 13.5 Performance

The system should optimize for recoverability and consistency over raw throughput. Batching is desirable, but not at the cost of opaque failures.

### 13.6 Distributed Async Compute Support

The system shall support distributed asynchronous execution through:

1. Compressed payload transfer
2. Shared cloud storage mounts such as Google Drive
3. Delayed return of generated artifacts from cloud environments such as Kaggle or Colab

## 14. Out of Scope for v2.0

The following are explicitly out of scope for this release:

1. Real-time collaborative editing
2. Fine-grained user permission systems
3. Fully managed cloud job orchestration services
4. Automatic quality scoring by multimodal evaluators
5. Fully autonomous publishing without review gates

## 15. Recommended Implementation Roadmap

### Phase 1

1. Define schemas
2. Create sample contracts
3. Implement validation utilities
4. Build `Master_Hub` CLI skeleton

### Phase 2

1. Implement episodic `Director_Engine`
2. Implement episodic `Writer_Engine`
3. Implement `Audio_Anchor_Forge`
4. Verify timing loop and payload packaging

### Phase 3

1. Implement `Visual_Asset_Foundry`
2. Implement `Render_Engine`
3. Test local and cloud render pathways

### Phase 4

1. Implement `Global_Distributor`
2. Add multilingual packaging
3. Add upload automation

## 16. Acceptance Summary

The system shall be considered compliant with this SRS when:

1. All module outputs validate against versioned schemas.
2. The orchestration layer can pause and resume at defined review gates.
3. A complete sample episode can be processed from source ingestion to final Chinese render.
4. The final render duration is controlled by measured audio timing.
5. Immutable and mutable data remain cleanly separated throughout execution.
6. Cloud-executable render stages can run from a packaged payload without dependence on the original local workspace.
