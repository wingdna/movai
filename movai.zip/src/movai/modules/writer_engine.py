from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel, Field
from schemas import (
    AudioTrack,
    BeatSheet,
    CameraMove,
    DialogueLine,
    EntityState,
    EnvironmentState,
    MasterScript,
    ModuleName,
    Mood,
    ProductionLedger,
    ProjectBible,
    SceneProgress,
    SceneScript,
    SceneStatus,
    StateLedger,
    ThreatLevel,
    TrackType,
    VisualRenderPlan,
)

from ..context import ModuleContext
from ..llm_client import LLMClient, LLMClientError
from ..module_base import ModuleSpec, ScaffoldModule


class WriterSceneDraft(BaseModel):
    scene_summary: str
    action_description: str
    narration_text: str
    camera_move: CameraMove
    dialogue: list[DialogueLine] = Field(default_factory=list)
    vfx_layers: list[str] = Field(default_factory=list)
    visual_base_prompt: str
    poster_candidate: bool = False
    state_update_notes: str | None = None
    environment_location: str | None = None
    threat_level: ThreatLevel = ThreatLevel.MEDIUM
    posture_by_entity: dict[str, str] = Field(default_factory=dict)


class WriterEngineModule(ScaffoldModule):
    spec = ModuleSpec(
        key="writer-engine",
        module_name=ModuleName.WRITER_ENGINE,
        description="Expand beats into structured scenes and rolling state updates.",
        default_output_subdir="writer_engine",
    )

    def build_template_payloads(self, ctx: ModuleContext) -> dict[str, object]:
        return {}

    def build_warnings(self) -> list[str]:
        return []

    def generate_outputs(self, ctx: ModuleContext) -> tuple[MasterScript, StateLedger, ProductionLedger]:
        project_bible = self.load_project_bible(ctx)
        beat_sheet = self.load_beat_sheet(ctx)

        scenes: list[SceneScript] = []
        scene_progress: list[SceneProgress] = []
        entity_states = {
            entity_id: EntityState(
                health_level=72 if idx == 0 else 80,
                sanity_level=58 if idx == 0 else 70,
                location="Unresolved",
                posture="standing",
                inventory=[],
                notes=entity.core_personality,
            )
            for idx, (entity_id, entity) in enumerate(project_bible.entities.items())
        }
        environment_state = EnvironmentState(location="Unknown", threat_level=ThreatLevel.MEDIUM, atmosphere="unresolved")

        previous_scenes: list[SceneScript] = []
        for beat in beat_sheet.beats:
            draft = self.generate_scene_draft(ctx, project_bible, beat_sheet, beat, previous_scenes, entity_states, environment_state)
            scene_id = f"{ctx.episode_id}_S_{beat.sequence_no:03d}"
            character_ids = beat.characters_present or list(project_bible.entities.keys())[:1]
            narration = draft.narration_text.strip()
            dialogue = draft.dialogue
            audio_tracks = [AudioTrack(type=TrackType.NARRATOR, text=narration)]
            for line in dialogue:
                audio_tracks.append(AudioTrack(type=TrackType.DIALOGUE, character_id=line.character_id, text=line.text))
            audio_tracks.append(AudioTrack(type=TrackType.SFX, tags=self.infer_sfx_tags(beat.mood, draft.action_description)))

            scene = SceneScript(
                scene_id=scene_id,
                episode_id=ctx.episode_id,
                beat_id=beat.beat_id,
                sequence_no=beat.sequence_no,
                status=SceneStatus.DRAFT,
                scene_summary=draft.scene_summary,
                action_description=draft.action_description,
                camera_move=draft.camera_move,
                narration_text=narration,
                dialogue=dialogue,
                vfx_layers=draft.vfx_layers,
                audio_tracks=audio_tracks,
                visual_render=VisualRenderPlan(
                    base_prompt=draft.visual_base_prompt,
                    entity_ids=character_ids,
                    poster_candidate=draft.poster_candidate,
                ),
                duration_ms=beat.estimated_duration_ms,
            )
            scenes.append(scene)
            previous_scenes = (previous_scenes + [scene])[-3:]
            self.apply_state_update(entity_states, environment_state, scene, draft, character_ids)
            scene_progress.append(
                SceneProgress(
                    scene_id=scene.scene_id,
                    episode_id=ctx.episode_id,
                    status=SceneStatus.DRAFT,
                    updated_at=datetime.now(timezone.utc),
                    notes=draft.state_update_notes or beat.objective,
                )
            )

        master_script = MasterScript(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            scenes=scenes,
        )
        final_scene = scenes[-1]
        state_ledger = StateLedger(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            current_time_ms=sum(scene.duration_ms or 0 for scene in scenes),
            episode_time_ms=sum(scene.duration_ms or 0 for scene in scenes),
            active_scene=final_scene.scene_id,
            last_completed_beat=final_scene.beat_id,
            snapshot_id=f"{ctx.episode_id}_snapshot_{len(scenes):03d}",
            inherited_from_episode_id=beat_sheet.inherited_from_episode_id,
            carry_over_summary=scenes[-1].scene_summary,
            entity_states=entity_states,
            environment_state=environment_state,
        )
        production_ledger = ProductionLedger(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            active_scene=final_scene.scene_id,
            current_stage=ModuleName.WRITER_ENGINE,
            scene_statuses=scene_progress,
        )
        return master_script, state_ledger, production_ledger

    def load_project_bible(self, ctx: ModuleContext) -> ProjectBible:
        path = ctx.workspace / "data" / "staged" / ctx.episode_id / "director_engine" / "project_bible.json"
        return ProjectBible.model_validate_json(path.read_text(encoding="utf-8"))

    def load_beat_sheet(self, ctx: ModuleContext) -> BeatSheet:
        path = ctx.workspace / "data" / "staged" / ctx.episode_id / "director_engine" / "beat_sheet.json"
        return BeatSheet.model_validate_json(path.read_text(encoding="utf-8"))

    def generate_scene_draft(
        self,
        ctx: ModuleContext,
        project_bible: ProjectBible,
        beat_sheet: BeatSheet,
        beat,
        previous_scenes: list[SceneScript],
        entity_states: dict[str, EntityState],
        environment_state: EnvironmentState,
    ) -> WriterSceneDraft:
        llm_draft = self.try_generate_with_llm(ctx, project_bible, beat_sheet, beat, previous_scenes, entity_states, environment_state)
        if llm_draft is not None:
            return llm_draft
        raise RuntimeError("Writer_Engine requires a configured LLM and did not receive a valid draft.")

    def try_generate_with_llm(
        self,
        ctx: ModuleContext,
        project_bible: ProjectBible,
        beat_sheet: BeatSheet,
        beat,
        previous_scenes: list[SceneScript],
        entity_states: dict[str, EntityState],
        environment_state: EnvironmentState,
    ) -> WriterSceneDraft:
        client = LLMClient.from_env(profile="writer")
        if client is None:
            raise RuntimeError("Writer_Engine requires a configured writer LLM profile.")
        prompt = self.build_llm_prompt(project_bible, beat_sheet, beat, previous_scenes, entity_states, environment_state)
        try:
            return client.call_with_schema(
                prompt=prompt,
                response_model=WriterSceneDraft,
                system_prompt=self.build_system_prompt(),
                temperature=0.35,
            )
        except LLMClientError as exc:
            raise RuntimeError(f"Writer_Engine LLM generation failed: {exc}") from exc

    def build_system_prompt(self) -> str:
        return (
            "You are the Writer_Engine for a pseudo-documentary cinematic pipeline.\n"
            "Write one scene draft at a time from structured beat data.\n"
            "Return strict JSON only.\n"
            "Narration must be observational, forensic, and camera-adjacent.\n"
            "Do not write omniscient internal monologue.\n"
            "Dialogue must be sparse, pressured, and situational.\n"
            "Visual prompts must be concrete and filmable.\n"
        )

    def build_llm_prompt(
        self,
        project_bible: ProjectBible,
        beat_sheet: BeatSheet,
        beat,
        previous_scenes: list[SceneScript],
        entity_states: dict[str, EntityState],
        environment_state: EnvironmentState,
    ) -> str:
        last_scenes = [
            {
                "scene_id": scene.scene_id,
                "summary": scene.scene_summary,
                "narration_text": scene.narration_text,
                "action_description": scene.action_description,
            }
            for scene in previous_scenes[-3:]
        ]
        active_entities = {
            entity_id: {
                "name": project_bible.entities[entity_id].name,
                "core_personality": project_bible.entities[entity_id].core_personality,
                "visual_prompt_lock": project_bible.entities[entity_id].visual_prompt_lock,
                "state": entity_states.get(entity_id).model_dump(mode="json") if entity_id in entity_states else {},
            }
            for entity_id in beat.characters_present
            if entity_id in project_bible.entities
        }
        return (
            f"Episode ID: {beat_sheet.episode_id}\n"
            f"Style Matrix: {project_bible.style_matrix.model_dump(mode='json')}\n"
            f"World Rules: {project_bible.world_rules}\n"
            f"Current Beat: {beat.model_dump(mode='json')}\n"
            f"Active Entities: {active_entities}\n"
            f"Environment State: {environment_state.model_dump(mode='json')}\n"
            f"Last Scenes: {last_scenes}\n"
            "Generate a single scene draft JSON with narration, action, sparse dialogue, visual base prompt, "
            "and state update hints. Preserve continuity and escalation."
        )

    def generate_fallback_scene(
        self,
        beat,
        project_bible: ProjectBible,
        previous_scenes: list[SceneScript],
        entity_states: dict[str, EntityState],
        environment_state: EnvironmentState,
    ) -> WriterSceneDraft:
        entity_ids = beat.characters_present or list(project_bible.entities.keys())[:1]
        lead_id = entity_ids[0]
        lead = project_bible.entities[lead_id]
        location = environment_state.location or "the contaminated perimeter"
        previous_clause = (
            f" After the previous scene, evidence still points toward {previous_scenes[-1].scene_summary.lower()}."
            if previous_scenes
            else ""
        )
        narration = (
            f"{lead.name} enters {location}. Instruments show a {beat.mood.value.lower()} pattern surrounding the objective."
            f"{previous_clause}"
        )
        action = (
            f"{lead.name} studies the environment, following the pressure of {beat.summary.lower()} "
            f"while the camera records surface detail, damaged structures, and unstable signal reflections."
        )
        dialogue = [
            DialogueLine(
                character_id=lead_id,
                text=self.dialogue_for_mood(lead.name, beat.mood),
                emotion=beat.mood,
            )
        ]
        return WriterSceneDraft(
            scene_summary=beat.summary,
            action_description=action,
            narration_text=narration,
            camera_move=self.camera_for_mood(beat.mood),
            dialogue=dialogue,
            vfx_layers=self.vfx_for_mood(beat.mood),
            visual_base_prompt=self.visual_prompt_for_scene(beat, project_bible, entity_ids),
            poster_candidate=beat.sequence_no == len(entity_ids) or beat.mood in {Mood.HORROR, Mood.ACTION},
            state_update_notes=beat.objective,
            environment_location=location if location != "Unknown" else self.infer_location_from_summary(beat.summary),
            threat_level=self.threat_for_mood(beat.mood),
            posture_by_entity={entity_id: self.posture_for_mood(beat.mood) for entity_id in entity_ids},
        )

    def apply_state_update(
        self,
        entity_states: dict[str, EntityState],
        environment_state: EnvironmentState,
        scene: SceneScript,
        draft: WriterSceneDraft,
        character_ids: list[str],
    ) -> None:
        environment_state.location = draft.environment_location or environment_state.location or self.infer_location_from_summary(scene.scene_summary)
        environment_state.threat_level = draft.threat_level
        environment_state.atmosphere = scene.action_description[:120]
        for entity_id in character_ids:
            state = entity_states.setdefault(entity_id, EntityState())
            state.location = environment_state.location
            state.posture = draft.posture_by_entity.get(entity_id, self.posture_for_mood(scene.dialogue[0].emotion if scene.dialogue and scene.dialogue[0].emotion else Mood.TENSION))
            if state.sanity_level is None:
                state.sanity_level = 70
            if state.health_level is None:
                state.health_level = 80
            state.sanity_level = max(0, state.sanity_level - self.sanity_cost(environment_state.threat_level))
            state.notes = draft.state_update_notes or state.notes

    def infer_sfx_tags(self, mood: Mood, action_description: str) -> list[str]:
        tags = ["room_tone", "low_frequency_drone"]
        lower = action_description.lower()
        if mood == Mood.HORROR or "signal" in lower:
            tags.append("metallic_echo")
        if mood == Mood.ACTION:
            tags.append("impact_rumble")
        if mood == Mood.TENSION:
            tags.append("heartbeat")
        return tags

    def dialogue_for_mood(self, name: str, mood: Mood) -> str:
        if mood == Mood.HORROR:
            return "That shape was not here a second ago."
        if mood == Mood.ACTION:
            return "Move. We lose the angle if we hesitate."
        if mood == Mood.TENSION:
            return "The reading is wrong, but it keeps getting closer."
        return f"{name} confirms the site is still active."

    def camera_for_mood(self, mood: Mood) -> CameraMove:
        mapping = {
            Mood.CALM: CameraMove.STATIC,
            Mood.TENSION: CameraMove.Z_DOLLY_IN_SLOW,
            Mood.HORROR: CameraMove.HANDHELD_DRIFT,
            Mood.ACTION: CameraMove.PAN_RIGHT,
        }
        return mapping[mood]

    def vfx_for_mood(self, mood: Mood) -> list[str]:
        if mood == Mood.HORROR:
            return ["Film_Grain", "Glitch_Light"]
        if mood == Mood.ACTION:
            return ["Impact_Shake", "Dust_Burst"]
        if mood == Mood.TENSION:
            return ["Scanline_Flicker"]
        return ["Soft_Grain"]

    def visual_prompt_for_scene(self, beat, project_bible: ProjectBible, entity_ids: list[str]) -> str:
        character_locks = [project_bible.entities[entity_id].visual_prompt_lock for entity_id in entity_ids if entity_id in project_bible.entities]
        joined = "; ".join(character_locks)
        return f"{beat.summary}, pseudo-documentary framing, environmental evidence, {joined}"

    def infer_location_from_summary(self, summary: str) -> str:
        lower = summary.lower()
        if "market" in lower:
            return "market ruins"
        if "dome" in lower:
            return "collapsed dome interior"
        if "corridor" in lower:
            return "service corridor"
        return "an unstable observation zone"

    def threat_for_mood(self, mood: Mood) -> ThreatLevel:
        mapping = {
            Mood.CALM: ThreatLevel.LOW,
            Mood.TENSION: ThreatLevel.HIGH,
            Mood.HORROR: ThreatLevel.CRITICAL,
            Mood.ACTION: ThreatLevel.CRITICAL,
        }
        return mapping[mood]

    def posture_for_mood(self, mood: Mood) -> str:
        mapping = {
            Mood.CALM: "standing",
            Mood.TENSION: "cautious",
            Mood.HORROR: "staggering",
            Mood.ACTION: "running",
        }
        return mapping[mood]

    def sanity_cost(self, threat: ThreatLevel) -> int:
        mapping = {
            ThreatLevel.LOW: 1,
            ThreatLevel.MEDIUM: 3,
            ThreatLevel.HIGH: 6,
            ThreatLevel.CRITICAL: 10,
        }
        return mapping[threat]
