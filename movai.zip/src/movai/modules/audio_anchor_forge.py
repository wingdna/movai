from __future__ import annotations

import asyncio
import io
import math
import wave
import zipfile
from pathlib import Path

import edge_tts
from pydub import AudioSegment
from schemas import (
    ExecutionMode,
    MasterScript,
    ModuleName,
    ProjectBible,
    RenderPayloadManifest,
    ResolvedVisualRenderPlan,
    TimedAudioTrack,
    TimedSceneScript,
    TimedScript,
    TrackType,
)

from ..config import get_tts_settings
from ..context import ModuleContext
from ..module_base import ModuleSpec, ScaffoldModule
from ..tts_voice_registry import choose_narrator_voice, choose_voice_for_entity, list_mandarin_voices, voice_catalog_payload


class AudioAnchorForgeModule(ScaffoldModule):
    spec = ModuleSpec(
        key="audio-anchor-forge",
        module_name=ModuleName.AUDIO_ANCHOR_FORGE,
        description="Generate TTS/SFX assets and backfill authoritative durations.",
        default_output_subdir="audio_anchor_forge",
    )

    def build_template_payloads(self, ctx: ModuleContext) -> dict[str, object]:
        scene_id = f"{ctx.episode_id}_S_001"
        return {
            "timed_script.template.json": TimedScript(
                project_id=ctx.project_id,
                episode_id=ctx.episode_id,
                run_id=ctx.run_id,
                total_duration_ms=4200,
                execution_mode=ctx.execution_mode,
                scenes=[
                    TimedSceneScript(
                        scene_id=scene_id,
                        episode_id=ctx.episode_id,
                        beat_id=f"{ctx.episode_id}_B_001",
                        sequence_no=1,
                        scene_summary="Example timed scene",
                        action_description="A placeholder scene for timing.",
                        camera_move="Z_Dolly_In_Slow",
                        narration_text="Example narration.",
                        audio_tracks=[
                            TimedAudioTrack(
                                type=TrackType.NARRATOR,
                                text="Example narration.",
                                file_path=f"artifacts/audio/{scene_id}_narrator.wav",
                                duration_ms=2200,
                            ),
                            TimedAudioTrack(
                                type=TrackType.SFX,
                                tags=["low_frequency_drone"],
                                file_path=f"artifacts/audio/{scene_id}_sfx_01.wav",
                                duration_ms=4200,
                            ),
                        ],
                        visual_render=ResolvedVisualRenderPlan(
                            base_prompt="example scene",
                            entity_ids=["CHAR_EXAMPLE_01"],
                            image_path=f"artifacts/visuals/{scene_id}_rgb.png",
                            depth_path=f"artifacts/visuals/{scene_id}_depth.png",
                        ),
                        duration_ms=4200,
                    )
                ],
            )
        }

    def generate_outputs(
        self, ctx: ModuleContext
    ) -> tuple[TimedScript, dict[str, bytes], RenderPayloadManifest | None, bytes | None]:
        master_script = self.load_master_script(ctx)
        project_bible = self.load_project_bible(ctx)
        output_dir = self.resolve_output_dir(ctx)

        timed_scenes: list[TimedSceneScript] = []
        binary_outputs: dict[str, bytes] = {}

        for scene in master_script.scenes:
            timed_tracks: list[TimedAudioTrack] = []
            scene_max_duration = 0

            for index, track in enumerate(scene.audio_tracks, start=1):
                suffix = f"{scene.scene_id}_{track.type.value}_{index:02d}.wav"
                relative_path = Path("artifacts") / "audio" / suffix
                absolute_path = output_dir / relative_path

                if track.type in {TrackType.NARRATOR, TrackType.DIALOGUE}:
                    voice_id = self.resolve_voice_id(track, project_bible)
                    audio_bytes, duration_ms = self.generate_tts_audio(track.text or "", voice_id)
                else:
                    audio_bytes, duration_ms = self.generate_sfx_audio(track.tags, scene.duration_ms or 3000)

                binary_outputs[str(relative_path)] = audio_bytes
                scene_max_duration = max(scene_max_duration, duration_ms)
                timed_tracks.append(
                    TimedAudioTrack(
                        type=track.type,
                        text=track.text,
                        tags=track.tags,
                        character_id=track.character_id,
                        voice_id=self.resolve_voice_id(track, project_bible),
                        file_path=str(relative_path).replace("\\", "/"),
                        duration_ms=duration_ms,
                    )
                )

            timed_duration = max(scene.duration_ms or 0, scene_max_duration, 1200)
            timed_scenes.append(
                TimedSceneScript(
                    scene_id=scene.scene_id,
                    episode_id=scene.episode_id,
                    beat_id=scene.beat_id,
                    sequence_no=scene.sequence_no,
                    status=scene.status,
                    scene_summary=scene.scene_summary,
                    action_description=scene.action_description,
                    camera_move=scene.camera_move,
                    narration_text=scene.narration_text,
                    dialogue=scene.dialogue,
                    vfx_layers=scene.vfx_layers,
                    audio_tracks=timed_tracks,
                    visual_render=ResolvedVisualRenderPlan(
                        base_prompt=scene.visual_render.base_prompt,
                        entity_ids=scene.visual_render.entity_ids,
                        image_path=(scene.visual_render.image_path or f"artifacts/visuals/{scene.scene_id}_rgb.png"),
                        depth_path=(scene.visual_render.depth_path or f"artifacts/visuals/{scene.scene_id}_depth.png"),
                        poster_candidate=scene.visual_render.poster_candidate,
                    ),
                    duration_ms=timed_duration,
                )
            )

        timed_script = TimedScript(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            execution_mode=ctx.execution_mode,
            total_duration_ms=sum(scene.duration_ms for scene in timed_scenes),
            scenes=timed_scenes,
        )

        payload_manifest = None
        payload_zip = None
        if ctx.execution_mode == ExecutionMode.CLOUD:
            payload_manifest = RenderPayloadManifest(
                project_id=ctx.project_id,
                episode_id=ctx.episode_id,
                run_id=ctx.run_id,
                execution_mode=ExecutionMode.CLOUD,
                payload_file="render_payload.zip",
                root_dir="payload/",
                included_files=[
                    "timed_script.json",
                    *[path.replace("\\", "/") for path in binary_outputs.keys()],
                ],
            )
            payload_zip = self.build_render_payload_zip(timed_script, binary_outputs)

        return timed_script, binary_outputs, payload_manifest, payload_zip

    def load_master_script(self, ctx: ModuleContext) -> MasterScript:
        path = ctx.workspace / "data" / "staged" / ctx.episode_id / "writer_engine" / "master_script.json"
        return MasterScript.model_validate_json(path.read_text(encoding="utf-8"))

    def load_project_bible(self, ctx: ModuleContext) -> ProjectBible:
        path = ctx.workspace / "data" / "staged" / ctx.episode_id / "director_engine" / "project_bible.json"
        return ProjectBible.model_validate_json(path.read_text(encoding="utf-8"))

    def resolve_voice_id(self, track, project_bible: ProjectBible) -> str | None:
        available = {voice.short_name for voice in list_mandarin_voices()}
        if track.voice_id:
            return track.voice_id
        if track.character_id and track.character_id in project_bible.entities:
            assigned = project_bible.entities[track.character_id].audio_tts_id
            if assigned in available:
                return assigned
            return choose_voice_for_entity(
                track.character_id,
                project_bible.entities[track.character_id].role,
                {choose_narrator_voice()},
                choose_narrator_voice(),
            )
        if track.type == TrackType.NARRATOR:
            narrator = project_bible.style_matrix.narrator_voice_id
            return narrator if narrator in available else choose_narrator_voice()
        return None

    def generate_tts_audio(self, text: str, voice_id: str | None) -> tuple[bytes, int]:
        if not text.strip():
            audio = self.synthesize_tone(duration_ms=800, frequency=220.0, volume=0.05)
            return audio, self.measure_duration_ms(audio)

        tts_settings = get_tts_settings()
        try:
            audio = asyncio.run(self._edge_tts_bytes(text, voice_id or tts_settings.default_voice))
        except Exception:
            estimate = max(1200, min(9000, len(text) * 85))
            audio = self.synthesize_tone(duration_ms=estimate, frequency=440.0, volume=0.12)
        return audio, self.measure_duration_ms(audio)

    async def _edge_tts_bytes(self, text: str, voice_id: str) -> bytes:
        communicate = edge_tts.Communicate(text=text, voice=voice_id)
        buffer = io.BytesIO()
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                buffer.write(chunk["data"])
        raw_mp3 = buffer.getvalue()
        if not raw_mp3:
            raise RuntimeError("edge-tts returned no audio data")
        segment = AudioSegment.from_file(io.BytesIO(raw_mp3), format="mp3")
        wav_buffer = io.BytesIO()
        segment.export(wav_buffer, format="wav")
        return wav_buffer.getvalue()

    def generate_sfx_audio(self, tags: list[str], target_duration_ms: int) -> tuple[bytes, int]:
        frequency = 110.0
        if "heartbeat" in tags:
            frequency = 72.0
        elif "metallic_echo" in tags:
            frequency = 280.0
        elif "impact_rumble" in tags:
            frequency = 90.0
        audio = self.synthesize_tone(duration_ms=max(1000, target_duration_ms), frequency=frequency, volume=0.08)
        return audio, self.measure_duration_ms(audio)

    def synthesize_tone(self, duration_ms: int, frequency: float, volume: float) -> bytes:
        sample_rate = 24000
        frames = int(sample_rate * (duration_ms / 1000))
        amplitude = int(32767 * volume)
        buffer = io.BytesIO()
        with wave.open(buffer, "wb") as wav_file:
            wav_file.setnchannels(1)
            wav_file.setsampwidth(2)
            wav_file.setframerate(sample_rate)
            for i in range(frames):
                sample = int(amplitude * math.sin(2 * math.pi * frequency * (i / sample_rate)))
                wav_file.writeframesraw(sample.to_bytes(2, byteorder="little", signed=True))
        return buffer.getvalue()

    def measure_duration_ms(self, wav_bytes: bytes) -> int:
        with wave.open(io.BytesIO(wav_bytes), "rb") as wav_file:
            frames = wav_file.getnframes()
            rate = wav_file.getframerate()
            return int((frames / rate) * 1000)

    def build_render_payload_zip(self, timed_script: TimedScript, binary_outputs: dict[str, bytes]) -> bytes:
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("payload/timed_script.json", timed_script.model_dump_json(indent=2))
            for relative_path, audio_bytes in binary_outputs.items():
                archive.writestr(f"payload/{relative_path.replace('\\', '/')}", audio_bytes)
        return buffer.getvalue()
