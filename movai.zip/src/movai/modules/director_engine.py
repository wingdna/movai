from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field
from schemas import Beat, BeatSheet, EntityDefinition, ExecutionMode, ModuleName, ModuleReport, ModuleStatus, Mood, ProjectBible, RawSource, StyleMatrix

from ..context import ModuleContext
from ..io_utils import ensure_directory, write_payload
from ..llm_client import LLMClient, LLMClientError
from ..module_base import ExecutionResult, ModuleSpec, ScaffoldModule
from ..tts_voice_registry import choose_narrator_voice, choose_voice_for_entity, voice_catalog_payload

logger = logging.getLogger(__name__)

STYLE_PRESETS = {
    "mockumentary_alien_horror": {
        "visual_lut": "cyberpunk_horror",
        "narrator_voice_id": "zh-CN-YunzeNeural",
        "world_rules": [
            "Narration must remain observational and non-omniscient.",
            "The camera behaves like recovered documentary footage.",
            "Threats should be introduced through evidence, not omniscient exposition.",
        ],
        "character_suffix": "archival-survival suit, documentary lighting, gritty realism",
    },
    "retro_mystery": {
        "visual_lut": "amber_noir",
        "narrator_voice_id": "en-US-GuyNeural",
        "world_rules": [
            "Narration should feel investigative and restrained.",
            "Visual design favors practical light, smoke, and analog texture.",
        ],
        "character_suffix": "retro tailoring, smoky backlight, analog film grain",
    },
}

DEFAULT_STYLE = "mockumentary_alien_horror"
CLASSICAL_ENTITY_STOPWORDS = {
    "但见",
    "且说",
    "却说",
    "说道",
    "说时",
    "只见",
    "看官",
    "真人",
    "众人",
    "当下",
    "原来",
    "忽见",
    "便道",
    "诗曰",
    "话说",
}
FORBIDDEN_SUMMARY_TOKENS = {
    "但见",
    "且说",
    "却说",
    "诗曰",
    "话说",
    "曰：",
    "曰:",
    "兮",
}


class DirectorEntityCandidate(BaseModel):
    name: str = Field(min_length=1)
    role_hint: str | None = None
    evidence: str | None = None


class DirectorExtractionDraft(BaseModel):
    plain_summary_zh: str = Field(min_length=20, max_length=240)
    core_entities: list[DirectorEntityCandidate] = Field(min_length=1, max_length=12)
    continuity_notes: list[str] = Field(default_factory=list)


class DirectorProjectBibleDraft(BaseModel):
    style_matrix: StyleMatrix
    entities: dict[str, EntityDefinition] = Field(min_length=1)
    world_rules: list[str] = Field(default_factory=list)
    glossary: dict[str, str] = Field(default_factory=dict)


class DirectorBeatDraft(BaseModel):
    beat_id: str | None = None
    title: str | None = None
    summary: str
    objective: str
    mood: Mood
    characters_present: list[str] = Field(default_factory=list)
    estimated_duration_ms: int | None = Field(default=None, ge=0)


class DirectorBeatSheetDraft(BaseModel):
    inherited_from_episode_id: str | None = None
    beats: list[DirectorBeatDraft] = Field(min_length=1, max_length=8)


class DirectorLLMResponse(BaseModel):
    project_bible: DirectorProjectBibleDraft
    beat_sheet: DirectorBeatSheetDraft


class DirectorEngineModule(ScaffoldModule):
    spec = ModuleSpec(
        key="director-engine",
        module_name=ModuleName.DIRECTOR_ENGINE,
        description="Generate project bible and beat sheet from source text.",
        default_output_subdir="director_engine",
    )

    def build_warnings(self) -> list[str]:
        return []

    def build_template_payloads(self, ctx: ModuleContext) -> dict[str, object]:
        return {
            "project_bible.template.json": self._sample_project_bible(ctx),
            "beat_sheet.template.json": self._sample_beat_sheet(ctx),
        }

    def run(self, ctx: ModuleContext) -> ExecutionResult:
        """Override run method to avoid build_mock_outputs and use real generation."""
        logger.info(f"[Director_Engine] run() method called for episode {ctx.episode_id}")
        
        self._last_retry_count = 0
        started_at = datetime.now(timezone.utc)
        output_dir = self.resolve_output_dir(ctx)
        reports_dir = ctx.resolved_reports_dir()
        output_files: list[Path] = []
        template_files: list[Path] = []

        if not ctx.dry_run:
            ensure_directory(output_dir)
            ensure_directory(reports_dir)

        # Generate template files
        template_payloads = self.build_template_payloads(ctx) if ctx.emit_templates else {}
        if ctx.emit_templates:
            for file_name, payload in template_payloads.items():
                file_path = output_dir / file_name
                template_files.append(file_path)
                if not ctx.dry_run:
                    write_payload(file_path, payload, overwrite=ctx.force)
                    logger.info(f"[Director_Engine] Generated template: {file_path}")

        # Generate REAL outputs (not mock data)
        logger.info("[Director_Engine] Calling generate_outputs() for real asset generation")
        try:
            project_bible, beat_sheet = self.generate_outputs(ctx)
            
            # Write project_bible.json
            bible_path = output_dir / "project_bible.json"
            output_files.append(bible_path)
            if not ctx.dry_run:
                write_payload(bible_path, project_bible, overwrite=ctx.force)
                logger.info(f"[Director_Engine] Generated project_bible.json: {bible_path}")
            
            # Write beat_sheet.json
            beat_path = output_dir / "beat_sheet.json"
            output_files.append(beat_path)
            if not ctx.dry_run:
                write_payload(beat_path, beat_sheet, overwrite=ctx.force)
                logger.info(f"[Director_Engine] Generated beat_sheet.json: {beat_path}")
            
            # Write voice_catalog.json
            voice_catalog_path = output_dir / "voice_catalog.json"
            output_files.append(voice_catalog_path)
            if not ctx.dry_run:
                write_payload(voice_catalog_path, voice_catalog_payload(), overwrite=ctx.force)
                logger.info(f"[Director_Engine] Generated voice_catalog.json: {voice_catalog_path}")
                
        except Exception as exc:
            logger.error(f"[Director_Engine] generate_outputs() failed: {exc}", exc_info=True)
            raise  # Re-raise to fail loudly

        finished_at = datetime.now(timezone.utc)
        report = ModuleReport(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            module_name=self.spec.module_name,
            status=ModuleStatus.SUCCESS,
            started_at=started_at,
            finished_at=finished_at,
            retry_count=self.get_retry_count(),
            warnings=self.build_warnings(),
            output_files=[str(path) for path in [*template_files, *output_files]],
            execution_mode=ctx.execution_mode,
        )

        report_path = reports_dir / self.report_file_name(ctx)
        if not ctx.dry_run:
            write_payload(report_path, report, overwrite=ctx.force)
            logger.info(f"[Director_Engine] Generated report: {report_path}")

        return ExecutionResult(report_path=report_path, output_files=output_files, template_files=template_files)

    def generate_outputs(self, ctx: ModuleContext) -> tuple[ProjectBible, BeatSheet]:
        """Generate project bible and beat sheet with full error handling."""
        logger.info(f"[Director_Engine] Starting execution for episode {ctx.episode_id}")
        
        try:
            # Step 1: Load raw source
            logger.info("[Director_Engine] Loading raw_source.json")
            raw_source = self.load_raw_source(ctx)
            logger.info(f"[Director_Engine] Successfully loaded raw source: {raw_source.title}")
            
            # Step 2: Initialize LLM client
            logger.info("[Director_Engine] Initializing LLM client with 'director' profile")
            client = LLMClient.from_env(profile="director")
            if client is None:
                logger.error("[Director_Engine] LLM client initialization failed - no API key configured")
                raise RuntimeError(
                    "Director_Engine requires a configured director LLM profile. "
                    "Please fill MOVAI_OPENAI_COMPAT_API_KEY / MOVAI_SILICONFLOW_API_KEY and MOVAI_DIRECTOR_MODEL in .env."
                )
            logger.info(f"[Director_Engine] LLM client initialized: model={client.model}, timeout={client.timeout}s")

            # Step 3: Resolve style configuration
            style_config = self.resolve_style(ctx)
            logger.info(f"[Director_Engine] Style resolved: {ctx.style_label or DEFAULT_STYLE}")

            # Step 4: Extract entities and summary
            logger.info("[Director_Engine] Starting entity extraction and summary generation")
            extraction = self.extract_entities_and_summary(ctx, raw_source, style_config, client)
            logger.info(f"[Director_Engine] Extraction successful: {len(extraction.core_entities)} entities extracted")

            # Step 5: Map to outputs (project bible and beat sheet)
            logger.info("[Director_Engine] Mapping extraction to project bible and beat sheet")
            project_bible, beat_sheet = self.map_extraction_to_outputs(ctx, raw_source, style_config, extraction, client)
            logger.info(f"[Director_Engine] Output mapping successful: {len(project_bible.entities)} entities, {len(beat_sheet.beats)} beats")

            logger.info(f"[Director_Engine] Execution completed successfully for episode {ctx.episode_id}")
            return project_bible, beat_sheet
            
        except FileNotFoundError as exc:
            logger.error(f"[Director_Engine] File not found: {exc}")
            raise  # Re-raise to let MasterHub handle it
        except LLMClientError as exc:
            logger.error(f"[Director_Engine] LLM API error: {exc}")
            raise RuntimeError(f"Director_Engine LLM call failed: {exc}") from exc
        except Exception as exc:
            logger.error(f"[Director_Engine] Unexpected error during execution: {exc}", exc_info=True)
            raise RuntimeError(f"Director_Engine failed: {exc}") from exc

    def extract_entities_and_summary(
        self,
        ctx: ModuleContext,
        raw_source: RawSource,
        style_config: dict[str, Any],
        client: LLMClient,
    ) -> DirectorExtractionDraft:
        response = client.call_with_schema(
            prompt=self.build_extraction_prompt(ctx, raw_source),
            response_model=DirectorExtractionDraft,
            system_prompt=self.build_extraction_system_prompt(style_config),
            temperature=0.1,
        )
        clean_entities = self.normalize_extracted_entities(response.core_entities)
        clean_summary = self.validate_plain_summary(response.plain_summary_zh)
        return DirectorExtractionDraft(
            plain_summary_zh=clean_summary,
            core_entities=clean_entities,
            continuity_notes=response.continuity_notes,
        )

    def map_extraction_to_outputs(
        self,
        ctx: ModuleContext,
        raw_source: RawSource,
        style_config: dict[str, Any],
        extraction: DirectorExtractionDraft,
        client: LLMClient,
    ) -> tuple[ProjectBible, BeatSheet]:
        response = client.call_with_schema(
            prompt=self.build_mapping_prompt(ctx, raw_source, style_config, extraction),
            response_model=DirectorLLMResponse,
            system_prompt=self.build_mapping_system_prompt(style_config),
            temperature=0.25,
        )

        project_bible = self.normalize_project_bible(ctx, style_config, response.project_bible)
        beat_sheet = self.normalize_beat_sheet(ctx, raw_source, extraction, project_bible, response.beat_sheet)
        return project_bible, beat_sheet

    def load_raw_source(self, ctx: ModuleContext) -> RawSource:
        source_path = self.workspace_source_path(ctx)
        if not source_path.exists():
            raise FileNotFoundError(
                f"Director_Engine requires raw_source.json, but it was not found: {source_path}"
            )
        return RawSource.model_validate_json(source_path.read_text(encoding="utf-8"))

    def workspace_source_path(self, ctx: ModuleContext) -> Path:
        return ctx.workspace / "data" / "staged" / ctx.episode_id / "source_ingester" / "raw_source.json"

    def resolve_style(self, ctx: ModuleContext) -> dict[str, object]:
        style_label = (ctx.style_label or DEFAULT_STYLE).strip()
        return STYLE_PRESETS.get(style_label, STYLE_PRESETS[DEFAULT_STYLE])

    def build_extraction_system_prompt(self, style_config: dict[str, Any]) -> str:
        return (
            "You are Stage 1 of Director_Engine: entity purification and narrative dehydration.\n"
            "Read classical or archaic Chinese source excerpts and extract only REAL entities and a plain-language digest.\n"
            "CRITICAL RULES:\n"
            "- Extract actual people, titles, organizations, or supernatural entities only.\n"
            "- NEVER treat connective phrases as names. Forbidden examples: 但见, 且说, 却说, 说道, 只见, 诗曰, 话说.\n"
            "- plain_summary_zh must be modern, plain Chinese, around 200 characters.\n"
            "- plain_summary_zh must summarize what happens, not quote the original text.\n"
            "- Do not include poetry, classical quotations, or copied archaic lines.\n"
            f"- Keep in mind the later target style is {style_config['visual_lut']} with pseudo-documentary restraint.\n"
        )

    def build_extraction_prompt(self, ctx: ModuleContext, raw_source: RawSource) -> str:
        return (
            f"Project ID: {ctx.project_id}\n"
            f"Episode ID: {ctx.episode_id}\n"
            f"Source title: {raw_source.title}\n"
            f"Source author: {raw_source.author or 'Unknown'}\n"
            f"Source excerpt:\n{self.build_source_excerpt(raw_source, char_budget=14000)}\n\n"
            "Task:\n"
            "1. Identify the true entities in this chapter.\n"
            "2. Remove classical connective noise and fake names.\n"
            "3. Produce a plain modern-Chinese summary of the chapter's core events in about 200 characters.\n"
            "4. continuity_notes may mention carry-over hooks for the next episode if relevant.\n"
        )

    def build_mapping_system_prompt(self, style_config: dict[str, Any]) -> str:
        return (
            "You are Stage 2 of Director_Engine: isomorphic adaptation and JSON assembly.\n"
            "You will receive clean entities and a modern Chinese digest, then produce project_bible and beat_sheet.\n"
            "CRITICAL RULES:\n"
            "- beat summary MUST be a SCI-FI / cyber-horror adaptation of the source events.\n"
            "- beat summary MUST NOT contain original classical Chinese sentences, poems, or copied source wording.\n"
            "- visual_prompt_lock MUST be PURE ENGLISH and detailed enough for image generation.\n"
            "- visual_prompt_lock should describe clothing, silhouette, age cues, materials, scars, cybernetic details, lighting cues.\n"
            "- Narration tone is pseudo-documentary, observational, forensic, restrained, and evidence-driven.\n"
            "- project_bible is project-scoped immutable law; beat_sheet is episode-scoped structure.\n"
            "- Entity IDs must begin with CHAR_ and remain machine-friendly.\n"
            f"- Preferred style preset visual LUT: {style_config['visual_lut']}.\n"
            f"- Preferred narrator voice: {style_config['narrator_voice_id']}.\n"
        )

    def build_mapping_prompt(
        self,
        ctx: ModuleContext,
        raw_source: RawSource,
        style_config: dict[str, Any],
        extraction: DirectorExtractionDraft,
    ) -> str:
        entity_pool = [entity.model_dump(mode="json") for entity in extraction.core_entities]
        glossary_seed = {
            partition.partition_id: partition.label
            for partition in raw_source.source_partitions[:8]
            if partition.label
        }
        return (
            f"Project ID: {ctx.project_id}\n"
            f"Episode ID: {ctx.episode_id}\n"
            f"Style Label: {ctx.style_label or DEFAULT_STYLE}\n"
            f"Visual LUT: {ctx.visual_lut or style_config['visual_lut']}\n"
            f"Narrator Voice: {ctx.narrator_voice_id or style_config['narrator_voice_id']}\n"
            f"Clean entity pool: {json.dumps(entity_pool, ensure_ascii=False)}\n"
            f"Plain summary (modern Chinese): {extraction.plain_summary_zh}\n"
            f"Continuity notes: {json.dumps(extraction.continuity_notes, ensure_ascii=False)}\n"
            f"Source glossary seed: {json.dumps(glossary_seed, ensure_ascii=False)}\n\n"
            "Adapt the chapter into a pseudo-documentary cyber-horror episode.\n"
            "Produce:\n"
            "1. project_bible with stable entities and immutable world rules.\n"
            "2. beat_sheet with 3 to 6 beats.\n"
            "Each beat summary should describe the SCI-FI adaptation, not the original archaic prose.\n"
            "Use only the clean entity pool as the basis for major character naming.\n"
            "characters_present should list entity IDs, not raw names.\n"
        )

    def normalize_extracted_entities(
        self,
        entities: list[DirectorEntityCandidate],
    ) -> list[DirectorEntityCandidate]:
        cleaned: list[DirectorEntityCandidate] = []
        seen: set[str] = set()
        for entity in entities:
            name = self.sanitize_entity_name(entity.name)
            if not name or name in seen:
                continue
            seen.add(name)
            cleaned.append(
                DirectorEntityCandidate(
                    name=name,
                    role_hint=entity.role_hint,
                    evidence=entity.evidence,
                )
            )
        if not cleaned:
            raise RuntimeError("Director_Engine extraction produced no valid entities after purification.")
        return cleaned

    def sanitize_entity_name(self, value: str) -> str | None:
        candidate = re.sub(r"\s+", "", value or "")
        candidate = candidate.strip("，。、“”‘’：:；;,.!?()[]{}<>")
        if not candidate:
            return None
        if candidate in CLASSICAL_ENTITY_STOPWORDS:
            return None
        if len(candidate) <= 1:
            return None
        if re.fullmatch(r"[A-Za-z][A-Za-z0-9_ -]{1,40}", candidate):
            return candidate.strip()
        if not re.fullmatch(r"[\u4e00-\u9fff]{2,8}", candidate):
            return None
        return candidate

    def validate_plain_summary(self, summary: str) -> str:
        cleaned = re.sub(r"\s+", "", summary or "")
        if len(cleaned) < 20:
            raise RuntimeError("Director_Engine extraction summary is too short.")
        for token in FORBIDDEN_SUMMARY_TOKENS:
            if token in cleaned:
                raise RuntimeError(
                    f"Director_Engine extraction summary still contains forbidden classical token: {token}"
                )
        return summary.strip()

    def normalize_project_bible(
        self,
        ctx: ModuleContext,
        style_config: dict[str, Any],
        draft: DirectorProjectBibleDraft,
    ) -> ProjectBible:
        entities: dict[str, EntityDefinition] = {}
        used_ids: set[str] = set()
        narrator_voice = choose_narrator_voice()
        assigned_voices: set[str] = {narrator_voice}
        for index, (raw_entity_id, entity) in enumerate(draft.entities.items(), start=1):
            clean_name = self.sanitize_entity_name(entity.name)
            if not clean_name:
                raise RuntimeError(f"Director_Engine produced invalid entity name: {entity.name!r}")
            entity_id = raw_entity_id if raw_entity_id.startswith("CHAR_") else f"CHAR_{self.slug_token(clean_name)}_{index:02d}"
            while entity_id in used_ids:
                entity_id = f"{entity_id}_{index:02d}"
            used_ids.add(entity_id)
            self.ensure_visual_prompt_lock(entity.visual_prompt_lock, clean_name)
            role = entity.role or ("Primary Character" if index == 1 else "Supporting Character")
            assigned_voice = choose_voice_for_entity(entity_id, role, assigned_voices, narrator_voice)
            assigned_voices.add(assigned_voice)
            entities[entity_id] = EntityDefinition(
                name=clean_name,
                role=role,
                core_personality=entity.core_personality,
                visual_prompt_lock=entity.visual_prompt_lock.strip(),
                audio_tts_id=assigned_voice,
            )

        return ProjectBible(
            project_id=ctx.project_id,
            run_id=ctx.run_id,
            style_matrix=StyleMatrix(
                visual_lut=ctx.visual_lut or draft.style_matrix.visual_lut or style_config["visual_lut"],
                narrator_voice_id=ctx.narrator_voice_id or narrator_voice,
                style_label=ctx.style_label or draft.style_matrix.style_label or DEFAULT_STYLE,
                color_script=draft.style_matrix.color_script,
            ),
            entities=entities,
            world_rules=draft.world_rules,
            glossary=dict(draft.glossary or {}),
        )

    def normalize_beat_sheet(
        self,
        ctx: ModuleContext,
        raw_source: RawSource,
        extraction: DirectorExtractionDraft,
        project_bible: ProjectBible,
        draft: DirectorBeatSheetDraft,
    ) -> BeatSheet:
        name_to_id = {entity.name: entity_id for entity_id, entity in project_bible.entities.items()}
        source_excerpt = re.sub(r"\s+", "", self.build_source_excerpt(raw_source, char_budget=12000))
        beats: list[Beat] = []
        for index, beat in enumerate(draft.beats, start=1):
            summary = self.ensure_adapted_summary(beat.summary, source_excerpt)
            objective = beat.objective.strip()
            character_ids = self.normalize_character_refs(beat.characters_present, name_to_id)
            beats.append(
                Beat(
                    beat_id=beat.beat_id or f"{ctx.episode_id}_B_{index:03d}",
                    episode_id=ctx.episode_id,
                    sequence_no=index,
                    title=beat.title,
                    summary=summary,
                    objective=objective,
                    mood=beat.mood,
                    characters_present=character_ids,
                    estimated_duration_ms=beat.estimated_duration_ms,
                )
            )
        return BeatSheet(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            inherited_from_episode_id=draft.inherited_from_episode_id,
            beats=beats,
        )

    def normalize_character_refs(self, values: list[str], name_to_id: dict[str, str]) -> list[str]:
        resolved: list[str] = []
        for value in values:
            token = (value or "").strip()
            if not token:
                continue
            if token in name_to_id.values():
                resolved.append(token)
            elif token in name_to_id:
                resolved.append(name_to_id[token])
        deduped: list[str] = []
        for item in resolved:
            if item not in deduped:
                deduped.append(item)
        return deduped

    def ensure_visual_prompt_lock(self, prompt: str, entity_name: str) -> None:
        value = (prompt or "").strip()
        if not value:
            raise RuntimeError(f"Entity {entity_name} is missing visual_prompt_lock.")
        if not value.isascii():
            raise RuntimeError(
                f"Entity {entity_name} has non-English visual_prompt_lock. "
                "visual_prompt_lock must be pure English."
            )
        if len(value.split(",")) < 3:
            raise RuntimeError(
                f"Entity {entity_name} visual_prompt_lock is too vague. "
                "It must include clothing / material / visual traits."
            )

    def ensure_adapted_summary(self, summary: str, source_excerpt: str) -> str:
        cleaned = (summary or "").strip()
        collapsed = re.sub(r"\s+", "", cleaned)
        if len(collapsed) < 12:
            raise RuntimeError("Beat summary is too short.")
        for token in FORBIDDEN_SUMMARY_TOKENS:
            if token in collapsed:
                raise RuntimeError(
                    f"Beat summary contains forbidden classical token {token!r}. "
                    "Summary must be a sci-fi adaptation, not copied archaic prose."
                )
        if len(collapsed) >= 20 and collapsed in source_excerpt:
            raise RuntimeError(
                "Beat summary appears to copy raw source text directly. "
                "Summary must be a sci-fi adaptation, not quoted source text."
            )
        return cleaned

    def build_source_excerpt(self, raw_source: RawSource, char_budget: int = 12000) -> str:
        parts: list[str] = []
        remaining = char_budget
        for partition in raw_source.source_partitions:
            if remaining <= 0:
                break
            label = partition.label or partition.partition_id
            parts.append(f"\n# {label}\n")
            remaining -= len(label) + 4
            for chunk in partition.text_chunks:
                if remaining <= 0:
                    break
                text = (chunk.text or "").strip()
                if not text:
                    continue
                excerpt = text[:remaining]
                parts.append(excerpt)
                parts.append("\n")
                remaining -= len(excerpt) + 1
        return "".join(parts).strip()

    def slug_token(self, value: str) -> str:
        cleaned = re.sub(r"[^A-Za-z0-9\u4e00-\u9fff]+", "_", value.strip()).strip("_")
        if not cleaned:
            return "ENTITY"
        return cleaned.upper()

    def _sample_project_bible(self, ctx: ModuleContext) -> ProjectBible:
        style = self.resolve_style(ctx)
        return ProjectBible(
            project_id=ctx.project_id,
            run_id=ctx.run_id,
            style_matrix=StyleMatrix(
                visual_lut=ctx.visual_lut or style["visual_lut"],
                narrator_voice_id=ctx.narrator_voice_id or style["narrator_voice_id"],
                style_label=ctx.style_label or DEFAULT_STYLE,
            ),
            entities={
                "CHAR_WANG_01": EntityDefinition(
                    name="Wang Zifu",
                    role="Protagonist",
                    core_personality="skeptical but persistent",
                    visual_prompt_lock="silver-grey mechanical suit, purple scar on left cheek, exhausted face, documentary rim light",
                    audio_tts_id="zh-CN-YunxiNeural",
                )
            },
            world_rules=style["world_rules"],
        )

    def _sample_beat_sheet(self, ctx: ModuleContext) -> BeatSheet:
        return BeatSheet(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            beats=[
                Beat(
                    beat_id=f"{ctx.episode_id}_B_001",
                    episode_id=ctx.episode_id,
                    sequence_no=1,
                    title="Approach Signal",
                    summary="A recovery crew tracks an impossible signal beneath a quarantined ruin as documentary sensors begin to fail.",
                    objective="Introduce the anomaly and the lead investigator's risk.",
                    mood=Mood.TENSION,
                    characters_present=["CHAR_WANG_01"],
                    estimated_duration_ms=4200,
                )
            ],
        )
