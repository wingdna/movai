<<<<<<< F:/scd/movai/src/movai/modules/master_hub.py
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path

from pydantic import ValidationError

from schemas import (
    BeatSheet,
    ExecutionMode,
    Manifest,
    MasterScript,
    ModuleName,
    ModuleReport,
    ModuleStatus,
    ProductionLedger,
    ProjectBible,
    RawSource,
    RenderPayloadManifest,
    StageRecord,
    StateLedger,
    TimedScript,
)

from ..context import ModuleContext
from ..io_utils import ensure_directory, read_json, read_model, write_payload
from ..module_base import ExecutionResult, ModuleSpec, ScaffoldModule


REVIEW_GATE_MESSAGES = {
    1: "Please review project_bible.json and beat_sheet.json. Enter [y] to continue, [n] to exit:",
    2: "Please review master_script.json, audio outputs, and visual assets. Enter [y] to continue, [n] to exit:",
    3: "Please review final_render_zh.mp4. Enter [y] to continue, [n] to exit:",
}


class MasterHubModule(ScaffoldModule):
    spec = ModuleSpec(
        key="master-hub",
        module_name=ModuleName.MASTER_HUB,
        description="Create manifest scaffolds and orchestrate stage execution.",
        default_output_subdir="master_hub",
    )

    stage_order = [
        ModuleName.SOURCE_INGESTER,
        ModuleName.DIRECTOR_ENGINE,
        ModuleName.WRITER_ENGINE,
        ModuleName.AUDIO_ANCHOR_FORGE,
        ModuleName.VISUAL_ASSET_FOUNDRY,
        ModuleName.RENDER_ENGINE,
        ModuleName.GLOBAL_DISTRIBUTOR,
    ]

    gate_after = {
        ModuleName.DIRECTOR_ENGINE: 1,
        ModuleName.VISUAL_ASSET_FOUNDRY: 2,
        ModuleName.RENDER_ENGINE: 3,
    }

    stage_to_key = {
        ModuleName.SOURCE_INGESTER: "source-ingester",
        ModuleName.DIRECTOR_ENGINE: "director-engine",
        ModuleName.WRITER_ENGINE: "writer-engine",
        ModuleName.AUDIO_ANCHOR_FORGE: "audio-anchor-forge",
        ModuleName.VISUAL_ASSET_FOUNDRY: "visual-asset-foundry",
        ModuleName.RENDER_ENGINE: "render-engine",
        ModuleName.GLOBAL_DISTRIBUTOR: "global-distributor",
    }

    stage_output_specs = {
        ModuleName.SOURCE_INGESTER: [("raw_source.json", RawSource)],
        ModuleName.DIRECTOR_ENGINE: [("project_bible.json", ProjectBible), ("beat_sheet.json", BeatSheet)],
        ModuleName.WRITER_ENGINE: [
            ("master_script.json", MasterScript),
            ("state_ledger.json", StateLedger),
            ("production_ledger.json", ProductionLedger),
        ],
        ModuleName.AUDIO_ANCHOR_FORGE: [("timed_script.json", TimedScript)],
        ModuleName.VISUAL_ASSET_FOUNDRY: [
            ("artifacts/visuals/{episode_id}_S_001_rgb.png", None),
            ("artifacts/visuals/{episode_id}_S_001_depth.png", None),
            ("artifacts/posters/raw_poster.png", None),
        ],
        ModuleName.RENDER_ENGINE: [("final_render_zh.mp4", None)],
        ModuleName.GLOBAL_DISTRIBUTOR: [
            ("upload_report.json", None),
            ("artifacts/subtitles/subtitles_en.srt", None),
            ("artifacts/subtitles/subtitles_ja.srt", None),
        ],
    }

    def resolve_output_dir(self, ctx: ModuleContext) -> Path:
        if ctx.output_dir is not None:
            return ctx.output_dir
        return ctx.workspace / "data" / "final" / ctx.episode_id

    def manifest_path(self, ctx: ModuleContext) -> Path:
        return self.resolve_output_dir(ctx) / "manifest.json"

    def build_manifest(self, ctx: ModuleContext) -> Manifest:
        return Manifest(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            current_stage=self.stage_order[0],
            last_completed_stage=None,
            overall_status=ModuleStatus.PENDING,
            review_gate_pending=None,
            execution_mode=ctx.execution_mode,
            payload_path=None,
            payload_ready=False,
            awaiting_cloud_return=False,
            stages=[
                StageRecord(
                    stage_name=stage_name,
                    status=ModuleStatus.PENDING,
                    gate_after=self.gate_after.get(stage_name),
                )
                for stage_name in self.stage_order
            ],
        )

    def load_manifest(self, ctx: ModuleContext) -> Manifest:
        path = self.manifest_path(ctx)
        if not path.exists():
            return self.build_manifest(ctx)
        from ..io_utils import read_json as _read_json

        data = _read_json(path)
        try:
            manifest = Manifest.model_validate(data)
        except ValidationError as exc:
            raise RuntimeError(f"Failed to load manifest: {path}: {exc}") from exc
        return manifest

    def save_manifest(self, ctx: ModuleContext, manifest: Manifest) -> Path:
        path = self.manifest_path(ctx)
        ensure_directory(path.parent)
        write_payload(path, manifest, overwrite=True)
        return path

    def stage_record(self, manifest: Manifest, stage_name: ModuleName) -> StageRecord:
        for stage in manifest.stages:
            if stage.stage_name == stage_name:
                return stage
        raise KeyError(stage_name)

    def stage_output_dir(self, ctx: ModuleContext, stage_name: ModuleName) -> Path:
        from ..registry import build_registry

        registry = build_registry()
        module = registry[self.stage_to_key[stage_name]]
        return module.resolve_output_dir(ctx)

    def resolve_stage_outputs(self, ctx: ModuleContext, stage_name: ModuleName) -> list[tuple[Path, type[object] | None]]:
        output_dir = self.stage_output_dir(ctx, stage_name)
        resolved: list[tuple[Path, type[object] | None]] = []
        for relative_path, model_type in self.stage_output_specs.get(stage_name, []):
            resolved.append((output_dir / relative_path.format(episode_id=ctx.episode_id), model_type))
        if stage_name == ModuleName.AUDIO_ANCHOR_FORGE and ctx.execution_mode == ExecutionMode.CLOUD:
            resolved.append((output_dir / "render_payload.zip", None))
            resolved.append((output_dir / "render_payload_manifest.json", RenderPayloadManifest))
        return resolved

    def preflight_dependencies(self, ctx: ModuleContext, stage_name: ModuleName) -> list[Path]:
        dependency_map = {
            ModuleName.DIRECTOR_ENGINE: [ModuleName.SOURCE_INGESTER],
            ModuleName.WRITER_ENGINE: [ModuleName.DIRECTOR_ENGINE],
            ModuleName.AUDIO_ANCHOR_FORGE: [ModuleName.WRITER_ENGINE],
            ModuleName.VISUAL_ASSET_FOUNDRY: [ModuleName.AUDIO_ANCHOR_FORGE],
            ModuleName.RENDER_ENGINE: [ModuleName.AUDIO_ANCHOR_FORGE, ModuleName.VISUAL_ASSET_FOUNDRY],
            ModuleName.GLOBAL_DISTRIBUTOR: [ModuleName.RENDER_ENGINE, ModuleName.VISUAL_ASSET_FOUNDRY, ModuleName.AUDIO_ANCHOR_FORGE],
        }

        upstream_paths: list[Path] = []
        for dependency_stage in dependency_map.get(stage_name, []):
            for path, model_type in self.resolve_stage_outputs(ctx, dependency_stage):
                if not path.exists():
                    raise FileNotFoundError(
                        f"Pre-flight check failed for {stage_name.value}: missing upstream file {path}"
                    )
                if model_type is not None:
                    try:
                        read_model(path, model_type)
                    except Exception as exc:
                        raise RuntimeError(
                            f"Schema validation failed for upstream file {path} before {stage_name.value}: {exc}"
                        ) from exc
                upstream_paths.append(path)
        return upstream_paths

    def verify_stage_outputs(self, ctx: ModuleContext, stage_name: ModuleName) -> list[Path]:
        verified_paths: list[Path] = []
        for path, model_type in self.resolve_stage_outputs(ctx, stage_name):
            if not path.exists():
                raise FileNotFoundError(
                    f"Output verification failed for {stage_name.value}: expected file was not generated: {path}"
                )
            if model_type is not None:
                try:
                    read_model(path, model_type)
                except Exception as exc:
                    raise RuntimeError(
                        f"Output schema validation failed for {stage_name.value}: {path}: {exc}"
                    ) from exc
            verified_paths.append(path)
        return verified_paths

    def prompt_review_gate(self, gate_no: int) -> bool:
        print(f"========== [REVIEW GATE {gate_no}] ==========")
        response = input(f"{REVIEW_GATE_MESSAGES[gate_no]} ").strip().lower()
        return response == "y"

    def approve_pending_gate(self, ctx: ModuleContext, manifest: Manifest) -> tuple[Manifest, bool]:
        if manifest.review_gate_pending is None:
            return manifest, True

        if not ctx.prompt_review:
            manifest.overall_status = ModuleStatus.AWAITING_REVIEW
            self.save_manifest(ctx, manifest)
            return manifest, False

        approved = self.prompt_review_gate(manifest.review_gate_pending)
        if not approved:
            manifest.overall_status = ModuleStatus.AWAITING_REVIEW
            self.save_manifest(ctx, manifest)
            return manifest, False

        manifest.review_gate_pending = None
        manifest.overall_status = ModuleStatus.RUNNING
        self.save_manifest(ctx, manifest)
        return manifest, True

    def update_payload_state(self, manifest: Manifest, result: ExecutionResult) -> None:
        payload = next((path for path in result.output_files if path.name == "render_payload.zip"), None)
        if payload is not None:
            manifest.payload_ready = True
            manifest.payload_path = str(payload)
        elif manifest.execution_mode == ExecutionMode.CLOUD and manifest.payload_path is None:
            manifest.payload_ready = False

    def next_stage_after(self, stage_name: ModuleName) -> ModuleName | None:
        index = self.stage_order.index(stage_name)
        if index + 1 >= len(self.stage_order):
            return None
        return self.stage_order[index + 1]

    def run_stage(self, ctx: ModuleContext, stage_name: ModuleName) -> ExecutionResult:
        from ..registry import build_registry

        registry = build_registry()
        module = registry[self.stage_to_key[stage_name]]
        stage_ctx = replace(ctx, emit_templates=True, output_dir=None, force=True)
        return module.run(stage_ctx)

    def run(self, ctx: ModuleContext) -> ExecutionResult:
        started_at = datetime.now(timezone.utc)
        reports_dir = ctx.resolved_reports_dir()
        ensure_directory(reports_dir)

        manifest = self.load_manifest(ctx)
        manifest.execution_mode = ctx.execution_mode
        manifest.run_id = ctx.run_id
        manifest.project_id = ctx.project_id
        manifest.episode_id = ctx.episode_id
        manifest.overall_status = ModuleStatus.RUNNING if manifest.review_gate_pending is None else ModuleStatus.AWAITING_REVIEW
        self.save_manifest(ctx, manifest)

        manifest, may_continue = self.approve_pending_gate(ctx, manifest)
        if not may_continue:
            report = self._build_report(ctx, started_at, ModuleStatus.AWAITING_REVIEW, [self.manifest_path(ctx)])
            report_path = reports_dir / self.report_file_name(ctx)
            write_payload(report_path, report, overwrite=True)
            return ExecutionResult(report_path=report_path, output_files=[self.manifest_path(ctx)], template_files=[])

        for stage_name in self.stage_order:
            stage = self.stage_record(manifest, stage_name)
            if stage.status == ModuleStatus.SUCCESS:
                continue

            stage.status = ModuleStatus.RUNNING
            stage.started_at = datetime.now(timezone.utc)
            stage.error_message = None
            manifest.current_stage = stage_name
            manifest.overall_status = ModuleStatus.RUNNING
            self.save_manifest(ctx, manifest)

            try:
                stage.input_files = [str(path) for path in self.preflight_dependencies(ctx, stage_name)]
                result = self.run_stage(ctx, stage_name)
                verified_outputs = self.verify_stage_outputs(ctx, stage_name)
            except Exception as exc:  # pragma: no cover - defensive path for CLI execution
                stage.status = ModuleStatus.FAILED
                stage.finished_at = datetime.now(timezone.utc)
                stage.error_message = str(exc)
                manifest.current_stage = stage_name
                manifest.overall_status = ModuleStatus.FAILED
                self.save_manifest(ctx, manifest)
                raise RuntimeError(f"Stage {stage_name.value} failed: {exc}") from exc

            stage.status = ModuleStatus.SUCCESS
            stage.finished_at = datetime.now(timezone.utc)
            stage.output_files = [str(path) for path in verified_outputs] + [str(path) for path in result.template_files]
            stage.report_path = str(result.report_path)
            manifest.last_completed_stage = stage_name
            self.update_payload_state(manifest, result)

            next_stage = self.next_stage_after(stage_name)
            manifest.current_stage = next_stage

            gate_no = self.gate_after.get(stage_name)
            if gate_no is not None:
                manifest.review_gate_pending = gate_no
                manifest.overall_status = ModuleStatus.AWAITING_REVIEW
                self.save_manifest(ctx, manifest)

                if not ctx.prompt_review:
                    report = self._build_report(
                        ctx,
                        started_at,
                        ModuleStatus.AWAITING_REVIEW,
                        [self.manifest_path(ctx)],
                    )
                    report_path = reports_dir / self.report_file_name(ctx)
                    write_payload(report_path, report, overwrite=True)
                    return ExecutionResult(
                        report_path=report_path,
                        output_files=[self.manifest_path(ctx)],
                        template_files=[],
                    )

                approved = self.prompt_review_gate(gate_no)
                if not approved:
                    self.save_manifest(ctx, manifest)
                    report = self._build_report(ctx, started_at, ModuleStatus.AWAITING_REVIEW, [self.manifest_path(ctx)])
                    report_path = reports_dir / self.report_file_name(ctx)
                    write_payload(report_path, report, overwrite=True)
                    return ExecutionResult(report_path=report_path, output_files=[self.manifest_path(ctx)], template_files=[])

                manifest.review_gate_pending = None
                manifest.overall_status = ModuleStatus.RUNNING
                self.save_manifest(ctx, manifest)
            else:
                self.save_manifest(ctx, manifest)

        manifest.current_stage = None
        manifest.overall_status = ModuleStatus.SUCCESS
        manifest.review_gate_pending = None
        self.save_manifest(ctx, manifest)

        report = self._build_report(ctx, started_at, ModuleStatus.SUCCESS, [self.manifest_path(ctx)])
        report_path = reports_dir / self.report_file_name(ctx)
        write_payload(report_path, report, overwrite=True)
        return ExecutionResult(report_path=report_path, output_files=[self.manifest_path(ctx)], template_files=[])

    def _build_report(self, ctx: ModuleContext, started_at: datetime, status: ModuleStatus, outputs: list[Path]):
        finished_at = datetime.now(timezone.utc)
        return ModuleReport(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            module_name=self.spec.module_name,
            status=status,
            started_at=started_at,
            finished_at=finished_at,
            warnings=self.build_warnings(),
            output_files=[str(path) for path in outputs],
            execution_mode=ctx.execution_mode,
        )
=======
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path

from pydantic import ValidationError

from schemas import (
    BeatSheet,
    ExecutionMode,
    Manifest,
    MasterScript,
    ModuleName,
    ModuleReport,
    ModuleStatus,
    ProductionLedger,
    ProjectBible,
    RawSource,
    RenderPayloadManifest,
    StageRecord,
    StateLedger,
    TimedScript,
)

from ..context import ModuleContext
from ..io_utils import ensure_directory, read_json, read_model, write_payload
from ..module_base import ExecutionResult, ModuleSpec, ScaffoldModule


REVIEW_GATE_MESSAGES = {
    1: "Please review project_bible.json and beat_sheet.json. Enter [y] to continue, [n] to exit:",
    2: "Please review master_script.json, audio outputs, and visual assets. Enter [y] to continue, [n] to exit:",
    3: "Please review final_render_zh.mp4. Enter [y] to continue, [n] to exit:",
}


class MasterHubModule(ScaffoldModule):
    spec = ModuleSpec(
        key="master-hub",
        module_name=ModuleName.MASTER_HUB,
        description="Create manifest scaffolds and orchestrate stage execution.",
        default_output_subdir="master_hub",
    )

    stage_order = [
        ModuleName.SOURCE_INGESTER,
        ModuleName.DIRECTOR_ENGINE,
        ModuleName.WRITER_ENGINE,
        ModuleName.AUDIO_ANCHOR_FORGE,
        ModuleName.VISUAL_ASSET_FOUNDRY,
        ModuleName.RENDER_ENGINE,
        ModuleName.GLOBAL_DISTRIBUTOR,
    ]

    gate_after = {
        ModuleName.DIRECTOR_ENGINE: 1,
        ModuleName.VISUAL_ASSET_FOUNDRY: 2,
        ModuleName.RENDER_ENGINE: 3,
    }

    stage_to_key = {
        ModuleName.SOURCE_INGESTER: "source-ingester",
        ModuleName.DIRECTOR_ENGINE: "director-engine",
        ModuleName.WRITER_ENGINE: "writer-engine",
        ModuleName.AUDIO_ANCHOR_FORGE: "audio-anchor-forge",
        ModuleName.VISUAL_ASSET_FOUNDRY: "visual-asset-foundry",
        ModuleName.RENDER_ENGINE: "render-engine",
        ModuleName.GLOBAL_DISTRIBUTOR: "global-distributor",
    }

    stage_output_specs = {
        ModuleName.SOURCE_INGESTER: [("raw_source.json", RawSource)],
        ModuleName.DIRECTOR_ENGINE: [("project_bible.json", ProjectBible), ("beat_sheet.json", BeatSheet)],
        ModuleName.WRITER_ENGINE: [
            ("master_script.json", MasterScript),
            ("state_ledger.json", StateLedger),
            ("production_ledger.json", ProductionLedger),
        ],
        ModuleName.AUDIO_ANCHOR_FORGE: [("timed_script.json", TimedScript)],
        ModuleName.VISUAL_ASSET_FOUNDRY: [
            ("artifacts/visuals/{episode_id}_S_001_rgb.png", None),
            ("artifacts/visuals/{episode_id}_S_001_depth.png", None),
            ("artifacts/posters/raw_poster.png", None),
        ],
        ModuleName.RENDER_ENGINE: [("final_render_zh.mp4", None)],
        ModuleName.GLOBAL_DISTRIBUTOR: [
            ("upload_report.json", None),
            ("artifacts/subtitles/subtitles_en.srt", None),
            ("artifacts/subtitles/subtitles_ja.srt", None),
        ],
    }

    def resolve_output_dir(self, ctx: ModuleContext) -> Path:
        if ctx.output_dir is not None:
            return ctx.output_dir
        return ctx.workspace / "data" / "final" / ctx.episode_id

    def manifest_path(self, ctx: ModuleContext) -> Path:
        return self.resolve_output_dir(ctx) / "manifest.json"

    def build_manifest(self, ctx: ModuleContext) -> Manifest:
        return Manifest(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            current_stage=self.stage_order[0],
            last_completed_stage=None,
            overall_status=ModuleStatus.PENDING,
            review_gate_pending=None,
            execution_mode=ctx.execution_mode,
            payload_path=None,
            payload_ready=False,
            awaiting_cloud_return=False,
            stages=[
                StageRecord(
                    stage_name=stage_name,
                    status=ModuleStatus.PENDING,
                    gate_after=self.gate_after.get(stage_name),
                )
                for stage_name in self.stage_order
            ],
        )

    def load_manifest(self, ctx: ModuleContext) -> Manifest:
        path = self.manifest_path(ctx)
        if not path.exists():
            return self.build_manifest(ctx)
        from ..io_utils import read_json as _read_json

        data = _read_json(path)
        try:
            manifest = Manifest.model_validate(data)
        except ValidationError as exc:
            raise RuntimeError(f"Failed to load manifest: {path}: {exc}") from exc
        return manifest

    def save_manifest(self, ctx: ModuleContext, manifest: Manifest) -> Path:
        path = self.manifest_path(ctx)
        ensure_directory(path.parent)
        write_payload(path, manifest, overwrite=True)
        return path

    def stage_record(self, manifest: Manifest, stage_name: ModuleName) -> StageRecord:
        for stage in manifest.stages:
            if stage.stage_name == stage_name:
                return stage
        raise KeyError(stage_name)

    def stage_output_dir(self, ctx: ModuleContext, stage_name: ModuleName) -> Path:
        from ..registry import build_registry

        registry = build_registry()
        module = registry[self.stage_to_key[stage_name]]
        return module.resolve_output_dir(ctx)

    def resolve_stage_outputs(self, ctx: ModuleContext, stage_name: ModuleName) -> list[tuple[Path, type[object] | None]]:
        output_dir = self.stage_output_dir(ctx, stage_name)
        resolved: list[tuple[Path, type[object] | None]] = []
        for relative_path, model_type in self.stage_output_specs.get(stage_name, []):
            resolved.append((output_dir / relative_path.format(episode_id=ctx.episode_id), model_type))
        if stage_name == ModuleName.AUDIO_ANCHOR_FORGE and ctx.execution_mode == ExecutionMode.CLOUD:
            resolved.append((output_dir / "render_payload.zip", None))
            resolved.append((output_dir / "render_payload_manifest.json", RenderPayloadManifest))
        return resolved

    def preflight_dependencies(self, ctx: ModuleContext, stage_name: ModuleName) -> list[Path]:
        dependency_map = {
            ModuleName.DIRECTOR_ENGINE: [ModuleName.SOURCE_INGESTER],
            ModuleName.WRITER_ENGINE: [ModuleName.DIRECTOR_ENGINE],
            ModuleName.AUDIO_ANCHOR_FORGE: [ModuleName.WRITER_ENGINE],
            ModuleName.VISUAL_ASSET_FOUNDRY: [ModuleName.AUDIO_ANCHOR_FORGE],
            ModuleName.RENDER_ENGINE: [ModuleName.AUDIO_ANCHOR_FORGE, ModuleName.VISUAL_ASSET_FOUNDRY],
            ModuleName.GLOBAL_DISTRIBUTOR: [ModuleName.RENDER_ENGINE, ModuleName.VISUAL_ASSET_FOUNDRY, ModuleName.AUDIO_ANCHOR_FORGE],
        }

        upstream_paths: list[Path] = []
        for dependency_stage in dependency_map.get(stage_name, []):
            for path, model_type in self.resolve_stage_outputs(ctx, dependency_stage):
                if not path.exists():
                    raise FileNotFoundError(
                        f"Pre-flight check failed for {stage_name.value}: missing upstream file {path}"
                    )
                if model_type is not None:
                    try:
                        read_model(path, model_type)
                    except Exception as exc:
                        raise RuntimeError(
                            f"Schema validation failed for upstream file {path} before {stage_name.value}: {exc}"
                        ) from exc
                upstream_paths.append(path)
        return upstream_paths

    def verify_stage_outputs(self, ctx: ModuleContext, stage_name: ModuleName) -> list[Path]:
        verified_paths: list[Path] = []
        for path, model_type in self.resolve_stage_outputs(ctx, stage_name):
            if not path.exists():
                raise FileNotFoundError(
                    f"Output verification failed for {stage_name.value}: expected file was not generated: {path}"
                )
            if model_type is not None:
                try:
                    read_model(path, model_type)
                except Exception as exc:
                    raise RuntimeError(
                        f"Output schema validation failed for {stage_name.value}: {path}: {exc}"
                    ) from exc
            verified_paths.append(path)
        return verified_paths

    def prompt_review_gate(self, gate_no: int) -> bool:
        print(f"========== [REVIEW GATE {gate_no}] ==========")
        response = input(f"{REVIEW_GATE_MESSAGES[gate_no]} ").strip().lower()
        return response == "y"

    def approve_pending_gate(self, ctx: ModuleContext, manifest: Manifest) -> tuple[Manifest, bool]:
        if manifest.review_gate_pending is None:
            return manifest, True

        if not ctx.prompt_review:
            manifest.overall_status = ModuleStatus.AWAITING_REVIEW
            self.save_manifest(ctx, manifest)
            return manifest, False

        approved = self.prompt_review_gate(manifest.review_gate_pending)
        if not approved:
            manifest.overall_status = ModuleStatus.AWAITING_REVIEW
            self.save_manifest(ctx, manifest)
            return manifest, False

        manifest.review_gate_pending = None
        manifest.overall_status = ModuleStatus.RUNNING
        self.save_manifest(ctx, manifest)
        return manifest, True

    def update_payload_state(self, manifest: Manifest, result: ExecutionResult) -> None:
        payload = next((path for path in result.output_files if path.name == "render_payload.zip"), None)
        if payload is not None:
            manifest.payload_ready = True
            manifest.payload_path = str(payload)
        elif manifest.execution_mode == ExecutionMode.CLOUD and manifest.payload_path is None:
            manifest.payload_ready = False

    def next_stage_after(self, stage_name: ModuleName) -> ModuleName | None:
        index = self.stage_order.index(stage_name)
        if index + 1 >= len(self.stage_order):
            return None
        return self.stage_order[index + 1]

    def run_stage(self, ctx: ModuleContext, stage_name: ModuleName) -> ExecutionResult:
        from ..registry import build_registry

        registry = build_registry()
        module = registry[self.stage_to_key[stage_name]]
        stage_ctx = replace(ctx, emit_templates=True, output_dir=None, force=True)
        return module.run(stage_ctx)

    def run(self, ctx: ModuleContext) -> ExecutionResult:
        started_at = datetime.now(timezone.utc)
        reports_dir = ctx.resolved_reports_dir()
        ensure_directory(reports_dir)

        manifest = self.load_manifest(ctx)
        manifest.execution_mode = ctx.execution_mode
        manifest.run_id = ctx.run_id
        manifest.project_id = ctx.project_id
        manifest.episode_id = ctx.episode_id
        manifest.overall_status = ModuleStatus.RUNNING if manifest.review_gate_pending is None else ModuleStatus.AWAITING_REVIEW
        self.save_manifest(ctx, manifest)

        manifest, may_continue = self.approve_pending_gate(ctx, manifest)
        if not may_continue:
            report = self._build_report(ctx, started_at, ModuleStatus.AWAITING_REVIEW, [self.manifest_path(ctx)])
            report_path = reports_dir / self.report_file_name(ctx)
            write_payload(report_path, report, overwrite=True)
            return ExecutionResult(report_path=report_path, output_files=[self.manifest_path(ctx)], template_files=[])

        for stage_name in self.stage_order:
            stage = self.stage_record(manifest, stage_name)
            if stage.status == ModuleStatus.SUCCESS:
                continue

            stage.status = ModuleStatus.RUNNING
            stage.started_at = datetime.now(timezone.utc)
            stage.error_message = None
            manifest.current_stage = stage_name
            manifest.overall_status = ModuleStatus.RUNNING
            self.save_manifest(ctx, manifest)

            try:
                stage.input_files = [str(path) for path in self.preflight_dependencies(ctx, stage_name)]
                result = self.run_stage(ctx, stage_name)
                verified_outputs = self.verify_stage_outputs(ctx, stage_name)
            except Exception as exc:  # pragma: no cover - defensive path for CLI execution
                stage.status = ModuleStatus.FAILED
                stage.finished_at = datetime.now(timezone.utc)
                stage.error_message = str(exc)
                manifest.current_stage = stage_name
                manifest.overall_status = ModuleStatus.FAILED
                self.save_manifest(ctx, manifest)
                raise RuntimeError(f"Stage {stage_name.value} failed: {exc}") from exc

            stage.status = ModuleStatus.SUCCESS
            stage.finished_at = datetime.now(timezone.utc)
            stage.output_files = [str(path) for path in verified_outputs] + [str(path) for path in result.template_files]
            stage.report_path = str(result.report_path)
            manifest.last_completed_stage = stage_name
            self.update_payload_state(manifest, result)

            next_stage = self.next_stage_after(stage_name)
            manifest.current_stage = next_stage

            gate_no = self.gate_after.get(stage_name)
            if gate_no is not None:
                manifest.review_gate_pending = gate_no
                manifest.overall_status = ModuleStatus.AWAITING_REVIEW
                self.save_manifest(ctx, manifest)

                if not ctx.prompt_review:
                    report = self._build_report(
                        ctx,
                        started_at,
                        ModuleStatus.AWAITING_REVIEW,
                        [self.manifest_path(ctx)],
                    )
                    report_path = reports_dir / self.report_file_name(ctx)
                    write_payload(report_path, report, overwrite=True)
                    return ExecutionResult(
                        report_path=report_path,
                        output_files=[self.manifest_path(ctx)],
                        template_files=[],
                    )

                approved = self.prompt_review_gate(gate_no)
                if not approved:
                    self.save_manifest(ctx, manifest)
                    report = self._build_report(ctx, started_at, ModuleStatus.AWAITING_REVIEW, [self.manifest_path(ctx)])
                    report_path = reports_dir / self.report_file_name(ctx)
                    write_payload(report_path, report, overwrite=True)
                    return ExecutionResult(report_path=report_path, output_files=[self.manifest_path(ctx)], template_files=[])

                manifest.review_gate_pending = None
                manifest.overall_status = ModuleStatus.RUNNING
                self.save_manifest(ctx, manifest)
            else:
                self.save_manifest(ctx, manifest)

        manifest.current_stage = None
        manifest.overall_status = ModuleStatus.SUCCESS
        manifest.review_gate_pending = None
        self.save_manifest(ctx, manifest)

        report = self._build_report(ctx, started_at, ModuleStatus.SUCCESS, [self.manifest_path(ctx)])
        report_path = reports_dir / self.report_file_name(ctx)
        write_payload(report_path, report, overwrite=True)
        return ExecutionResult(report_path=report_path, output_files=[self.manifest_path(ctx)], template_files=[])

    def _build_report(self, ctx: ModuleContext, started_at: datetime, status: ModuleStatus, outputs: list[Path]):
        finished_at = datetime.now(timezone.utc)
        return ModuleReport(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            module_name=self.spec.module_name,
            status=status,
            started_at=started_at,
            finished_at=finished_at,
            warnings=self.build_warnings(),
            output_files=[str(path) for path in outputs],
            execution_mode=ctx.execution_mode,
        )
>>>>>>> C:/Users/Administrator/.windsurf/worktrees/movai/movai-9501c3f2/src/movai/modules/master_hub.py
