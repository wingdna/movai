from __future__ import annotations

import asyncio
import io
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import edge_tts
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from PIL import Image, ImageDraw, ImageFilter, ImageFont
from pydantic import BaseModel, Field
from pydub import AudioSegment
from schemas import ModuleName, TimedScript

from ..context import ModuleContext
from ..llm_client import LLMClient, LLMClientError
from ..module_base import ModuleSpec, ScaffoldModule
from ..tts_voice_registry import choose_narrator_voice, voice_catalog_payload

try:
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request as GoogleAuthRequest
except Exception:  # pragma: no cover
    InstalledAppFlow = None
    Credentials = None
    GoogleAuthRequest = None


LANGUAGES: dict[str, dict[str, str]] = {
    "zh": {"name": "Chinese", "voice": "zh-CN-YunxiNeural", "title_suffix": "幻影卷轴"},
    "en": {"name": "English", "voice": "en-US-BrianNeural", "title_suffix": "Phantom Scroll"},
    "de": {"name": "German", "voice": "de-DE-ConradNeural", "title_suffix": "Phantom-Schriftrolle"},
    "fr": {"name": "French", "voice": "fr-FR-HenriNeural", "title_suffix": "Le Rouleau Fantôme"},
    "es": {"name": "Spanish", "voice": "es-ES-AlvaroNeural", "title_suffix": "El Pergamino Fantasma"},
    "pt": {"name": "Portuguese", "voice": "pt-BR-AntonioNeural", "title_suffix": "Pergaminho Fantasma"},
    "ja": {"name": "Japanese", "voice": "ja-JP-KeitaNeural", "title_suffix": "幻影の巻物"},
    "ko": {"name": "Korean", "voice": "ko-KR-InJoonNeural", "title_suffix": "환영의 두루마리"},
}

LANGUAGE_DESCRIPTIONS = {
    "zh": "伪纪录片风格异星惊悚短片，基于结构化流水线自动生成。",
    "en": "Pseudo-documentary sci-fi horror short generated through a modular cinematic pipeline.",
    "de": "Pseudo-dokumentarischer Sci-Fi-Horror-Kurzfilm aus einer modularen Produktionspipeline.",
    "fr": "Court métrage d'horreur SF pseudo-documentaire généré par une pipeline cinématographique modulaire.",
    "es": "Corto de terror y ciencia ficción en estilo falso documental generado por una pipeline modular.",
    "pt": "Curta de terror sci-fi em estilo pseudo-documental gerado por um pipeline modular.",
    "ja": "モキュメンタリー風SFホラー短編。モジュール式映像パイプラインで生成。",
    "ko": "모큐멘터리풍 SF 호러 단편. 모듈형 영상 파이프라인으로 생성.",
}


@dataclass(slots=True)
class SubtitleEntry:
    index: int
    start_ms: int
    end_ms: int
    text: str


class GlobalDistributorModule(ScaffoldModule):
    spec = ModuleSpec(
        key="global-distributor",
        module_name=ModuleName.GLOBAL_DISTRIBUTOR,
        description="Create multilingual assets and upload-ready distribution packages.",
        default_output_subdir="global_distributor",
    )

    def build_template_payloads(self, ctx: ModuleContext) -> dict[str, object]:
        return {
            "distribution_job.template.json": {
                "schema_version": "2.0",
                "project_id": ctx.project_id,
                "episode_id": ctx.episode_id,
                "run_id": ctx.run_id,
                "master_video": "final_render_zh.mp4",
                "poster_source": "artifacts/posters/raw_poster.png",
                "target_languages": list(LANGUAGES.keys()),
                "deliverables": [
                    *[f"artifacts/subtitles/subtitles_{lang}.srt" for lang in LANGUAGES],
                    *[f"artifacts/audio/track_{lang}.m4a" for lang in LANGUAGES],
                    *[f"artifacts/posters/poster_{lang}.png" for lang in LANGUAGES],
                    "youtube_metadata.json",
                ],
                "notes": [
                    "Generate localized subtitle, poster, and audio tracks for 8 languages.",
                    "Upload flow remains optional unless OAuth credentials are configured.",
                ],
            }
        }

    def load_timed_script(self, ctx: ModuleContext) -> TimedScript:
        path = ctx.workspace / "data" / "staged" / ctx.episode_id / "audio_anchor_forge" / "timed_script.json"
        return TimedScript.model_validate_json(path.read_text(encoding="utf-8"))

    def load_master_video(self, ctx: ModuleContext) -> Path:
        return ctx.workspace / "data" / "staged" / ctx.episode_id / "render_engine" / "final_render_zh.mp4"

    def load_poster_source(self, ctx: ModuleContext) -> Path:
        return ctx.workspace / "data" / "staged" / ctx.episode_id / "visual_asset_foundry" / "artifacts" / "posters" / "raw_poster.png"

    def build_translation_matrix(self, timed_script: TimedScript) -> dict[str, list[dict[str, Any]]]:
        matrix: dict[str, list[dict[str, Any]]] = {}
        for lang in LANGUAGES:
            matrix[lang] = self.translate_script(timed_script, lang)
        return matrix

    def translate_script(self, timed_script: TimedScript, lang: str) -> list[dict[str, Any]]:
        client = LLMClient.from_env(profile="translator")
        if client is not None and lang != "zh":
            prompt = self.build_translation_prompt(timed_script, lang)
            try:
                response = client.call_with_schema(
                    prompt=prompt,
                    response_model=TranslationResponse,
                    system_prompt=(
                        "You are a localization engine for cinematic subtitle and dubbing adaptation. "
                        "Return strict JSON only."
                    ),
                    temperature=0.25,
                )
                return [item.model_dump(mode="json") for item in response.items]
            except LLMClientError:
                pass
        return self.fallback_translation(timed_script, lang)

    def build_translation_prompt(self, timed_script: TimedScript, lang: str) -> str:
        lines = []
        for scene in timed_script.scenes:
            lines.append(
                {
                    "scene_id": scene.scene_id,
                    "narration_text": scene.narration_text,
                    "dialogue": [line.model_dump(mode="json") for line in scene.dialogue],
                }
            )
        return (
            f"Target language: {lang} ({LANGUAGES[lang]['name']})\n"
            f"Timed script lines: {lines}\n"
            "Translate narration and dialogue lines for subtitles and dubbing. Preserve suspense, pseudo-documentary restraint, and timing-friendly phrasing."
        )

    def fallback_translation(self, timed_script: TimedScript, lang: str) -> list[dict[str, Any]]:
        items = []
        for scene in timed_script.scenes:
            base_narration = scene.narration_text or scene.scene_summary
            translated_narration = base_narration if lang == "zh" else f"[{lang.upper()}] {base_narration}"
            translated_dialogue = []
            for line in scene.dialogue:
                translated_dialogue.append(
                    {
                        "character_id": line.character_id,
                        "text": line.text if lang == "zh" else f"[{lang.upper()}] {line.text}",
                    }
                )
            items.append(
                {
                    "scene_id": scene.scene_id,
                    "narration_text": translated_narration,
                    "dialogue": translated_dialogue,
                }
            )
        return items

    def build_subtitle_entries(self, timed_script: TimedScript, localized_items: list[dict[str, Any]]) -> list[SubtitleEntry]:
        entries: list[SubtitleEntry] = []
        cursor = 0
        idx = 1
        localized_map = {item["scene_id"]: item for item in localized_items}
        for scene in timed_script.scenes:
            item = localized_map.get(scene.scene_id, {})
            block_lines = [item.get("narration_text") or scene.narration_text or scene.scene_summary]
            block_lines.extend(dialogue["text"] for dialogue in item.get("dialogue", []))
            text = "\n".join(line for line in block_lines if line)
            entries.append(SubtitleEntry(index=idx, start_ms=cursor, end_ms=cursor + scene.duration_ms, text=text))
            idx += 1
            cursor += scene.duration_ms
        return entries

    def build_srt(self, entries: list[SubtitleEntry]) -> str:
        blocks = []
        for entry in entries:
            blocks.append(
                f"{entry.index}\n"
                f"{self.format_timestamp(entry.start_ms, srt=True)} --> {self.format_timestamp(entry.end_ms, srt=True)}\n"
                f"{entry.text}\n"
            )
        return "\n".join(blocks)

    def build_vtt(self, entries: list[SubtitleEntry]) -> str:
        blocks = ["WEBVTT\n"]
        for entry in entries:
            blocks.append(
                f"{entry.index}\n"
                f"{self.format_timestamp(entry.start_ms, srt=False)} --> {self.format_timestamp(entry.end_ms, srt=False)}\n"
                f"{entry.text}\n"
            )
        return "\n".join(blocks)

    def format_timestamp(self, ms: int, srt: bool) -> str:
        hours = ms // 3_600_000
        minutes = (ms % 3_600_000) // 60_000
        seconds = (ms % 60_000) // 1000
        milliseconds = ms % 1000
        sep = "," if srt else "."
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}{sep}{milliseconds:03d}"

    def build_language_audio_track(self, timed_script: TimedScript, localized_items: list[dict[str, Any]], voice: str) -> bytes:
        localized_map = {item["scene_id"]: item for item in localized_items}
        final_mix = AudioSegment.silent(duration=timed_script.total_duration_ms)
        cursor = 0
        for scene in timed_script.scenes:
            item = localized_map.get(scene.scene_id, {})
            text_fragments = [item.get("narration_text") or scene.narration_text or scene.scene_summary]
            text_fragments.extend(dialogue["text"] for dialogue in item.get("dialogue", []))
            text = " ".join(fragment for fragment in text_fragments if fragment)
            segment = self.generate_tts_segment(text, voice, scene.duration_ms)
            final_mix = final_mix.overlay(segment, position=cursor)
            cursor += scene.duration_ms
        buffer = io.BytesIO()
        final_mix.export(buffer, format="mp4")
        return buffer.getvalue()

    def generate_tts_segment(self, text: str, voice: str, target_duration_ms: int) -> AudioSegment:
        if not text.strip():
            return AudioSegment.silent(duration=target_duration_ms)
        try:
            wav_bytes = asyncio.run(self._edge_tts_wav(text, voice))
            segment = AudioSegment.from_file(io.BytesIO(wav_bytes), format="wav")
        except Exception:
            segment = AudioSegment.silent(duration=max(500, target_duration_ms))

        if len(segment) > target_duration_ms:
            segment = segment[:target_duration_ms]
        elif len(segment) < target_duration_ms:
            segment = segment + AudioSegment.silent(duration=target_duration_ms - len(segment))
        return segment

    async def _edge_tts_wav(self, text: str, voice: str) -> bytes:
        communicator = edge_tts.Communicate(text=text, voice=voice)
        mp3_buffer = io.BytesIO()
        async for chunk in communicator.stream():
            if chunk["type"] == "audio":
                mp3_buffer.write(chunk["data"])
        segment = AudioSegment.from_file(io.BytesIO(mp3_buffer.getvalue()), format="mp3")
        wav_buffer = io.BytesIO()
        segment.export(wav_buffer, format="wav")
        return wav_buffer.getvalue()

    def render_localized_poster(self, poster_source: Path, title: str, subtitle: str, lang: str) -> bytes:
        image = Image.open(poster_source).convert("RGBA")
        overlay = Image.new("RGBA", image.size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)
        width, height = image.size
        safe_right = width - 240
        title_box = (70, 80, safe_right, 320)
        subtitle_box = (70, 340, safe_right, 440)
        draw.rounded_rectangle((50, 60, safe_right + 20, 470), radius=26, fill=(8, 12, 18, 120))
        try:
            title_font = ImageFont.truetype("arial.ttf", 56)
            sub_font = ImageFont.truetype("arial.ttf", 24)
        except Exception:
            title_font = ImageFont.load_default()
            sub_font = ImageFont.load_default()

        shadow = Image.new("RGBA", image.size, (0, 0, 0, 0))
        shadow_draw = ImageDraw.Draw(shadow)
        shadow_draw.text((title_box[0] + 6, title_box[1] + 8), title, font=title_font, fill=(0, 0, 0, 180))
        shadow = shadow.filter(ImageFilter.GaussianBlur(radius=7))
        image = Image.alpha_composite(image, shadow)

        glow = Image.new("RGBA", image.size, (0, 0, 0, 0))
        glow_draw = ImageDraw.Draw(glow)
        glow_draw.text((title_box[0], title_box[1]), title, font=title_font, fill=(255, 170, 70, 120))
        glow = glow.filter(ImageFilter.GaussianBlur(radius=10))
        image = Image.alpha_composite(image, glow)

        draw = ImageDraw.Draw(overlay)
        draw.text((title_box[0], title_box[1]), title, font=title_font, fill=(255, 243, 221, 255))
        draw.text((subtitle_box[0], subtitle_box[1]), subtitle, font=sub_font, fill=(214, 228, 240, 230))
        badge = f"{LANGUAGES[lang]['name']} Edition"
        draw.rounded_rectangle((70, height - 120, 310, height - 62), radius=18, fill=(255, 138, 61, 180))
        draw.text((92, height - 104), badge, font=sub_font, fill=(15, 19, 26, 255))
        final = Image.alpha_composite(image, overlay).convert("RGB")
        buffer = io.BytesIO()
        final.save(buffer, format="PNG")
        return buffer.getvalue()

    def build_localized_titles(self, episode_id: str) -> dict[str, str]:
        return {lang: f"{LANGUAGES[lang]['title_suffix']} - {episode_id}" for lang in LANGUAGES}

    def build_localized_descriptions(self, episode_id: str) -> dict[str, str]:
        return {
            lang: f"{LANGUAGE_DESCRIPTIONS[lang]} Episode: {episode_id}. Released through the MOVAI cinematic pipeline."
            for lang in LANGUAGES
        }

    def build_youtube_metadata(self, ctx: ModuleContext, titles: dict[str, str], descriptions: dict[str, str]) -> dict[str, Any]:
        tags = [
            "phantom scroll",
            "pseudo documentary",
            "sci fi horror",
            "2.5d animation",
            "movai",
            ctx.episode_id.lower(),
            "alien signal",
            "cinematic short",
        ]
        return {
            "schema_version": "2.0",
            "project_id": ctx.project_id,
            "episode_id": ctx.episode_id,
            "run_id": ctx.run_id,
            "defaultLanguage": "en",
            "defaultAudioLanguage": "zh",
            "title": titles["en"],
            "description": descriptions["en"],
            "tags": tags,
            "localizations": {
                lang: {
                    "title": titles[lang],
                    "description": descriptions[lang],
                }
                for lang in LANGUAGES
            },
            "seo_tags": tags,
            "privacyStatus": "unlisted",
        }

    def upload_to_youtube(
        self,
        video_path: Path,
        thumbnail_path: Path,
        subtitle_paths: dict[str, Path],
        metadata: dict[str, Any],
    ) -> dict[str, Any]:
        creds = self.get_youtube_credentials()
        if creds is None:
            return {
                "schema_version": "2.0",
                "status": "skipped",
                "reason": "YouTube OAuth credentials are not configured.",
                "platform_url": None,
            }

        youtube = build("youtube", "v3", credentials=creds)
        body = {
            "snippet": {
                "title": metadata["title"],
                "description": metadata["description"],
                "tags": metadata["tags"],
                "defaultLanguage": metadata["defaultLanguage"],
                "defaultAudioLanguage": metadata["defaultAudioLanguage"],
            },
            "status": {"privacyStatus": "unlisted"},
            "localizations": metadata["localizations"],
        }
        request = youtube.videos().insert(
            part="snippet,status,localizations",
            body=body,
            media_body=MediaFileUpload(str(video_path), chunksize=-1, resumable=True),
        )
        response = request.execute()
        video_id = response["id"]

        if thumbnail_path.exists():
            youtube.thumbnails().set(videoId=video_id, media_body=MediaFileUpload(str(thumbnail_path))).execute()

        for lang, subtitle_path in subtitle_paths.items():
            if not subtitle_path.exists():
                continue
            youtube.captions().insert(
                part="snippet",
                body={
                    "snippet": {
                        "videoId": video_id,
                        "language": lang,
                        "name": f"subtitle_{lang}",
                        "isDraft": False,
                    }
                },
                media_body=MediaFileUpload(str(subtitle_path)),
            ).execute()

        return {
            "schema_version": "2.0",
            "status": "uploaded",
            "video_id": video_id,
            "platform_url": f"https://www.youtube.com/watch?v={video_id}",
        }

    def get_youtube_credentials(self):
        client_secret = os.getenv("MOVAI_YOUTUBE_CLIENT_SECRET_FILE")
        token_file = os.getenv("MOVAI_YOUTUBE_TOKEN_FILE", "youtube_token.json")
        scopes = ["https://www.googleapis.com/auth/youtube.upload", "https://www.googleapis.com/auth/youtube.force-ssl"]

        if not client_secret or InstalledAppFlow is None or Credentials is None:
            return None

        creds = None
        token_path = Path(token_file)
        if token_path.exists():
            creds = Credentials.from_authorized_user_file(str(token_path), scopes)
        if creds and creds.expired and creds.refresh_token and GoogleAuthRequest is not None:
            creds.refresh(GoogleAuthRequest())
        if not creds or not creds.valid:
            flow = InstalledAppFlow.from_client_secrets_file(client_secret, scopes)
            creds = flow.run_local_server(port=0)
            token_path.write_text(creds.to_json(), encoding="utf-8")
        return creds


class TranslationItem(BaseModel):
    scene_id: str
    narration_text: str
    dialogue: list[dict[str, str]] = Field(default_factory=list)


class TranslationResponse(BaseModel):
    items: list[TranslationItem] = Field(min_length=1)
