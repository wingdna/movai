from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

from schemas import ModuleName, PartitionType, RawSource, RawTextChunk, SourcePartition, SourceType

from ..context import ModuleContext
from ..module_base import ModuleSpec, ScaffoldModule


DEFAULT_PUBLIC_DOMAIN_URL = "https://www.gutenberg.org/cache/epub/1342/pg1342.txt"
DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36 MOVAI/0.1"
)
PARTITION_HEADING_RE = re.compile(
    r"^\s*(?:"
    r"第[零一二三四五六七八九十百千万0-9]+[章节回卷部篇集]"
    r"|[卷部篇集][零一二三四五六七八九十百千万0-9]+"
    r"|chapter\s+[0-9ivxlcdm]+"
    r"|book\s+[0-9ivxlcdm]+"
    r"|part\s+[0-9ivxlcdm]+"
    r")[\s：:.-]*.*$",
    re.IGNORECASE,
)
NOISE_PATTERNS = [
    r"本站提供.*下载",
    r"this site provides .*download",
    r"手机在线阅读",
    r"最新网址",
    r"本章未完",
    r"请收藏本站",
    r"更多精彩",
    r"广告",
    r"copyright",
    r"all rights reserved",
    r"project gutenberg license",
    r"end of the project gutenberg",
    r"start of the project gutenberg",
]


class SourceIngesterModule(ScaffoldModule):
    spec = ModuleSpec(
        key="source-ingester",
        module_name=ModuleName.SOURCE_INGESTER,
        description="Collect and normalize source text into raw_source.json.",
        default_output_subdir="source_ingester",
    )

    def build_template_payloads(self, ctx: ModuleContext) -> dict[str, RawSource]:
        return {}

    def build_mock_outputs(self, ctx: ModuleContext) -> dict[str, RawSource]:
        return {"raw_source.json": self.ingest_source(ctx)}

    def build_warnings(self) -> list[str]:
        return []

    def ingest_source(self, ctx: ModuleContext) -> RawSource:
        source_uri = ctx.source_uri or DEFAULT_PUBLIC_DOMAIN_URL
        source_type = self.detect_source_type(source_uri, ctx.source_type_hint)

        if source_type == SourceType.LOCAL_TXT:
            title, author, raw_text = self.load_local_txt(ctx, Path(source_uri))
        elif source_type == SourceType.WEB_URL:
            title, author, raw_text = self.fetch_web_text(source_uri, ctx.source_keywords)
        elif source_type == SourceType.LOCAL_EPUB:
            raise NotImplementedError("LOCAL_EPUB support is not implemented yet. TODO: integrate ebooklib.")
        else:
            raise ValueError(f"Unsupported source type: {source_type}")

        cleaned_text = self.clean_text(raw_text)
        if not cleaned_text.strip():
            raise ValueError("Source text is empty after cleansing.")

        partitions = self.partition_text(cleaned_text, ctx.chapter_range)
        return RawSource(
            project_id=ctx.project_id,
            run_id=ctx.run_id,
            title=title,
            author=author,
            source_type=source_type,
            source_uri=source_uri,
            chapter_range=ctx.chapter_range,
            source_partitions=partitions,
        )

    def detect_source_type(self, source_uri: str, source_type_hint: str | None) -> SourceType:
        if source_type_hint:
            return SourceType(source_type_hint)

        parsed = urlparse(source_uri)
        if parsed.scheme in {"http", "https"}:
            return SourceType.WEB_URL

        suffix = Path(source_uri).suffix.lower()
        if suffix == ".txt":
            return SourceType.LOCAL_TXT
        if suffix == ".epub":
            return SourceType.LOCAL_EPUB
        raise ValueError(f"Unable to infer source type from: {source_uri}")

    def load_local_txt(self, ctx: ModuleContext, path: Path) -> tuple[str, str | None, str]:
        if not path.is_absolute():
            path = ctx.workspace / path
        if not path.exists():
            raise FileNotFoundError(f"Local source file does not exist: {path}")

        raw_text: str | None = None
        for encoding in ("utf-8-sig", "utf-8", "gb18030"):
            try:
                raw_text = path.read_text(encoding=encoding)
                break
            except UnicodeDecodeError:
                continue
        if raw_text is None:
            raise UnicodeDecodeError("source_ingester", b"", 0, 1, f"Unable to decode local text file: {path}")
        title = path.stem.replace("_", " ").strip() or "Untitled Local Text"
        return title, None, raw_text

    def fetch_web_text(self, url: str, keywords: str | None) -> tuple[str, str | None, str]:
        headers = {"User-Agent": DEFAULT_USER_AGENT}
        try:
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
        except requests.RequestException as exc:
            raise RuntimeError(f"Failed to fetch source URL: {url}: {exc}") from exc

        response.encoding = response.apparent_encoding or response.encoding
        content_type = response.headers.get("Content-Type", "").lower()
        if "text/plain" in content_type or url.lower().endswith(".txt"):
            text = response.text
            title = self.extract_plaintext_title(text) or Path(urlparse(url).path).stem or "Web Text"
            return title, None, text

        soup = BeautifulSoup(response.text, "html.parser")
        for tag in soup(["script", "style", "noscript", "iframe"]):
            tag.decompose()

        title = self.extract_title(soup, url)
        author = self.extract_author(soup)
        text = self.extract_main_text(soup, url, headers, keywords)
        return title, author, text

    def extract_title(self, soup: BeautifulSoup, url: str) -> str:
        if soup.title and soup.title.string:
            return soup.title.string.strip()
        return Path(urlparse(url).path).stem or "Untitled Web Source"

    def extract_author(self, soup: BeautifulSoup) -> str | None:
        author_meta = soup.find("meta", attrs={"name": re.compile("author", re.IGNORECASE)})
        if author_meta and author_meta.get("content"):
            return author_meta["content"].strip()
        return None

    def extract_main_text(
        self,
        soup: BeautifulSoup,
        base_url: str,
        headers: dict[str, str],
        keywords: str | None,
    ) -> str:
        candidates = []
        for selector in ["article", "main", '[role="main"]', ".entry-content", ".mw-parser-output", "body"]:
            candidates.extend(soup.select(selector))
        if not candidates:
            candidates = [soup]

        best_text = ""
        keyword_tokens = [token.strip().lower() for token in (keywords or "").split() if token.strip()]

        for candidate in candidates:
            text = candidate.get_text("\n", strip=True)
            if keyword_tokens and not all(token in text.lower() for token in keyword_tokens):
                continue
            if len(text) > len(best_text):
                best_text = text

        if not best_text:
            best_text = soup.get_text("\n", strip=True)

        chapter_text = self.extract_linked_chapters(soup, base_url, headers)
        if len(chapter_text) > len(best_text):
            return chapter_text
        return best_text

    def extract_linked_chapters(self, soup: BeautifulSoup, base_url: str, headers: dict[str, str]) -> str:
        parsed_base = urlparse(base_url)
        if "wikisource.org" not in parsed_base.netloc:
            return ""

        chapter_links: list[tuple[str, str]] = []
        seen: set[str] = set()
        for anchor in soup.select(".mw-parser-output a[href], #mw-content-text a[href]"):
            href = anchor.get("href", "").strip()
            label = anchor.get_text(" ", strip=True)
            if not href or href.startswith("#") or not label:
                continue
            if not PARTITION_HEADING_RE.match(label):
                continue
            full_url = urljoin(base_url, href)
            parsed = urlparse(full_url)
            if parsed.netloc != parsed_base.netloc:
                continue
            normalized = parsed._replace(fragment="").geturl()
            if normalized in seen:
                continue
            seen.add(normalized)
            chapter_links.append((label, normalized))

        if len(chapter_links) < 2:
            return ""

        chapters: list[str] = []
        for label, chapter_url in chapter_links[:80]:
            try:
                response = requests.get(chapter_url, headers=headers, timeout=30)
                response.raise_for_status()
            except requests.RequestException:
                continue
            response.encoding = response.apparent_encoding or response.encoding
            chapter_soup = BeautifulSoup(response.text, "html.parser")
            for tag in chapter_soup(["script", "style", "noscript", "iframe", "table"]):
                tag.decompose()
            container = chapter_soup.select_one(".mw-parser-output") or chapter_soup.select_one("body")
            if container is None:
                continue

            lines: list[str] = []
            for node in container.select("p, dd, li"):
                text = node.get_text(" ", strip=True)
                if len(text) >= 8:
                    lines.append(text)

            if not lines:
                text = container.get_text("\n", strip=True)
                if len(text) < 20:
                    continue
                lines = [line.strip() for line in text.splitlines() if line.strip()]

            chapter_body = "\n".join(lines).strip()
            if len(chapter_body) < 20:
                continue
            chapters.append(f"{label}\n{chapter_body}")

        return "\n\n".join(chapters)

    def clean_text(self, raw_text: str) -> str:
        text = raw_text.replace("\ufeff", "").replace("\r\n", "\n").replace("\r", "\n")
        text = self.trim_gutenberg_boilerplate(text)
        lines = []
        for line in text.split("\n"):
            normalized = re.sub(r"\s+", " ", line).strip()
            if not normalized:
                continue
            if any(re.search(pattern, normalized, re.IGNORECASE) for pattern in NOISE_PATTERNS):
                continue
            lines.append(normalized)

        text = "\n".join(lines)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def extract_plaintext_title(self, text: str) -> str | None:
        for line in text.splitlines():
            normalized = line.replace("\ufeff", "").strip()
            if normalized.lower().startswith("the project gutenberg ebook of "):
                return normalized.removeprefix("The Project Gutenberg eBook of ").strip(" ,.")
            if normalized:
                return normalized[:120]
        return None

    def trim_gutenberg_boilerplate(self, text: str) -> str:
        start_match = re.search(r"\*\*\*\s*START OF (?:THE|THIS) PROJECT GUTENBERG EBOOK.*\*\*\*", text, re.IGNORECASE)
        end_match = re.search(r"\*\*\*\s*END OF (?:THE|THIS) PROJECT GUTENBERG EBOOK.*\*\*\*", text, re.IGNORECASE)
        if start_match:
            text = text[start_match.end() :]
        if end_match:
            text = text[: end_match.start()]
        return text

    def partition_text(self, cleaned_text: str, chapter_range: str | None) -> list[SourcePartition]:
        segments = self.split_by_headings(cleaned_text)
        partitions: list[SourcePartition] = []

        for index, (heading, body) in enumerate(segments):
            if chapter_range and not self.heading_matches_range(index, heading, chapter_range):
                continue
            combined = body.strip()
            if heading:
                combined = f"{heading}\n{combined}".strip()
            if not combined:
                continue

            chunks = self.chunk_text(combined, heading or f"Partition {index + 1}", index)
            partitions.append(
                SourcePartition(
                    partition_id=f"PART_{index + 1:03d}",
                    partition_type=PartitionType.CHAPTER_RANGE,
                    order_index=len(partitions),
                    label=heading or f"Partition {index + 1}",
                    chapter_range=heading,
                    text_chunks=chunks,
                )
            )

        if partitions:
            return partitions

        return [
            SourcePartition(
                partition_id="PART_001",
                partition_type=PartitionType.SECTION,
                order_index=0,
                label="Full Text",
                chapter_range=chapter_range,
                text_chunks=self.chunk_text(cleaned_text, "Full Text", 0),
            )
        ]

    def split_by_headings(self, cleaned_text: str) -> list[tuple[str | None, str]]:
        lines = cleaned_text.splitlines()
        segments: list[tuple[str | None, list[str]]] = []
        current_heading: str | None = None
        current_lines: list[str] = []

        for line in lines:
            if PARTITION_HEADING_RE.match(line):
                if current_lines:
                    segments.append((current_heading, current_lines))
                    current_lines = []
                current_heading = line.strip()
            else:
                current_lines.append(line)

        if current_lines:
            segments.append((current_heading, current_lines))

        if not segments:
            return [(None, cleaned_text)]
        return [(heading, "\n".join(body_lines).strip()) for heading, body_lines in segments]

    def heading_matches_range(self, index: int, heading: str | None, chapter_range: str) -> bool:
        if not chapter_range:
            return True
        parsed = self.parse_range(chapter_range)
        if parsed is None:
            return True

        start, end = parsed
        chapter_no = self.extract_heading_number(heading)
        if chapter_no is None:
            chapter_no = index + 1
        return start <= chapter_no <= end

    def parse_range(self, value: str) -> tuple[int, int] | None:
        match = re.match(r"^\s*(\d+)\s*[-~至]\s*(\d+)\s*$", value)
        if match:
            start, end = int(match.group(1)), int(match.group(2))
            return (min(start, end), max(start, end))
        match = re.match(r"^\s*(\d+)\s*$", value)
        if match:
            number = int(match.group(1))
            return (number, number)
        return None

    def extract_heading_number(self, heading: str | None) -> int | None:
        if not heading:
            return None
        match = re.search(r"(\d+)", heading)
        if match:
            return int(match.group(1))
        return None

    def chunk_text(self, text: str, chapter_label: str, partition_index: int, max_chars: int = 1800) -> list[RawTextChunk]:
        paragraphs = [paragraph.strip() for paragraph in text.split("\n") if paragraph.strip()]
        chunks: list[RawTextChunk] = []
        buffer = ""
        chunk_index = 0

        for paragraph in paragraphs:
            candidate = f"{buffer}\n{paragraph}".strip() if buffer else paragraph
            if len(candidate) <= max_chars:
                buffer = candidate
                continue

            if buffer:
                chunks.append(
                    RawTextChunk(
                        chunk_id=f"part_{partition_index + 1:03d}_chunk_{chunk_index + 1:03d}",
                        order_index=chunk_index,
                        chapter_label=chapter_label,
                        text=buffer,
                    )
                )
                chunk_index += 1
                buffer = ""

            if len(paragraph) <= max_chars:
                buffer = paragraph
                continue

            for start in range(0, len(paragraph), max_chars):
                piece = paragraph[start : start + max_chars].strip()
                if not piece:
                    continue
                chunks.append(
                    RawTextChunk(
                        chunk_id=f"part_{partition_index + 1:03d}_chunk_{chunk_index + 1:03d}",
                        order_index=chunk_index,
                        chapter_label=chapter_label,
                        text=piece,
                    )
                )
                chunk_index += 1

        if buffer:
            chunks.append(
                RawTextChunk(
                    chunk_id=f"part_{partition_index + 1:03d}_chunk_{chunk_index + 1:03d}",
                    order_index=chunk_index,
                    chapter_label=chapter_label,
                    text=buffer,
                )
            )

        if not chunks:
            raise ValueError("Failed to create any text chunks from source content.")
        return chunks
