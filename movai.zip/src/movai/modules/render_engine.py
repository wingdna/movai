from __future__ import annotations

import math
import wave
from pathlib import Path

import cv2
import numpy as np
from moviepy import AudioFileClip, VideoFileClip, concatenate_videoclips
from pydub import AudioSegment
from schemas import ModuleName, TimedScript

from ..context import ModuleContext
from ..module_base import ModuleSpec, ScaffoldModule


class RenderEngineModule(ScaffoldModule):
    spec = ModuleSpec(
        key="render-engine",
        module_name=ModuleName.RENDER_ENGINE,
        description="Render 2.5D motion clips and composite the Chinese master.",
        default_output_subdir="render_engine",
    )

    fps = 24
    frame_size = (1280, 720)

    def build_template_payloads(self, ctx: ModuleContext) -> dict[str, object]:
        return {
            "render_job.template.json": {
                "schema_version": "2.0",
                "project_id": ctx.project_id,
                "episode_id": ctx.episode_id,
                "run_id": ctx.run_id,
                "execution_mode": ctx.execution_mode.value,
                "target_output": "final_render_zh.mp4",
                "scene_contract": "timed_script.json",
                "required_assets": ["artifacts/audio", "artifacts/visuals"],
                "notes": [
                    "Respect duration_ms from timed_script for every scene clip.",
                    "Use depth-driven parallax, focus pulls, layered overlays, and audio-synced lighting changes.",
                ],
            }
        }

    def load_timed_script(self, ctx: ModuleContext) -> TimedScript:
        path = ctx.workspace / "data" / "staged" / ctx.episode_id / "audio_anchor_forge" / "timed_script.json"
        return TimedScript.model_validate_json(path.read_text(encoding="utf-8"))

    def render_episode(self, ctx: ModuleContext, timed_script: TimedScript, output_dir: Path) -> Path:
        clips: list[VideoFileClip] = []
        temp_paths: list[Path] = []

        for scene in timed_script.scenes:
            scene_video = output_dir / f"{scene.scene_id}.mp4"
            scene_audio = output_dir / f"{scene.scene_id}_mix.wav"
            self.render_scene_clip(ctx, scene, scene_video, scene_audio)
            clip = VideoFileClip(str(scene_video)).with_audio(AudioFileClip(str(scene_audio)))
            clips.append(clip)
            temp_paths.extend([scene_video, scene_audio])

        final_clip = concatenate_videoclips(clips, method="compose")
        final_path = output_dir / "final_render_zh.mp4"
        final_clip.write_videofile(str(final_path), codec="libx264", audio_codec="aac", fps=self.fps, logger=None)

        for clip in clips:
            clip.close()
        final_clip.close()
        return final_path

    def render_scene_clip(self, ctx: ModuleContext, scene, video_path: Path, scene_audio_path: Path) -> None:
        rgb = self.load_image(self.resolve_visual_path(ctx, scene.visual_render.image_path, "visual_asset_foundry"))
        depth = self.load_image(self.resolve_visual_path(ctx, scene.visual_render.depth_path, "visual_asset_foundry"), grayscale=True)
        rgb = cv2.resize(rgb, self.frame_size)
        depth = cv2.resize(depth, self.frame_size)
        depth = depth.astype(np.float32) / 255.0

        mixed_audio, envelope = self.mix_scene_audio(ctx, scene, scene_audio_path)
        frame_count = max(1, round(scene.duration_ms / 1000 * self.fps))
        writer = cv2.VideoWriter(
            str(video_path),
            cv2.VideoWriter_fourcc(*"mp4v"),
            self.fps,
            self.frame_size,
        )

        for frame_idx in range(frame_count):
            t = frame_idx / max(1, frame_count - 1)
            frame = self.render_parallax_frame(rgb, depth, t, scene.camera_move)
            frame = self.apply_blur_by_depth(frame, depth, t)
            frame = self.apply_lighting_fx(frame, envelope[min(frame_idx, len(envelope) - 1)], scene.vfx_layers, t)
            frame = self.composite_layers(frame, depth, scene.vfx_layers, t)
            writer.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))

        writer.release()

    def render_parallax_frame(self, rgb: np.ndarray, depth: np.ndarray, t: float, camera_move: str) -> np.ndarray:
        h, w = depth.shape
        xx, yy = np.meshgrid(np.arange(w), np.arange(h))
        move_x, move_y, zoom_strength = self.motion_profile(camera_move, t)
        displacement = (depth - 0.5) * 2.0
        map_x = xx.astype(np.float32) + displacement * move_x
        map_y = yy.astype(np.float32) + displacement * move_y
        warped = cv2.remap(rgb, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        if zoom_strength != 1.0:
            warped = self.zoom_image(warped, zoom_strength)
        return warped

    def motion_profile(self, camera_move: str, t: float) -> tuple[float, float, float]:
        if camera_move == "Z_Dolly_In_Slow":
            return 18 * (0.5 - t), 8 * math.sin(t * math.pi), 1.0 + 0.08 * t
        if camera_move == "Z_Dolly_Out_Slow":
            return -18 * (0.5 - t), -6 * math.sin(t * math.pi), 1.08 - 0.08 * t
        if camera_move == "Pan_Left":
            return -28 * t, 0.0, 1.01
        if camera_move == "Pan_Right":
            return 28 * t, 0.0, 1.01
        if camera_move == "Handheld_Drift":
            return 12 * math.sin(t * 10), 8 * math.cos(t * 7), 1.02 + 0.01 * math.sin(t * 3)
        return 0.0, 0.0, 1.0

    def zoom_image(self, image: np.ndarray, zoom: float) -> np.ndarray:
        h, w = image.shape[:2]
        nh, nw = max(1, int(h / zoom)), max(1, int(w / zoom))
        y1 = max(0, (h - nh) // 2)
        x1 = max(0, (w - nw) // 2)
        cropped = image[y1 : y1 + nh, x1 : x1 + nw]
        return cv2.resize(cropped, (w, h), interpolation=cv2.INTER_LINEAR)

    def apply_blur_by_depth(self, frame: np.ndarray, depth: np.ndarray, t: float) -> np.ndarray:
        focus_depth = 0.35 + 0.3 * math.sin(t * math.pi)
        distance = np.abs(depth - focus_depth)
        near = cv2.GaussianBlur(frame, (0, 0), sigmaX=1.2)
        far = cv2.GaussianBlur(frame, (0, 0), sigmaX=5.5)
        mask = np.clip(distance * 3.5, 0, 1)[..., None]
        return (near * (1 - mask) + far * mask).astype(np.uint8)

    def apply_lighting_fx(self, frame: np.ndarray, audio_level: float, vfx_layers: list[str], t: float) -> np.ndarray:
        result = frame.astype(np.float32)
        brightness_boost = 1.0 + 0.18 * audio_level
        color_shift = np.array([1.0 + 0.08 * audio_level, 1.0, 1.0 - 0.06 * audio_level], dtype=np.float32)
        if "Glitch_Light" in vfx_layers:
            color_shift += np.array([0.05 * math.sin(t * 20), 0.0, 0.03 * math.cos(t * 18)], dtype=np.float32)
        if "Scanline_Flicker" in vfx_layers:
            brightness_boost += 0.04 * math.sin(t * 40)
        result = result * brightness_boost
        result = result * color_shift
        return np.clip(result, 0, 255).astype(np.uint8)

    def composite_layers(self, frame: np.ndarray, depth: np.ndarray, vfx_layers: list[str], t: float) -> np.ndarray:
        result = frame.copy().astype(np.float32)
        particles = self.generate_particles(depth.shape, t)
        ui_noise = self.generate_ui_interference(depth.shape, t, "Scanline_Flicker" in vfx_layers)
        result = result * 0.92 + particles * 0.08
        result = np.clip(result + ui_noise, 0, 255)
        return result.astype(np.uint8)

    def generate_particles(self, shape: tuple[int, int], t: float) -> np.ndarray:
        h, w = shape
        layer = np.zeros((h, w, 3), dtype=np.float32)
        for idx in range(18):
            x = int((idx * 73 + t * 180 * (idx + 1)) % w)
            y = int((idx * 41 + t * 120 * (idx + 2)) % h)
            radius = 1 + (idx % 3)
            cv2.circle(layer, (x, y), radius, (255, 180, 90), -1)
        layer = cv2.GaussianBlur(layer, (0, 0), 1.4)
        return layer

    def generate_ui_interference(self, shape: tuple[int, int], t: float, enabled: bool) -> np.ndarray:
        h, w = shape
        if not enabled:
            return np.zeros((h, w, 3), dtype=np.float32)
        layer = np.zeros((h, w, 3), dtype=np.float32)
        for y in range(0, h, 6):
            intensity = 12 + 8 * math.sin((y / h) * 12 + t * 20)
            layer[y : y + 1, :, :] = intensity
        glitch_x = int((0.5 + 0.5 * math.sin(t * 25)) * (w - 180))
        cv2.rectangle(layer, (glitch_x, 0), (min(w, glitch_x + 90), h), (18, 32, 54), -1)
        return layer

    def mix_scene_audio(self, ctx: ModuleContext, scene, output_path: Path) -> tuple[AudioSegment, list[float]]:
        base = AudioSegment.silent(duration=scene.duration_ms)
        peaks: list[float] = []
        for track in scene.audio_tracks:
            audio_path = self.resolve_audio_path(ctx, track.file_path)
            segment = AudioSegment.from_file(audio_path)
            if len(segment) < scene.duration_ms:
                segment = segment + AudioSegment.silent(duration=scene.duration_ms - len(segment))
            base = base.overlay(segment[: scene.duration_ms])
        base.export(output_path, format="wav")
        peaks = self.audio_envelope(output_path, scene.duration_ms)
        return base, peaks

    def audio_envelope(self, audio_path: Path, duration_ms: int) -> list[float]:
        with wave.open(str(audio_path), "rb") as wav_file:
            frame_count = wav_file.getnframes()
            sample_rate = wav_file.getframerate()
            raw = wav_file.readframes(frame_count)
        samples = np.frombuffer(raw, dtype=np.int16).astype(np.float32)
        if samples.size == 0:
            return [0.0]
        if len(samples.shape) > 1:
            samples = samples.mean(axis=1)
        frames_needed = max(1, round(duration_ms / 1000 * self.fps))
        window = max(1, len(samples) // frames_needed)
        envelope = []
        max_val = np.max(np.abs(samples)) or 1.0
        for idx in range(frames_needed):
            chunk = samples[idx * window : (idx + 1) * window]
            level = float(np.mean(np.abs(chunk)) / max_val) if chunk.size else 0.0
            envelope.append(level)
        return envelope

    def resolve_audio_path(self, ctx: ModuleContext, relative_path: str) -> Path:
        return ctx.workspace / "data" / "staged" / ctx.episode_id / "audio_anchor_forge" / Path(relative_path)

    def resolve_visual_path(self, ctx: ModuleContext, relative_path: str, module_name: str) -> Path:
        candidate = ctx.workspace / "data" / "staged" / ctx.episode_id / module_name / Path(relative_path)
        if candidate.exists():
            return candidate
        candidate = ctx.workspace / "data" / "staged" / ctx.episode_id / Path(relative_path)
        if candidate.exists():
            return candidate
        return ctx.workspace / "data" / "staged" / ctx.episode_id / "visual_asset_foundry" / Path(relative_path)

    def load_image(self, path: Path, grayscale: bool = False) -> np.ndarray:
        flag = cv2.IMREAD_GRAYSCALE if grayscale else cv2.IMREAD_COLOR
        image = cv2.imread(str(path), flag)
        if image is None:
            raise FileNotFoundError(f"Required image asset not found or unreadable: {path}")
        if grayscale:
            return image
        return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
