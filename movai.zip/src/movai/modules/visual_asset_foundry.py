from __future__ import annotations

import base64
import io
import json
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import requests
from PIL import Image, ImageDraw, ImageFilter, ImageFont
from schemas import ExecutionMode, ModuleName, ProjectBible, RenderPayloadManifest, TimedScript

from ..config import get_visual_model_settings
from ..context import ModuleContext
from ..io_utils import read_json
from ..module_base import ModuleSpec, ScaffoldModule


@dataclass(slots=True)
class VisualPromptEngine:
    project_bible: ProjectBible

    def build_scene_prompt(self, scene) -> str:
        entity_locks = [
            self.project_bible.entities[entity_id].visual_prompt_lock
            for entity_id in scene.visual_render.entity_ids
            if entity_id in self.project_bible.entities
        ]
        tags = [
            scene.scene_summary,
            scene.action_description,
            scene.visual_render.base_prompt,
            *entity_locks,
            "cinematic still",
            "high detail",
            "best quality",
            "film lighting",
            "Kolors style",
            "storyboard keyframe",
            "2.5D parallax friendly composition",
        ]
        return ", ".join(dict.fromkeys(tag.strip() for tag in tags if tag and tag.strip()))

    def build_character_sheet_prompt(self, entity_id: str, entity) -> str:
        return (
            f"{entity.visual_prompt_lock}, four-view character sheet, front view, left profile, right profile, back view, "
            "neutral pose, full body, turnaround sheet, clean background, concept art board, design consistency, Kolors style"
        )


class KolorsClient:
    def __init__(self) -> None:
        settings = get_visual_model_settings()
        self.base_url = settings.base_url
        self.api_key = settings.api_key
        self.model = settings.model
        self.timeout = settings.timeout
        self.max_retries = settings.max_retries
        self.last_retry_count = 0

    @property
    def enabled(self) -> bool:
        return bool(self.base_url and self.api_key)

    def generate_image(self, prompt: str, size: str = "1024x1024") -> bytes:
        if not self.enabled:
            raise RuntimeError("Kolors client is not configured.")

        payload = {
            "model": self.model,
            "prompt": prompt,
            "size": size,
            "response_format": "b64_json",
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        last_error = "unknown"
        for attempt in range(1, self.max_retries + 1):
            try:
                response = requests.post(
                    f"{self.base_url.rstrip('/')}/images/generations",
                    headers=headers,
                    json=payload,
                    timeout=self.timeout,
                )
            except requests.RequestException as exc:
                last_error = str(exc)
                self.last_retry_count += 1
                time.sleep(min(2**attempt, 12))
                continue

            if response.status_code == 429:
                self.last_retry_count += 1
                retry_after = response.headers.get("Retry-After")
                sleep_seconds = int(retry_after) if retry_after and retry_after.isdigit() else min(2**attempt, 20)
                time.sleep(sleep_seconds)
                last_error = f"rate limited (429), slept {sleep_seconds}s"
                continue

            try:
                response.raise_for_status()
            except requests.RequestException as exc:
                self.last_retry_count += 1
                last_error = f"{exc}: {response.text}"
                time.sleep(min(2**attempt, 12))
                continue

            data = response.json()
            try:
                image_b64 = data["data"][0]["b64_json"]
            except (KeyError, IndexError, TypeError) as exc:
                self.last_retry_count += 1
                last_error = f"unexpected image response: {data}"
                time.sleep(min(2**attempt, 12))
                continue
            return base64.b64decode(image_b64)

        raise RuntimeError(f"Kwai-Kolors generation failed after {self.max_retries} attempts: {last_error}")


class VisualAssetFoundryModule(ScaffoldModule):
    spec = ModuleSpec(
        key="visual-asset-foundry",
        module_name=ModuleName.VISUAL_ASSET_FOUNDRY,
        description="Generate RGB renders, depth maps, and poster source art.",
        default_output_subdir="visual_asset_foundry",
    )

    def __init__(self) -> None:
        super().__init__()
        self.kolors = KolorsClient()

    def build_template_payloads(self, ctx: ModuleContext) -> dict[str, object]:
        scene_id = f"{ctx.episode_id}_S_001"
        return {
            "visual_asset_batch.template.json": {
                "schema_version": "2.0",
                "project_id": ctx.project_id,
                "episode_id": ctx.episode_id,
                "run_id": ctx.run_id,
                "execution_mode": ctx.execution_mode.value,
                "expected_outputs": [
                    f"artifacts/visuals/{scene_id}_rgb.png",
                    f"artifacts/visuals/{scene_id}_depth.png",
                    "artifacts/posters/raw_poster.png",
                    "artifacts/character_sheets",
                ],
                "notes": [
                    "Compose scene prompts from base_prompt plus immutable entity visual locks.",
                    "Create character sheets before scene renders for Gate 2 review.",
                    "Persist cloud-friendly config using relative paths only.",
                ],
            }
        }

    def load_timed_script(self, ctx: ModuleContext) -> TimedScript:
        path = ctx.workspace / "data" / "staged" / ctx.episode_id / "audio_anchor_forge" / "timed_script.json"
        return TimedScript.model_validate_json(path.read_text(encoding="utf-8"))

    def load_project_bible(self, ctx: ModuleContext) -> ProjectBible:
        path = ctx.workspace / "data" / "staged" / ctx.episode_id / "director_engine" / "project_bible.json"
        return ProjectBible.model_validate_json(path.read_text(encoding="utf-8"))

    def generate_character_sheet(self, entity_id: str, name: str, prompt: str) -> bytes:
        if self.kolors.enabled:
            try:
                return self.kolors.generate_image(prompt, size="1024x1024")
            except Exception:
                self._last_retry_count = self.kolors.last_retry_count
        return self.render_character_sheet_fallback(entity_id, name, prompt)

    def generate_scene_image(self, scene_id: str, prompt: str, duration_ms: int) -> bytes:
        if self.kolors.enabled:
            try:
                return self.kolors.generate_image(prompt, size="1280x720")
            except Exception:
                self._last_retry_count = self.kolors.last_retry_count
        return self.render_scene_fallback(scene_id, prompt, duration_ms)

    def generate_depth_map(self, rgb_bytes: bytes) -> bytes:
        image = Image.open(io.BytesIO(rgb_bytes)).convert("L")
        image = image.filter(ImageFilter.GaussianBlur(radius=2))
        output = io.BytesIO()
        image.save(output, format="PNG")
        return output.getvalue()

    def generate_poster_image(self, prompt: str, episode_id: str) -> bytes:
        image = Image.new("RGB", (1280, 720), color=(15, 19, 28))
        draw = ImageDraw.Draw(image)
        font = ImageFont.load_default()
        draw.rectangle((40, 40, 1240, 680), outline=(255, 138, 61), width=4)
        draw.text((80, 90), f"{episode_id} Poster Plate", fill=(255, 219, 173), font=font)
        draw.text((80, 140), prompt[:240], fill=(225, 235, 245), font=font)
        output = io.BytesIO()
        image.save(output, format="PNG")
        return output.getvalue()

    def render_character_sheet_fallback(self, entity_id: str, name: str, prompt: str) -> bytes:
        image = Image.new("RGB", (1200, 1200), color=(12, 17, 26))
        draw = ImageDraw.Draw(image)
        font = ImageFont.load_default()
        directions = ["FRONT", "LEFT", "RIGHT", "BACK"]
        positions = [(80, 120), (620, 120), (80, 640), (620, 640)]
        for direction, (x, y) in zip(directions, positions):
            draw.rounded_rectangle((x, y, x + 460, y + 420), radius=24, outline=(65, 198, 183), width=3)
            draw.text((x + 24, y + 24), f"{name} - {direction}", fill=(255, 255, 255), font=font)
            draw.ellipse((x + 180, y + 80, x + 280, y + 180), outline=(255, 138, 61), width=3)
            draw.rectangle((x + 190, y + 180, x + 270, y + 320), outline=(255, 138, 61), width=3)
            draw.line((x + 190, y + 220, x + 130, y + 310), fill=(255, 138, 61), width=3)
            draw.line((x + 270, y + 220, x + 330, y + 310), fill=(255, 138, 61), width=3)
            draw.line((x + 210, y + 320, x + 170, y + 400), fill=(255, 138, 61), width=3)
            draw.line((x + 250, y + 320, x + 290, y + 400), fill=(255, 138, 61), width=3)
        draw.text((80, 1080), f"{entity_id}: {prompt[:180]}", fill=(190, 210, 228), font=font)
        output = io.BytesIO()
        image.save(output, format="PNG")
        return output.getvalue()

    def render_scene_fallback(self, scene_id: str, prompt: str, duration_ms: int) -> bytes:
        image = Image.new("RGB", (1280, 720), color=(8, 14, 20))
        draw = ImageDraw.Draw(image)
        font = ImageFont.load_default()
        draw.rectangle((0, 0, 1280, 720), fill=(14, 22, 30))
        draw.ellipse((820, 80, 1170, 430), fill=(255, 138, 61, 60), outline=(255, 138, 61))
        draw.rectangle((100, 430, 1180, 660), fill=(24, 38, 49), outline=(65, 198, 183), width=3)
        draw.text((70, 60), f"{scene_id} / {duration_ms} ms", fill=(255, 219, 173), font=font)
        draw.text((70, 110), prompt[:320], fill=(231, 240, 247), font=font)
        output = io.BytesIO()
        image.save(output, format="PNG")
        return output.getvalue()

    def extend_cloud_payload(self, ctx: ModuleContext, outputs: dict[str, object], config_payload: dict[str, Any]) -> None:
        output_dir = self.resolve_output_dir(ctx)
        audio_output_dir = ctx.workspace / "data" / "staged" / ctx.episode_id / "audio_anchor_forge"
        payload_zip_path = audio_output_dir / "render_payload.zip"
        payload_manifest_path = audio_output_dir / "render_payload_manifest.json"
        if not payload_zip_path.exists() or not payload_manifest_path.exists():
            return

        existing_manifest = RenderPayloadManifest.model_validate_json(payload_manifest_path.read_text(encoding="utf-8"))
        updated_files = set(existing_manifest.included_files)
        updated_files.add("project_bible.json")
        updated_files.add("configs/visual_generation_config.json")

        for relative_path in outputs:
            if relative_path.startswith("artifacts/character_sheets/"):
                updated_files.add(relative_path.replace("\\", "/"))

        buffer = io.BytesIO(payload_zip_path.read_bytes())
        rewritten = io.BytesIO()
        with zipfile.ZipFile(buffer, "r") as source_zip, zipfile.ZipFile(rewritten, "w", compression=zipfile.ZIP_DEFLATED) as target_zip:
            copied_names = set()
            for name in source_zip.namelist():
                target_zip.writestr(name, source_zip.read(name))
                copied_names.add(name)

            project_bible_path = ctx.workspace / "data" / "staged" / ctx.episode_id / "director_engine" / "project_bible.json"
            additions = {
                "payload/project_bible.json": project_bible_path.read_bytes(),
                "payload/configs/visual_generation_config.json": json.dumps(config_payload, ensure_ascii=False, indent=2).encode("utf-8"),
            }
            for relative_path, payload in outputs.items():
                if relative_path.startswith("artifacts/character_sheets/"):
                    target_name = f"payload/{relative_path.replace('\\', '/')}"
                    if isinstance(payload, bytes):
                        additions[target_name] = payload

            for target_name, payload in additions.items():
                target_zip.writestr(target_name, payload)

        outputs["render_payload.zip"] = rewritten.getvalue()
        outputs["render_payload_manifest.json"] = RenderPayloadManifest(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            execution_mode=ExecutionMode.CLOUD,
            payload_file="render_payload.zip",
            root_dir="payload/",
            included_files=sorted(updated_files),
        )
