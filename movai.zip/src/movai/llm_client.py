from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any

import requests
from pydantic import BaseModel, ValidationError

from .config import get_llm_profile

logger = logging.getLogger(__name__)


class LLMClientError(RuntimeError):
    pass


@dataclass(slots=True)
class LLMClient:
    base_url: str
    api_key: str
    model: str
    timeout: int = 120
    max_retries: int = 3

    @classmethod
    def from_env(cls, profile: str = "default") -> "LLMClient | None":
        settings = get_llm_profile(profile)
        if settings is None:
            return None
        return cls(
            base_url=settings.base_url,
            api_key=settings.api_key,
            model=settings.model,
            timeout=settings.timeout,
            max_retries=settings.max_retries,
        )

    def call_with_schema(
        self,
        prompt: str,
        response_model: type[BaseModel],
        system_prompt: str | None = None,
        temperature: float = 0.2,
    ) -> BaseModel:
        logger.info(f"[LLM] Calling with schema: model={response_model.__name__}, temperature={temperature}")
        schema_hint = json.dumps(response_model.model_json_schema(), ensure_ascii=False)
        messages: list[dict[str, str]] = []
        if system_prompt:
            messages.append(
                {
                    "role": "system",
                    "content": (
                        f"{system_prompt}\n\n"
                        "You must return a single JSON object matching this schema exactly:\n"
                        f"{schema_hint}"
                    ),
                }
            )
        messages.append(
            {
                "role": "user",
                "content": (
                    f"{prompt}\n\n"
                    "Return only valid JSON that matches the requested schema. "
                    "Do not include markdown fences or commentary."
                ),
            }
        )

        last_error = "unknown error"
        last_raw_content = ""
        for attempt in range(1, self.max_retries + 1):
            logger.info(f"[LLM] Attempt {attempt}/{self.max_retries}")
            try:
                raw_content = self._chat(messages=messages, temperature=temperature)
            except LLMClientError as exc:
                logger.error(f"[LLM] Attempt {attempt} failed during _chat: {exc}")
                last_error = str(exc)
                raise  # Re-raise immediately to fail loudly
            
            last_raw_content = raw_content
            try:
                payload = self._extract_json(raw_content)
                result = response_model.model_validate(payload)
                logger.info(f"[LLM] Schema validation successful for {response_model.__name__}")
                return result
            except (json.JSONDecodeError, ValidationError, ValueError) as exc:
                last_error = str(exc)
                logger.warning(f"[LLM] Validation failed on attempt {attempt}: {last_error}")
                messages.append({"role": "assistant", "content": raw_content})
                messages.append(
                    {
                        "role": "user",
                        "content": (
                            "The previous response could not be accepted.\n"
                            f"Validation error: {last_error}\n"
                            "Please regenerate the full response as valid JSON only, "
                            "strictly matching the schema."
                        ),
                    }
                )

        logger.error(f"[LLM] Failed after {self.max_retries} attempts. Last error: {last_error}")
        raise LLMClientError(
            f"LLM failed to return valid {response_model.__name__} JSON after {self.max_retries} attempts. "
            f"Last error: {last_error}. "
            f"Last raw response excerpt: {self._snippet(last_raw_content)}"
        )

    def _chat(self, messages: list[dict[str, str]], temperature: float) -> str:
        logger.info(f"[LLM] Sending request to {self.base_url} with model={self.model}, temperature={temperature}")
        try:
            response = requests.post(
                f"{self.base_url.rstrip('/')}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.model,
                    "messages": messages,
                    "temperature": temperature,
                    "response_format": {"type": "json_object"},
                },
                timeout=self.timeout,
            )
            logger.info(f"[LLM] Received response: status_code={response.status_code}")
        except requests.exceptions.Timeout as exc:
            logger.error(f"[LLM] Request timed out after {self.timeout}s: {exc}")
            raise LLMClientError(f"LLM request timed out after {self.timeout} seconds") from exc
        except requests.exceptions.ConnectionError as exc:
            logger.error(f"[LLM] Connection failed: {exc}")
            raise LLMClientError(f"LLM connection failed: {exc}") from exc
        except requests.exceptions.RequestException as exc:
            logger.error(f"[LLM] Request failed: {exc}: {response.text if 'response' in locals() else 'N/A'}")
            raise LLMClientError(f"LLM request failed: {exc}") from exc

        try:
            response.raise_for_status()
        except requests.HTTPError as exc:
            logger.error(f"[LLM] HTTP error: {exc}: {response.text}")
            raise LLMClientError(f"LLM HTTP error: {exc}: {response.text}") from exc

        try:
            data = response.json()
        except json.JSONDecodeError as exc:
            logger.error(f"[LLM] Invalid JSON response: {response.text[:200]}")
            raise LLMClientError(f"LLM returned invalid JSON: {exc}") from exc

        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            logger.error(f"[LLM] Unexpected response structure: {data}")
            raise LLMClientError(f"Unexpected LLM response structure: {data}") from exc

        if isinstance(content, list):
            text_parts = []
            for item in content:
                if isinstance(item, dict) and item.get("type") == "text":
                    text_parts.append(item.get("text", ""))
            content = "".join(text_parts)
        if not isinstance(content, str) or not content.strip():
            logger.error(f"[LLM] Empty content received: {data}")
            raise LLMClientError(f"LLM returned empty content: {data}")
        logger.info(f"[LLM] Successfully extracted content (length={len(content)})")
        return content.strip()

    def _extract_json(self, raw_content: str) -> dict[str, Any]:
        candidate = raw_content.strip()
        if candidate.startswith("```"):
            candidate = candidate.strip("`")
            candidate = candidate.replace("json", "", 1).strip()
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            start = candidate.find("{")
            end = candidate.rfind("}")
            if start == -1 or end == -1 or end <= start:
                raise
            return json.loads(candidate[start : end + 1])

    def _snippet(self, text: str, limit: int = 600) -> str:
        cleaned = " ".join((text or "").split())
        if len(cleaned) <= limit:
            return cleaned
        return cleaned[: limit - 3] + "..."
