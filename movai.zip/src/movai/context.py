from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from schemas import ExecutionMode


@dataclass(slots=True)
class ModuleContext:
    project_id: str
    episode_id: str
    run_id: str
    workspace: Path
    execution_mode: ExecutionMode = ExecutionMode.LOCAL
    source_uri: str | None = None
    source_type_hint: str | None = None
    chapter_range: str | None = None
    source_keywords: str | None = None
    style_label: str | None = None
    visual_lut: str | None = None
    narrator_voice_id: str | None = None
    output_dir: Path | None = None
    reports_dir: Path | None = None
    emit_templates: bool = False
    force: bool = False
    dry_run: bool = False
    prompt_review: bool = True

    def resolved_reports_dir(self) -> Path:
        return self.reports_dir or self.workspace / "reports" / self.episode_id
