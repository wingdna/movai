from __future__ import annotations

import asyncio
import hashlib
from dataclasses import dataclass
from functools import lru_cache
from typing import Any

import edge_tts

from .config import get_tts_settings


MANDARIN_LOCALE_PREFIXES = ("zh-CN", "zh-TW")
EXCLUDED_LOCALE_PREFIXES = ("zh-HK",)
VARIANT_PRIORITY = {
    "mainland_standard": 0,
    "taiwan_mandarin": 1,
    "southwestern_mandarin": 2,
    "northeast_mandarin": 3,
    "northwestern_mandarin": 4,
    "other_mandarin": 5,
}


@dataclass(frozen=True, slots=True)
class VoiceProfile:
    short_name: str
    locale: str
    gender: str
    friendly_name: str
    variant: str


def _run_async(coro):
    try:
        return asyncio.run(coro)
    except RuntimeError:
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(coro)
        finally:
            loop.close()


def classify_variant(voice: dict[str, Any]) -> str:
    locale = str(voice.get("Locale", "")).lower()
    short_name = str(voice.get("ShortName", "")).lower()
    friendly = str(voice.get("FriendlyName", "")).lower()
    combined = f"{locale} {short_name} {friendly}"
    if locale.startswith("zh-tw"):
        return "taiwan_mandarin"
    if "sichuan" in combined or "southwestern" in combined or "xiaorou" in combined:
        return "southwestern_mandarin"
    if "liaoning" in combined or "dongbei" in combined or "xiaobei" in combined:
        return "northeast_mandarin"
    if "shaanxi" in combined or "xiaoni" in combined or "henan" in combined:
        return "northwestern_mandarin"
    if locale.startswith("zh-cn"):
        return "mainland_standard"
    return "other_mandarin"


def is_mandarin_voice(voice: dict[str, Any]) -> bool:
    locale = str(voice.get("Locale", ""))
    if any(locale.startswith(prefix) for prefix in EXCLUDED_LOCALE_PREFIXES):
        return False
    if not any(locale.startswith(prefix) for prefix in MANDARIN_LOCALE_PREFIXES):
        return False
    combined = " ".join(
        str(voice.get(key, "")).lower()
        for key in ("Locale", "ShortName", "FriendlyName")
    )
    excluded_markers = ("cantonese", "yue", "wu", "shanghai", "粤语", "吴语", "上海话")
    return not any(marker in combined for marker in excluded_markers)


@lru_cache(maxsize=1)
def list_mandarin_voices() -> list[VoiceProfile]:
    try:
        raw_voices = _run_async(edge_tts.list_voices())
    except Exception as exc:
        raise RuntimeError(
            "Failed to fetch Edge TTS voice catalog. "
            "Please check network access and edge-tts availability."
        ) from exc
    voices: list[VoiceProfile] = []
    for voice in raw_voices:
        if not is_mandarin_voice(voice):
            continue
        voices.append(
            VoiceProfile(
                short_name=str(voice.get("ShortName", "")),
                locale=str(voice.get("Locale", "")),
                gender=str(voice.get("Gender", "")),
                friendly_name=str(voice.get("FriendlyName", "")),
                variant=classify_variant(voice),
            )
        )
    voices.sort(key=lambda item: (VARIANT_PRIORITY.get(item.variant, 99), item.locale, item.short_name))
    if not voices:
        raise RuntimeError(
            "Edge TTS returned no usable Mandarin voices. "
            "Expected Mandarin voices from zh-CN / zh-TW and excluded Cantonese / Wu / Shanghai families."
        )
    return voices


def voice_catalog_payload() -> dict[str, Any]:
    voices = list_mandarin_voices()
    by_variant: dict[str, list[str]] = {}
    for voice in voices:
        by_variant.setdefault(voice.variant, []).append(voice.short_name)
    return {
        "provider": "edge-tts",
        "voice_count": len(voices),
        "voices": [
            {
                "short_name": voice.short_name,
                "locale": voice.locale,
                "gender": voice.gender,
                "friendly_name": voice.friendly_name,
                "variant": voice.variant,
            }
            for voice in voices
        ],
        "by_variant": by_variant,
    }


def choose_narrator_voice() -> str:
    tts_settings = get_tts_settings()
    voices = list_mandarin_voices()
    available = {voice.short_name for voice in voices}
    if tts_settings.narrator_voice in available:
        return tts_settings.narrator_voice
    for preferred in ("zh-CN-YunzeNeural", "zh-CN-YunyangNeural", "zh-CN-YunjianNeural", "zh-TW-YunJheNeural"):
        if preferred in available:
            return preferred
    if voices:
        return voices[0].short_name
    return tts_settings.narrator_voice


def choose_voice_for_entity(entity_id: str, role: str | None, assigned: set[str], narrator_voice: str) -> str:
    voices = [voice for voice in list_mandarin_voices() if voice.short_name != narrator_voice]
    if not voices:
        return narrator_voice

    preferred_variants = ["mainland_standard", "taiwan_mandarin", "southwestern_mandarin", "northeast_mandarin", "northwestern_mandarin"]
    if role and "primary" in role.lower():
        preferred_variants = ["mainland_standard", "taiwan_mandarin", "northeast_mandarin", "northwestern_mandarin", "southwestern_mandarin"]

    ordered_pool: list[VoiceProfile] = []
    for variant in preferred_variants:
        ordered_pool.extend([voice for voice in voices if voice.variant == variant and voice.short_name not in assigned])
    ordered_pool.extend([voice for voice in voices if voice.short_name not in assigned and voice not in ordered_pool])
    if not ordered_pool:
        ordered_pool = voices

    digest = hashlib.sha1(entity_id.encode("utf-8", errors="ignore")).hexdigest()
    index = int(digest[:8], 16) % len(ordered_pool)
    return ordered_pool[index].short_name
