from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


_ENV_LOADED = False


def load_env_file(start_dir: Path | None = None) -> Path | None:
    global _ENV_LOADED
    if _ENV_LOADED:
        return None

    candidates: list[Path] = []
    if start_dir is not None:
        start = start_dir.resolve()
        candidates.extend(start.parents)
        candidates.insert(0, start)
    else:
        candidates.extend(Path.cwd().resolve().parents)
        candidates.insert(0, Path.cwd().resolve())

    seen: set[Path] = set()
    for root in candidates:
        env_path = root / ".env"
        if env_path in seen:
            continue
        seen.add(env_path)
        if env_path.exists():
            for raw_line in env_path.read_text(encoding="utf-8").splitlines():
                line = raw_line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip("'\"")
                if key and key not in os.environ:
                    os.environ[key] = value
            _ENV_LOADED = True
            return env_path

    _ENV_LOADED = True
    return None


def _env(*names: str, default: str | None = None) -> str | None:
    for name in names:
        value = os.getenv(name)
        if value is not None and value != "":
            return value
    return default


def _env_int(*names: str, default: int) -> int:
    value = _env(*names)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


@dataclass(frozen=True, slots=True)
class LLMProfileSettings:
    profile: str
    base_url: str
    api_key: str
    model: str
    timeout: int
    max_retries: int


@dataclass(frozen=True, slots=True)
class VisualModelSettings:
    base_url: str | None
    api_key: str | None
    model: str
    timeout: int
    max_retries: int


@dataclass(frozen=True, slots=True)
class TTSSettings:
    provider: str
    default_voice: str
    narrator_voice: str


def get_llm_profile(profile: str = "default") -> LLMProfileSettings | None:
    load_env_file()
    token = profile.strip().upper().replace("-", "_")
    base_url = _env(
        f"MOVAI_{token}_BASE_URL",
        "MOVAI_SILICONFLOW_BASE_URL",
        "MOVAI_OPENAI_COMPAT_BASE_URL",
        "MOVAI_LLM_BASE_URL",
        "OPENAI_BASE_URL",
    )
    api_key = _env(
        f"MOVAI_{token}_API_KEY",
        "MOVAI_SILICONFLOW_API_KEY",
        "MOVAI_OPENAI_COMPAT_API_KEY",
        "MOVAI_LLM_API_KEY",
        "OPENAI_API_KEY",
    )
    model = _env(
        f"MOVAI_{token}_MODEL",
        "MOVAI_LLM_MODEL",
        "OPENAI_MODEL",
    )
    if not (base_url and api_key and model):
        return None
    timeout = _env_int(f"MOVAI_{token}_TIMEOUT", "MOVAI_LLM_TIMEOUT", default=120)
    max_retries = _env_int(f"MOVAI_{token}_MAX_RETRIES", "MOVAI_LLM_MAX_RETRIES", default=3)
    return LLMProfileSettings(
        profile=profile,
        base_url=base_url,
        api_key=api_key,
        model=model,
        timeout=timeout,
        max_retries=max_retries,
    )


def get_visual_model_settings() -> VisualModelSettings:
    load_env_file()
    return VisualModelSettings(
        base_url=_env("MOVAI_VISUAL_BASE_URL", "MOVAI_KOLORS_BASE_URL", "MOVAI_SILICONFLOW_BASE_URL"),
        api_key=_env("MOVAI_VISUAL_API_KEY", "MOVAI_SILICONFLOW_API_KEY", "MOVAI_KOLORS_API_KEY"),
        model=_env("MOVAI_VISUAL_MODEL", "MOVAI_KOLORS_MODEL", default="Kwai-Kolors/Kolors") or "Kwai-Kolors/Kolors",
        timeout=_env_int("MOVAI_VISUAL_TIMEOUT", "MOVAI_KOLORS_TIMEOUT", default=120),
        max_retries=_env_int("MOVAI_VISUAL_MAX_RETRIES", "MOVAI_KOLORS_MAX_RETRIES", default=4),
    )


def get_tts_settings() -> TTSSettings:
    load_env_file()
    return TTSSettings(
        provider=_env("MOVAI_TTS_PROVIDER", default="edge-tts") or "edge-tts",
        default_voice=_env("MOVAI_TTS_DEFAULT_VOICE", default="en-US-BrianNeural") or "en-US-BrianNeural",
        narrator_voice=_env("MOVAI_TTS_NARRATOR_VOICE", default="zh-CN-YunzeNeural") or "zh-CN-YunzeNeural",
    )
