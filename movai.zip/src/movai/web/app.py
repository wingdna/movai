from __future__ import annotations

import argparse
import hashlib
import logging
import re
import threading
import uuid
import traceback
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import uvicorn
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from schemas import BeatSheet, ExecutionMode, Manifest, ModuleName, ModuleStatus, ProjectBible, RawSource

from ..config import load_env_file
from ..context import ModuleContext
from ..io_utils import read_json, write_payload
from ..modules.master_hub import MasterHubModule, REVIEW_GATE_MESSAGES
from ..modules.source_ingester import SourceIngesterModule
from ..registry import build_registry
from .translations import simple_translate

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

APP_TITLE = "MOVAI Studio"
PIPELINE_KEY = "master-hub"
GATE_STAGE_MAP = {
    1: ModuleName.DIRECTOR_ENGINE,
    2: ModuleName.VISUAL_ASSET_FOUNDRY,
    3: ModuleName.RENDER_ENGINE,
}
JOB_TERMINAL_STATES = {"success", "failed"}
PIPELINE_STAGE_ORDER: list[ModuleName] = [
    ModuleName.SOURCE_INGESTER,
    ModuleName.DIRECTOR_ENGINE,
    ModuleName.WRITER_ENGINE,
    ModuleName.AUDIO_ANCHOR_FORGE,
    ModuleName.VISUAL_ASSET_FOUNDRY,
    ModuleName.RENDER_ENGINE,
    ModuleName.GLOBAL_DISTRIBUTOR,
    ModuleName.MASTER_HUB,
]
STAGE_META: dict[ModuleName, dict[str, str]] = {
    ModuleName.SOURCE_INGESTER: {"slug": "source-ingester", "zh": "数据采集", "en": "Data Ingest"},
    ModuleName.DIRECTOR_ENGINE: {"slug": "director-engine", "zh": "世界观导演", "en": "Director Engine"},
    ModuleName.WRITER_ENGINE: {"slug": "writer-engine", "zh": "分镜编剧", "en": "Writer Engine"},
    ModuleName.AUDIO_ANCHOR_FORGE: {"slug": "audio-anchor-forge", "zh": "音频锚点", "en": "Audio Anchor"},
    ModuleName.VISUAL_ASSET_FOUNDRY: {"slug": "visual-asset-foundry", "zh": "视觉资产", "en": "Visual Foundry"},
    ModuleName.RENDER_ENGINE: {"slug": "render-engine", "zh": "2.5D 渲染", "en": "2.5D Render"},
    ModuleName.GLOBAL_DISTRIBUTOR: {"slug": "global-distributor", "zh": "全球分发", "en": "Global Distributor"},
    ModuleName.MASTER_HUB: {"slug": "master-hub", "zh": "总控台", "en": "Master Hub"},
}
SLUG_TO_STAGE = {meta["slug"]: stage for stage, meta in STAGE_META.items()}

# Define base directory for static files and templates
BASE_DIR = Path(__file__).parent

# Initialize Jinja2 templates
TEMPLATES = Jinja2Templates(directory=str(BASE_DIR / "templates"))

app = FastAPI(title=APP_TITLE)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
load_env_file()


def resolve_workspace_path(raw_path: str) -> Path:
    candidate = Path(raw_path)
    if not candidate.is_absolute():
        candidate = workspace_root() / candidate
    resolved = candidate.resolve()
    root = workspace_root().resolve()
    if root not in resolved.parents and resolved != root:
        raise HTTPException(status_code=403, detail="Path escapes workspace root.")
    if not resolved.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {resolved}")
    return resolved


class JobManager:
    def __init__(self) -> None:
        self._executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="movai-web")
        self._lock = threading.Lock()
        self._jobs: dict[str, dict[str, Any]] = {}

    @staticmethod
    def _stamp() -> str:
        return datetime.now(timezone.utc).isoformat()

    def _entry(self, *, job_id: str, project_id: str, episode_id: str, run_id: str, module_key: str) -> dict[str, Any]:
        return {
            "job_id": job_id,
            "project_id": project_id,
            "episode_id": episode_id,
            "run_id": run_id,
            "module_key": module_key,
            "status": "queued",
            "created_at": self._stamp(),
            "started_at": None,
            "finished_at": None,
            "result": None,
            "error": None,
        }

    def enqueue(self, *, project_id: str, episode_id: str, run_id: str, module_key: str, task: Any) -> dict[str, Any]:
        with self._lock:
            active = self.latest_for_episode(project_id, episode_id, run_id)
            if active and active["status"] not in JOB_TERMINAL_STATES:
                raise RuntimeError(f"Job already in progress for {episode_id}: {active['module_key']}")
            job_id = uuid.uuid4().hex[:12]
            entry = self._entry(
                job_id=job_id,
                project_id=project_id,
                episode_id=episode_id,
                run_id=run_id,
                module_key=module_key,
            )
            self._jobs[job_id] = entry
            logger.info(f"[JobManager] Enqueued job {job_id[:8]} for {module_key} episode {episode_id}")

        def runner() -> None:
            logger.info(f"[JobManager] Starting job {job_id[:8]} for {module_key}")
            self.mark_started(job_id)
            try:
                result = task()
                logger.info(f"[JobManager] Job {job_id[:8]} completed successfully")
            except Exception as exc:  # pragma: no cover - background safety
                logger.error(f"[JobManager] Job {job_id[:8]} failed: {exc}", exc_info=True)
                self.mark_finished(job_id, status="failed", error=format_exception_summary(exc))
                return
            self.mark_finished(job_id, status="success", result=result)

        self._executor.submit(runner)
        return self.get(job_id)

    def mark_finished(self, job_id: str, *, status: str, result: Any | None = None, error: str | None = None) -> None:
        with self._lock:
            self._jobs[job_id]["status"] = status
            self._jobs[job_id]["finished_at"] = self._stamp()
            self._jobs[job_id]["result"] = result
            self._jobs[job_id]["error"] = error

    def get(self, job_id: str) -> dict[str, Any]:
        with self._lock:
            if job_id not in self._jobs:
                raise KeyError(job_id)
            return dict(self._jobs[job_id])

    def latest_for_episode(self, project_id: str, episode_id: str, run_id: str) -> dict[str, Any] | None:
        """Get the most recent job for a specific episode."""
        with self._lock:
            # Find all jobs for this episode
            episode_jobs = [
                job for job in self._jobs.values()
                if job["episode_id"] == episode_id and job["project_id"] == project_id and job["run_id"] == run_id
            ]
            if not episode_jobs:
                return None
            # Return the most recent one (by created_at timestamp)
            return max(episode_jobs, key=lambda j: j["created_at"])


job_manager = JobManager()


def format_exception_summary(exc: Exception, *, limit: int = 2200) -> str:
    trace = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    summary = f"{exc.__class__.__name__}: {exc}\n{trace}"
    return summary[:limit]


def workspace_root() -> Path:
    return Path.cwd()


def build_context(
    project_id: str,
    episode_id: str,
    run_id: str,
    *,
    execution_mode: ExecutionMode = ExecutionMode.LOCAL,
    source_uri: str | None = None,
    source_type_hint: str | None = None,
    chapter_range: str | None = None,
    source_keywords: str | None = None,
    style_label: str | None = None,
    visual_lut: str | None = None,
    narrator_voice_id: str | None = None,
    prompt_review: bool = False,
) -> ModuleContext:
    return ModuleContext(
        project_id=project_id,
        episode_id=episode_id,
        run_id=run_id,
        workspace=workspace_root(),
        execution_mode=execution_mode,
        source_uri=source_uri,
        source_type_hint=source_type_hint,
        chapter_range=chapter_range,
        source_keywords=source_keywords,
        style_label=style_label,
        visual_lut=visual_lut,
        narrator_voice_id=narrator_voice_id,
        force=True,
        prompt_review=prompt_review,
    )


def parse_execution_mode(value: str | None) -> ExecutionMode:
    if not value:
        return ExecutionMode.LOCAL
    try:
        return ExecutionMode(value)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=f"Unsupported execution_mode: {value}") from exc


def load_json_if_exists(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    return read_json(path)


def load_manifest_if_exists(project_id: str, episode_id: str, run_id: str) -> Manifest | None:
    ctx = build_context(project_id=project_id, episode_id=episode_id, run_id=run_id)
    path = MasterHubModule().manifest_path(ctx)
    if not path.exists():
        return None
    return Manifest.model_validate_json(path.read_text(encoding="utf-8"))


def raw_source_path(episode_id: str) -> Path:
    return workspace_root() / "data" / "staged" / episode_id / "source_ingester" / "raw_source.json"


def upload_dir(episode_id: str) -> Path:
    return workspace_root() / "data" / "uploads" / episode_id / "source_ingester"


def has_valid_raw_source(raw_source: dict[str, Any] | None) -> bool:
    if not raw_source:
        return False
    for partition in raw_source.get("source_partitions", []):
        for chunk in partition.get("text_chunks", []):
            if (chunk.get("text") or "").strip():
                return True
    return False


STORY_HEADING_RE = re.compile(
    r"^\s*(第\s*[0-9一二三四五六七八九十百千万萬零]+\s*[回章节節篇卷则則幕]|[0-9一二三四五六七八九十百千万萬零]{1,4}\s*[.)、．）]\s*\S+|chapter\s+\d+|book\s+\d+)",
    re.IGNORECASE,
)


def story_heading_from_chunk(chunk: dict[str, Any]) -> str:
    chapter_label = (chunk.get("chapter_label") or "").strip()
    if chapter_label and STORY_HEADING_RE.search(chapter_label) and chapter_label.lower() != "partition 1":
        return chapter_label
    text = (chunk.get("text") or "").strip()
    if not text:
        return chapter_label or "未命名片段"
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    for line in lines[:20]:
        candidate = line.strip()
        if candidate and STORY_HEADING_RE.search(candidate):
            return candidate[:120]
    for line in lines[:20]:
        candidate = line.strip()
        if not candidate:
            continue
        if len(candidate) <= 24 and not re.search(r"[，。！？；：,.!?;:]", candidate):
            return candidate
    chunk_id = (chunk.get("chunk_id") or "").strip()
    if chunk_id:
        return f"故事 {chunk_id}"
    return chapter_label or "未命名片段"


def build_source_outline(raw_source: dict[str, Any] | None) -> dict[str, Any]:
    if not raw_source:
        return {"volumes": [], "story_count": 0}
    partitions = raw_source.get("source_partitions", [])
    volumes: list[dict[str, Any]] = []
    story_count = 0
    multi_volume_mode = any(
        re.search(r"(第\s*[一二三四五六七八九十百千万萬零0-9]+\s*卷|卷\s*[一二三四五六七八九十百千万萬零0-9]+)", (p.get("label") or ""), re.IGNORECASE)
        for p in partitions
    )
    for p_index, partition in enumerate(partitions):
        partition_id = partition.get("partition_id") or f"PART_{p_index + 1:03d}"
        volume_label = partition.get("label") or partition_id
        stories: list[dict[str, Any]] = []
        story_by_label: dict[str, dict[str, Any]] = {}
        for c_index, chunk in enumerate(partition.get("text_chunks", [])):
            label = story_heading_from_chunk(chunk)
            if label in {"Partition 1", "Full Text", "未命名片段"}:
                fallback = (chunk.get("text") or "").strip().splitlines()
                for line in fallback[:12]:
                    candidate = line.strip()
                    if candidate and len(candidate) <= 28 and not re.search(r"[，。！？；：,.!?;:]", candidate):
                        label = candidate
                        break
                if label in {"Partition 1", "Full Text", "未命名片段"}:
                    label = f"故事 {len(stories) + 1:02d}"
            if label not in story_by_label:
                story_uid = f"{partition_id}::story_{len(stories) + 1:03d}"
                story = {
                    "story_uid": story_uid,
                    "label": label,
                    "chunk_ids": [],
                    "chunk_count": 0,
                    "preview": "",
                    "substories": [],
                }
                story_by_label[label] = story
                stories.append(story)
                story_count += 1
            current = story_by_label[label]
            chunk_id = chunk.get("chunk_id") or f"{partition_id}_chunk_{c_index + 1:03d}"
            current["chunk_ids"].append(chunk_id)
            current["chunk_count"] += 1
            if not current["preview"]:
                current["preview"] = (chunk.get("text") or "").strip()[:160]
            sub_label = (chunk.get("chapter_label") or "").strip()
            if not sub_label or sub_label.lower() in {"partition 1", "full text", "?????"}:
                text_lines = [ln.strip() for ln in (chunk.get("text") or "").splitlines() if ln.strip()]
                for candidate in text_lines[:12]:
                    if len(candidate) <= 28 and not re.search(r"[??????,.!?;:]", candidate):
                        sub_label = candidate
                        break
            if not sub_label:
                sub_label = f"??{current['chunk_count']}"
            sub_uid = f"{current['story_uid']}::sub_{current['chunk_count']:03d}"
            current["substories"].append(
                {
                    "substory_uid": sub_uid,
                    "label": sub_label,
                    "chunk_id": chunk_id,
                }
            )

        if not multi_volume_mode and len(stories) > 1 and story_count == len(stories):
            # keep a single volume but preserve all story nodes under it
            volume_label = "单卷 / 多故事"
        volumes.append(
            {
                "partition_id": partition_id,
                "label": volume_label,
                "chunk_count": len(partition.get("text_chunks", [])),
                "stories": stories,
            }
        )
    return {"volumes": volumes, "story_count": story_count}


def apply_story_selection(raw_source: RawSource, story_uid: str | None) -> RawSource:
    if not story_uid:
        return raw_source
    outline = build_source_outline(raw_source.model_dump(mode="json"))
    selected_story: dict[str, Any] | None = None
    selected_partition: dict[str, Any] | None = None
    for volume in outline["volumes"]:
        for story in volume["stories"]:
            if story["story_uid"] == story_uid:
                selected_story = story
                selected_partition = volume
                break
        if selected_story is not None:
            break
    if selected_story is None or selected_partition is None:
        raise ValueError("Selected story was not found in current raw_source.")

    payload = raw_source.model_dump(mode="json")
    filtered_partitions: list[dict[str, Any]] = []
    for partition in payload.get("source_partitions", []):
        if partition.get("partition_id") != selected_partition["partition_id"]:
            continue
        selected_ids = set(selected_story["chunk_ids"])
        kept_chunks = [chunk for chunk in partition.get("text_chunks", []) if (chunk.get("chunk_id") or "") in selected_ids]
        partition["text_chunks"] = kept_chunks
        partition["label"] = selected_story["label"]
        filtered_partitions.append(partition)
        break
    payload["source_partitions"] = filtered_partitions
    return RawSource.model_validate(payload)


def progress_book_id(raw_source_payload: dict[str, Any]) -> str:
    title = (raw_source_payload.get("title") or "unknown").strip()
    source_uri = (raw_source_payload.get("source_uri") or "").strip()
    digest = hashlib.sha1(f"{title}|{source_uri}".encode("utf-8", errors="ignore")).hexdigest()[:12]
    return f"{title[:24].replace(' ', '_')}_{digest}"


def progress_path(project_id: str, raw_source_payload: dict[str, Any]) -> Path:
    pid = project_id or "default"
    book_id = progress_book_id(raw_source_payload)
    return workspace_root() / "data" / "progress" / pid / f"{book_id}.json"


def load_source_progress(project_id: str, raw_source_payload: dict[str, Any] | None) -> dict[str, Any] | None:
    if not raw_source_payload:
        return None
    path = progress_path(project_id, raw_source_payload)
    if not path.exists():
        return {
            "project_id": project_id,
            "book_id": progress_book_id(raw_source_payload),
            "title": raw_source_payload.get("title"),
            "source_uri": raw_source_payload.get("source_uri"),
            "processed_story_uids": [],
            "story_episode_map": {},
        }
    return read_json(path)


def save_source_progress(
    project_id: str,
    raw_source_payload: dict[str, Any],
    *,
    processed_story_uids: list[str],
    story_episode_map: dict[str, str],
) -> None:
    path = progress_path(project_id, raw_source_payload)
    payload = {
        "project_id": project_id,
        "book_id": progress_book_id(raw_source_payload),
        "title": raw_source_payload.get("title"),
        "source_uri": raw_source_payload.get("source_uri"),
        "processed_story_uids": sorted(set(processed_story_uids)),
        "story_episode_map": story_episode_map,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    write_payload(path, payload, overwrite=True)


def update_source_progress(project_id: str, raw_source_payload: dict[str, Any], story_uid_to_episode: dict[str, str]) -> dict[str, Any]:
    current = load_source_progress(project_id, raw_source_payload) or {}
    processed = list(current.get("processed_story_uids", []))
    mapping = dict(current.get("story_episode_map", {}))
    for story_uid, episode_id in story_uid_to_episode.items():
        if story_uid not in processed:
            processed.append(story_uid)
        mapping[story_uid] = episode_id
    save_source_progress(project_id, raw_source_payload, processed_story_uids=processed, story_episode_map=mapping)
    return {
        "processed_story_uids": processed,
        "story_episode_map": mapping,
    }


def next_episode_ids(base_episode_id: str, count: int) -> list[str]:
    match = re.match(r"^(.*?)(\d+)$", base_episode_id or "")
    if not match:
        prefix = (base_episode_id or "EP_").rstrip("_") + "_"
        start = 1
    else:
        prefix = match.group(1)
        start = int(match.group(2))
    width = 2
    return [f"{prefix}{str(start + i).zfill(width)}" for i in range(count)]


def mark_source_confirmed(project_id: str, episode_id: str, run_id: str, source_path: Path) -> None:
    ctx = build_context(project_id=project_id, episode_id=episode_id, run_id=run_id, prompt_review=False)
    hub = MasterHubModule()
    manifest = hub.load_manifest(ctx)
    source_stage = hub.stage_record(manifest, ModuleName.SOURCE_INGESTER)
    source_stage.status = ModuleStatus.SUCCESS
    source_stage.error_message = None
    source_stage.output_files = [str(source_path)]
    manifest.last_completed_stage = ModuleName.SOURCE_INGESTER
    manifest.current_stage = ModuleName.DIRECTOR_ENGINE
    manifest.overall_status = ModuleStatus.PENDING
    manifest.review_gate_pending = None
    hub.save_manifest(ctx, manifest)


def try_start_director_engine(project_id: str, episode_id: str, run_id: str) -> dict[str, Any] | None:
    ctx = build_context(project_id=project_id, episode_id=episode_id, run_id=run_id, prompt_review=False)

    def task() -> dict[str, Any]:
        return run_registry_module("director-engine", ctx)

    try:
        return job_manager.enqueue(
            project_id=project_id,
            episode_id=episode_id,
            run_id=run_id,
            module_key="director-engine",
            task=task,
        )
    except RuntimeError:
        return job_manager.latest_for_episode(project_id, episode_id, run_id)


def stage_output_dir(episode_id: str, module_key: str) -> Path:
    registry = build_registry()
    module = registry[module_key]
    ctx = build_context(project_id="dashboard", episode_id=episode_id, run_id="dashboard")
    return module.resolve_output_dir(ctx)


def stage_artifacts(stage_name: ModuleName, manifest: Manifest | None) -> list[str]:
    if manifest is not None:
        for stage in manifest.stages:
            if stage.stage_name == stage_name and stage.output_files:
                return stage.output_files
    return []


def to_workspace_url(path: Path | str | None) -> str | None:
    if path is None:
        return None
    value = str(path)
    return f"/workspace-file?path={value}"


def list_files(directory: Path, pattern: str) -> list[Path]:
    if not directory.exists():
        return []
    return sorted(directory.glob(pattern))


def load_scene_assets(episode_id: str) -> dict[str, Any]:
    staged = workspace_root() / "data" / "staged" / episode_id
    master_script = load_json_if_exists(staged / "writer_engine" / "master_script.json") or {}
    timed_script = load_json_if_exists(staged / "audio_anchor_forge" / "timed_script.json") or {}
    visuals_dir = staged / "visual_asset_foundry" / "artifacts" / "visuals"
    character_dir = staged / "visual_asset_foundry" / "artifacts" / "character_sheets"
    poster_path = staged / "visual_asset_foundry" / "artifacts" / "posters" / "raw_poster.png"

    timed_by_scene = {scene["scene_id"]: scene for scene in timed_script.get("scenes", [])}
    review_rows: list[dict[str, Any]] = []
    for scene in master_script.get("scenes", []):
        scene_id = scene.get("scene_id")
        timed_scene = timed_by_scene.get(scene_id, {})
        image_path = visuals_dir / f"{scene_id}_rgb.png"
        depth_path = visuals_dir / f"{scene_id}_depth.png"
        audio_preview = None
        for track in timed_scene.get("audio_tracks", []):
            if track.get("type") in {"narrator", "dialogue"} and track.get("file_path"):
                audio_preview = track["file_path"]
                break
        review_rows.append(
            {
                "scene_id": scene_id,
                "sequence_no": scene.get("sequence_no"),
                "summary": scene.get("scene_summary"),
                "narration_text": scene.get("narration_text"),
                "image_url": to_workspace_url(image_path) if image_path.exists() else None,
                "depth_url": to_workspace_url(depth_path) if depth_path.exists() else None,
                "audio_url": to_workspace_url(audio_preview),
            }
        )

    return {
        "master_script": master_script,
        "timed_script": timed_script,
        "visual_gallery": [
            {"name": path.name, "url": to_workspace_url(path)}
            for path in list_files(visuals_dir, "*_rgb.png")
        ],
        "character_sheets": [
            {"name": path.name, "url": to_workspace_url(path)}
            for path in list_files(character_dir, "*.png")
        ],
        "poster_url": to_workspace_url(poster_path) if poster_path.exists() else None,
        "review_rows": review_rows,
    }


def load_recent_logs(episode_id: str) -> list[dict[str, Any]]:
    reports_dir = workspace_root() / "reports" / episode_id
    if not reports_dir.exists():
        return []
    logs: list[dict[str, Any]] = []
    for path in sorted(reports_dir.glob("*.json"), key=lambda item: item.stat().st_mtime, reverse=True)[:12]:
        try:
            payload = read_json(path)
        except Exception:
            continue
        logs.append(
            {
                "timestamp": payload.get("finished_at") or payload.get("started_at"),
                "module_name": payload.get("module_name"),
                "status": payload.get("status"),
                "message": payload.get("error_message") or ", ".join(payload.get("warnings", [])[:1]) or "Stage updated.",
                "error": payload.get("error_message"),
                "report_path": str(path),
            }
        )
    return logs


def gate_payload(manifest: Manifest | None) -> dict[str, Any] | None:
    if manifest is None or manifest.review_gate_pending is None:
        return None
    gate_no = manifest.review_gate_pending
    stage_name = GATE_STAGE_MAP.get(gate_no)
    return {
        "gate_no": gate_no,
        "message": REVIEW_GATE_MESSAGES[gate_no],
        "stage_name": stage_name.value if stage_name else None,
        "can_edit_documents": gate_no == 1,
    }


def dashboard_snapshot(project_id: str, episode_id: str, run_id: str) -> dict[str, Any]:
    registry = build_registry()
    hub = MasterHubModule()
    manifest = load_manifest_if_exists(project_id, episode_id, run_id)

    source_path = raw_source_path(episode_id)
    director_root = workspace_root() / "data" / "staged" / episode_id / "director_engine"
    raw_source = load_json_if_exists(source_path)
    raw_outline = build_source_outline(raw_source)
    source_progress = load_source_progress(project_id, raw_source)
    project_bible = load_json_if_exists(director_root / "project_bible.json")
    beat_sheet = load_json_if_exists(director_root / "beat_sheet.json")
    scene_assets = load_scene_assets(episode_id)
    latest_job = job_manager.latest_for_episode(project_id, episode_id, run_id)
    logs = load_recent_logs(episode_id)
    if latest_job and latest_job.get("status") == "failed" and latest_job.get("error"):
        logs = [
            {
                "timestamp": latest_job.get("finished_at") or latest_job.get("started_at"),
                "module_name": latest_job.get("module_key"),
                "status": latest_job.get("status"),
                "message": latest_job.get("error"),
                "error": latest_job.get("error"),
                "report_path": None,
            },
            *logs,
        ][:12]

    stages: list[dict[str, Any]] = []
    for stage_name in hub.stage_order:
        module_key = hub.stage_to_key[stage_name]
        module = registry[module_key]
        record = None
        if manifest is not None:
            try:
                record = hub.stage_record(manifest, stage_name)
            except KeyError:
                record = None
        output_dir = stage_output_dir(episode_id, module_key)
        report_path = None if record is None else record.report_path
        status = ModuleStatus.PENDING if record is None else record.status
        stages.append(
            {
                "module_key": module_key,
                "module_name": stage_name.value,
                "description": module.spec.description,
                "output_dir": str(output_dir),
                "status": status.value,
                "gate_after": hub.gate_after.get(stage_name),
                "current": bool(manifest and manifest.current_stage == stage_name),
                "last_completed": bool(manifest and manifest.last_completed_stage == stage_name),
                "report_path": report_path,
                "error_message": None if record is None else record.error_message,
                "artifacts": stage_artifacts(stage_name, manifest),
                "busy": bool(
                    latest_job
                    and latest_job["status"] not in JOB_TERMINAL_STATES
                    and latest_job["module_key"] == module_key
                ),
            }
        )

    return {
        "project_id": project_id,
        "episode_id": episode_id,
        "run_id": run_id,
        "manifest": manifest.model_dump(mode="json") if manifest else None,
        "source_ready": has_valid_raw_source(raw_source),
        "gate": gate_payload(manifest),
        "job": latest_job,
        "logs": logs,
        "documents": {
            "raw_source": raw_source,
            "raw_outline": raw_outline,
            "source_progress": source_progress,
            "project_bible": project_bible,
            "beat_sheet": beat_sheet,
            "master_script": scene_assets["master_script"],
            "timed_script": scene_assets["timed_script"],
        },
        "assets": {
            "visual_gallery": scene_assets["visual_gallery"],
            "character_sheets": scene_assets["character_sheets"],
            "poster_url": scene_assets["poster_url"],
            "review_rows": scene_assets["review_rows"],
        },
        "stages": stages,
    }


def effective_stage_name(dashboard: dict[str, Any]) -> ModuleName:
    manifest = dashboard.get("manifest") or {}
    current_value = manifest.get("current_stage") or ModuleName.SOURCE_INGESTER.value
    try:
        current_stage = ModuleName(current_value)
    except ValueError:
        current_stage = ModuleName.SOURCE_INGESTER
    current_index = PIPELINE_STAGE_ORDER.index(current_stage)
    raw_outline = (dashboard.get("documents") or {}).get("raw_outline") or {}
    stage1_ready = bool(dashboard.get("source_ready")) and bool(raw_outline.get("volumes"))
    if current_index > 0 and not stage1_ready:
        return ModuleName.SOURCE_INGESTER
    return current_stage


def build_stage_url(request: Request, stage_name: ModuleName, project_id: str, episode_id: str, run_id: str) -> str:
    base = request.url_for("stage_page", stage_slug=STAGE_META[stage_name]["slug"])
    query = urlencode({"project_id": project_id, "episode_id": episode_id, "run_id": run_id})
    return f"{base}?{query}"


def build_stage_nav(
    request: Request,
    dashboard: dict[str, Any],
    *,
    project_id: str,
    episode_id: str,
    run_id: str,
    active_stage: ModuleName,
) -> list[dict[str, Any]]:
    effective_stage = effective_stage_name(dashboard)
    effective_index = PIPELINE_STAGE_ORDER.index(effective_stage)
    items: list[dict[str, Any]] = []
    for index, stage_name in enumerate(PIPELINE_STAGE_ORDER):
        meta = STAGE_META[stage_name]
        items.append(
            {
                "key": stage_name.value,
                "slug": meta["slug"],
                "zh": meta["zh"],
                "en": meta["en"],
                "active": stage_name == active_stage,
                "complete": index < effective_index,
                "unlocked": index <= effective_index,
                "url": build_stage_url(request, stage_name, project_id, episode_id, run_id),
            }
        )
    return items


def build_stage_workspace(stage_name: ModuleName, dashboard: dict[str, Any]) -> dict[str, Any]:
    documents = dashboard.get("documents") or {}
    assets = dashboard.get("assets") or {}
    stage_record = next(
        (item for item in dashboard.get("stages", []) if item.get("module_name") == stage_name.value),
        None,
    )
    cards: list[dict[str, Any]] = []
    notes: list[str] = []

    if stage_name == ModuleName.DIRECTOR_ENGINE:
        cards.extend(
            [
                {
                    "title": "世界观宪法",
                    "status": "ready" if documents.get("project_bible") else "pending",
                    "detail": "project_bible.json 已用于锁定角色 DNA 与世界规则。",
                },
                {
                    "title": "节拍骨架",
                    "status": "ready" if documents.get("beat_sheet") else "pending",
                    "detail": "beat_sheet.json 将决定后续 Writer 的推进节奏。",
                },
            ]
        )
        notes.append("Gate 1 审核通过前，不应继续假推进后续阶段。")
    elif stage_name == ModuleName.WRITER_ENGINE:
        cards.append(
            {
                "title": "主剧本台账",
                "status": "ready" if documents.get("master_script") else "pending",
                "detail": "master_script.json 应包含分镜、对白、提示词与状态继承。",
            }
        )
    elif stage_name == ModuleName.AUDIO_ANCHOR_FORGE:
        cards.append(
            {
                "title": "音频锚点",
                "status": "ready" if documents.get("timed_script") else "pending",
                "detail": "timed_script.json 决定音画同步与物理时长。",
            }
        )
    elif stage_name == ModuleName.VISUAL_ASSET_FOUNDRY:
        cards.extend(
            [
                {
                    "title": "角色定型图",
                    "status": "ready" if assets.get("character_sheets") else "pending",
                    "detail": f"当前角色定型图数量：{len(assets.get('character_sheets') or [])}",
                },
                {
                    "title": "场景图阵列",
                    "status": "ready" if assets.get("visual_gallery") else "pending",
                    "detail": f"当前场景图数量：{len(assets.get('visual_gallery') or [])}",
                },
            ]
        )
    elif stage_name == ModuleName.RENDER_ENGINE:
        cards.append(
            {
                "title": "中文母带",
                "status": "ready" if (stage_record or {}).get("artifacts") else "pending",
                "detail": "final_render_zh.mp4 应在本阶段生成并等待 Gate 3 审核。",
            }
        )
    elif stage_name == ModuleName.GLOBAL_DISTRIBUTOR:
        cards.append(
            {
                "title": "全球化资源包",
                "status": "ready" if (stage_record or {}).get("artifacts") else "pending",
                "detail": "用于多语字幕、海报与平台分发。",
            }
        )
    elif stage_name == ModuleName.MASTER_HUB:
        cards.append(
            {
                "title": "状态机总览",
                "status": "ready" if dashboard.get("manifest") else "pending",
                "detail": "manifest.json 是整条流水线的唯一真相来源。",
            }
        )

    if stage_record and stage_record.get("error_message"):
        notes.append(stage_record["error_message"])
    if dashboard.get("gate"):
        notes.append((dashboard["gate"] or {}).get("message") or "")

    return {
        "stage_record": stage_record,
        "cards": cards,
        "notes": [item for item in notes if item],
    }


def director_paths(episode_id: str) -> tuple[Path, Path]:
    director_root = workspace_root() / "data" / "staged" / episode_id / "director_engine"
    return director_root / "project_bible.json", director_root / "beat_sheet.json"


def invalidate_downstream_after_source_change(project_id: str, episode_id: str, run_id: str) -> None:
    ctx = build_context(project_id=project_id, episode_id=episode_id, run_id=run_id, prompt_review=False)
    hub = MasterHubModule()
    manifest_path = hub.manifest_path(ctx)
    if manifest_path.exists():
        manifest = hub.load_manifest(ctx)
        reset_started = False
        for stage_name in hub.stage_order:
            if stage_name == ModuleName.DIRECTOR_ENGINE:
                reset_started = True
            if not reset_started:
                continue
            record = hub.stage_record(manifest, stage_name)
            record.status = ModuleStatus.PENDING
            record.error_message = None
            record.output_files = []
            record.report_path = None
        manifest.current_stage = ModuleName.SOURCE_INGESTER
        manifest.last_completed_stage = None
        manifest.review_gate_pending = None
        manifest.overall_status = ModuleStatus.PENDING
        hub.save_manifest(ctx, manifest)

    stage_keys = [
        "director_engine",
        "writer_engine",
        "audio_anchor_forge",
        "visual_asset_foundry",
        "render_engine",
        "global_distributor",
    ]
    staged_root = workspace_root() / "data" / "staged" / episode_id
    for stage_key in stage_keys:
        target_dir = staged_root / stage_key
        if target_dir.exists():
            for path in sorted(target_dir.rglob("*"), reverse=True):
                if path.is_file():
                    path.unlink()
                elif path.is_dir():
                    path.rmdir()
            if target_dir.exists():
                target_dir.rmdir()

    reports_dir = workspace_root() / "reports" / episode_id
    if reports_dir.exists():
        for pattern in (
            "director-engine_*.json",
            "writer-engine_*.json",
            "audio-anchor-forge_*.json",
            "visual-asset-foundry_*.json",
            "render-engine_*.json",
            "global-distributor_*.json",
            "master-hub_*.json",
        ):
            for path in reports_dir.glob(pattern):
                path.unlink()


def mark_stage_running(project_id: str, episode_id: str, run_id: str, stage_name: ModuleName) -> None:
    ctx = build_context(project_id=project_id, episode_id=episode_id, run_id=run_id, prompt_review=False)
    hub = MasterHubModule()
    if stage_name == ModuleName.DIRECTOR_ENGINE:
        director_root = workspace_root() / "data" / "staged" / episode_id / "director_engine"
        for file_name in ("project_bible.json", "beat_sheet.json", "voice_catalog.json"):
            file_path = director_root / file_name
            if file_path.exists():
                file_path.unlink()
        reports_dir = workspace_root() / "reports" / episode_id
        if reports_dir.exists():
            for path in reports_dir.glob("director-engine_*.json"):
                path.unlink()
    manifest_path = hub.manifest_path(ctx)
    if not manifest_path.exists():
        return
    manifest = hub.load_manifest(ctx)
    stage = hub.stage_record(manifest, stage_name)
    stage.status = ModuleStatus.RUNNING
    stage.error_message = None
    stage.report_path = None
    if stage_name == ModuleName.DIRECTOR_ENGINE:
        stage.output_files = []
    manifest.current_stage = stage_name
    manifest.review_gate_pending = None
    manifest.overall_status = ModuleStatus.RUNNING
    previous_stage = None
    stage_index = hub.stage_order.index(stage_name)
    if stage_index > 0:
        previous_stage = hub.stage_order[stage_index - 1]
    manifest.last_completed_stage = previous_stage
    hub.save_manifest(ctx, manifest)


def run_registry_module(module_key: str, ctx: ModuleContext) -> dict[str, Any]:
    logger.info(f"[WebApp] Running module: {module_key} for episode {ctx.episode_id}")
    registry = build_registry()
    if module_key not in registry:
        logger.error(f"[WebApp] Module not found: {module_key}")
        raise HTTPException(status_code=404, detail=f"Unknown module: {module_key}")
    
    try:
        result = registry[module_key].run(ctx)
        logger.info(f"[WebApp] Module {module_key} completed successfully")
        return {
            "module_key": module_key,
            "report_path": str(result.report_path),
            "output_files": [str(path) for path in result.output_files],
            "template_files": [str(path) for path in result.template_files],
        }
    except Exception as exc:
        logger.error(f"[WebApp] Module {module_key} failed: {exc}", exc_info=True)
        raise  # Re-raise to let job_manager handle it


def queue_module_job(payload: dict[str, Any]) -> dict[str, Any]:
    module_key = payload.get("module_key")
    if not module_key:
        raise HTTPException(status_code=400, detail="module_key is required.")
    ctx = context_from_payload(payload)
    if module_key == "director-engine":
        mark_stage_running(ctx.project_id, ctx.episode_id, ctx.run_id, ModuleName.DIRECTOR_ENGINE)

    def task() -> dict[str, Any]:
        return run_registry_module(module_key, ctx)

    try:
        job = job_manager.enqueue(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            module_key=module_key,
            task=task,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return {
        "job": job,
        "dashboard": dashboard_snapshot(ctx.project_id, ctx.episode_id, ctx.run_id),
    }


@app.get("/", response_class=HTMLResponse)
async def index(request: Request) -> RedirectResponse:
    project_id = request.query_params.get("project_id", "demo_project")
    episode_id = request.query_params.get("episode_id", "EP_01")
    run_id = request.query_params.get("run_id", "web_ui")
    dashboard = dashboard_snapshot(project_id, episode_id, run_id)
    target_stage = effective_stage_name(dashboard)
    return RedirectResponse(build_stage_url(request, target_stage, project_id, episode_id, run_id), status_code=307)


@app.get("/stage/{stage_slug}", response_class=HTMLResponse, name="stage_page")
async def stage_page(
    request: Request,
    stage_slug: str,
    project_id: str = "demo_project",
    episode_id: str = "EP_01",
    run_id: str = "web_ui",
) -> HTMLResponse:
    requested_stage = SLUG_TO_STAGE.get(stage_slug)
    if requested_stage is None:
        raise HTTPException(status_code=404, detail=f"Unknown stage page: {stage_slug}")

    dashboard = dashboard_snapshot(project_id, episode_id, run_id)
    effective_stage = effective_stage_name(dashboard)
    if PIPELINE_STAGE_ORDER.index(requested_stage) > PIPELINE_STAGE_ORDER.index(effective_stage):
        return RedirectResponse(build_stage_url(request, effective_stage, project_id, episode_id, run_id), status_code=307)

    stage_nav = build_stage_nav(
        request,
        dashboard,
        project_id=project_id,
        episode_id=episode_id,
        run_id=run_id,
        active_stage=requested_stage,
    )
    page_data = {
        "project_id": project_id,
        "episode_id": episode_id,
        "run_id": run_id,
        "dashboard": dashboard,
        "active_stage": requested_stage.value,
        "effective_stage": effective_stage.value,
        "stage_nav": stage_nav,
        "stage_urls": {item["key"]: item["url"] for item in stage_nav},
    }
    if requested_stage == ModuleName.SOURCE_INGESTER:
        template_name = "source_ingester.html"
    elif requested_stage == ModuleName.DIRECTOR_ENGINE:
        template_name = "director_engine.html"
    elif requested_stage == ModuleName.WRITER_ENGINE:
        template_name = "writer_engine.html"
    else:
        template_name = "stage_generic.html"
    return TEMPLATES.TemplateResponse(
        template_name,
        {
            "request": request,
            "project_id": project_id,
            "episode_id": episode_id,
            "run_id": run_id,
            "dashboard": dashboard,
            "page_data": page_data,
            "stage_nav": stage_nav,
            "active_stage": requested_stage,
            "stage_meta": STAGE_META[requested_stage],
            "workspace": build_stage_workspace(requested_stage, dashboard),
        },
    )


@app.get("/api/dashboard")
async def api_dashboard(project_id: str, episode_id: str, run_id: str = "web_ui") -> JSONResponse:
    return JSONResponse(dashboard_snapshot(project_id, episode_id, run_id))


@app.get("/workspace-file")
async def workspace_file(path: str) -> FileResponse:
    resolved = resolve_workspace_path(path)
    return FileResponse(resolved)


@app.get("/api/jobs/{job_id}")
async def api_job(job_id: str, project_id: str, episode_id: str, run_id: str = "web_ui") -> JSONResponse:
    try:
        job = job_manager.get(job_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"Unknown job: {job_id}") from exc
    return JSONResponse(
        {
            "job": job,
            "dashboard": dashboard_snapshot(project_id, episode_id, run_id),
        }
    )


@app.post("/api/run-module")
async def api_run_module(request: Request) -> JSONResponse:
    payload = await request.json()
    response = queue_module_job(payload)
    return JSONResponse({"status": "queued", **response})


@app.post("/api/source/extract")
async def api_source_extract(request: Request) -> JSONResponse:
    payload = await request.json()
    ctx = context_from_payload(
        {
            "project_id": payload.get("project_id"),
            "episode_id": payload.get("episode_id"),
            "run_id": payload.get("run_id", "web_ui"),
            "source_uri": payload.get("source_uri"),
            "source_type_hint": payload.get("source_type_hint"),
            "source_keywords": payload.get("source_keywords"),
        }
    )
    try:
        result = SourceIngesterModule().run(ctx)
    except Exception as exc:
        detail = format_exception_summary(exc)
        job_manager._jobs.setdefault(
            "source-extract-latest",
            {
                "job_id": "source-extract-latest",
                "project_id": ctx.project_id,
                "episode_id": ctx.episode_id,
                "run_id": ctx.run_id,
                "module_key": "source-ingester",
                "status": "failed",
                "created_at": datetime.now(timezone.utc).isoformat(),
                "started_at": None,
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "result": None,
                "error": detail,
            },
        )
        raise HTTPException(status_code=500, detail=detail) from exc
    invalidate_downstream_after_source_change(ctx.project_id, ctx.episode_id, ctx.run_id)
    return JSONResponse(
        {
            "status": "ok",
            "result": {
                "report_path": str(result.report_path),
                "output_files": [str(path) for path in result.output_files],
            },
            "dashboard": dashboard_snapshot(ctx.project_id, ctx.episode_id, ctx.run_id),
        }
    )


@app.post("/api/source/update")
async def api_source_update(request: Request) -> JSONResponse:
    payload = await request.json()
    project_id = payload.get("project_id")
    episode_id = payload.get("episode_id")
    run_id = payload.get("run_id", "web_ui")
    source_partitions = payload.get("source_partitions")
    if not project_id or not episode_id:
        raise HTTPException(status_code=400, detail="project_id and episode_id are required.")
    if not isinstance(source_partitions, list):
        raise HTTPException(status_code=400, detail="source_partitions must be a list.")

    source_path = raw_source_path(episode_id)
    if not source_path.exists():
        raise HTTPException(status_code=404, detail="raw_source.json does not exist yet.")

    try:
        raw_source_payload = read_json(source_path)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Failed to read raw_source.json: {exc}") from exc

    raw_source_payload["source_partitions"] = source_partitions
    try:
        validated = RawSource.model_validate(raw_source_payload)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Updated source payload is invalid: {exc}") from exc

    write_payload(source_path, validated, overwrite=True)
    invalidate_downstream_after_source_change(project_id, episode_id, run_id)
    return JSONResponse(
        {
            "status": "updated",
            "dashboard": dashboard_snapshot(project_id, episode_id, run_id),
        }
    )


@app.post("/api/source/upload")
async def api_source_upload(
    project_id: str = Form(...),
    episode_id: str = Form(...),
    run_id: str = Form("web_ui"),
    file: UploadFile = File(...),
) -> JSONResponse:
    filename = file.filename or "upload.bin"
    suffix = Path(filename).suffix.lower()
    destination_dir = upload_dir(episode_id)
    destination_dir.mkdir(parents=True, exist_ok=True)
    destination = destination_dir / filename
    destination.write_bytes(await file.read())

    source_type_hint_map = {
        ".txt": "local_txt",
        ".pdf": "local_txt",
        ".epub": "local_epub",
    }
    source_type_hint = source_type_hint_map.get(suffix)

    if source_type_hint:
        ctx = build_context(
            project_id=project_id,
            episode_id=episode_id,
            run_id=run_id,
            source_uri=str(destination),
            source_type_hint=source_type_hint,
            prompt_review=False,
        )
        try:
            result = SourceIngesterModule().run(ctx)
        except Exception as exc:
            raise HTTPException(status_code=500, detail=format_exception_summary(exc)) from exc
        invalidate_downstream_after_source_change(project_id, episode_id, run_id)
        return JSONResponse(
            {
                "status": "ok",
                "uploaded_file": str(destination),
                "supported": True,
                "result": {
                    "report_path": str(result.report_path),
                    "output_files": [str(path) for path in result.output_files],
                },
                "dashboard": dashboard_snapshot(project_id, episode_id, run_id),
            }
        )

    return JSONResponse(
        {
            "status": "uploaded",
            "uploaded_file": str(destination),
            "supported": False,
            "message": f"{suffix or 'This file type'} upload succeeded, but extraction is currently implemented only for .txt/.pdf/.epub.",
            "dashboard": dashboard_snapshot(project_id, episode_id, run_id),
        }
    )


@app.post("/api/source/confirm")
async def api_source_confirm(request: Request) -> JSONResponse:
    payload = await request.json()
    project_id = payload.get("project_id")
    episode_id = payload.get("episode_id")
    run_id = payload.get("run_id", "web_ui")
    auto_start_next = bool(payload.get("auto_start_next", True))
    selected_story_uid = payload.get("selected_story_uid")
    selected_story_uids = payload.get("selected_story_uids")
    if not project_id or not episode_id:
        raise HTTPException(status_code=400, detail="project_id and episode_id are required.")

    source_path = raw_source_path(episode_id)
    if not source_path.exists():
        raise HTTPException(status_code=400, detail="raw_source.json does not exist yet.")
    try:
        raw_source = RawSource.model_validate_json(source_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"raw_source.json is invalid: {exc}") from exc
    if isinstance(selected_story_uids, list) and len(selected_story_uids) > 1:
        raise HTTPException(status_code=400, detail="Use /api/source/confirm-batch for multiple stories.")
    selected = selected_story_uid or (selected_story_uids[0] if isinstance(selected_story_uids, list) and selected_story_uids else None)
    if not selected:
        raise HTTPException(status_code=400, detail="Please select at least one story before confirming.")
    try:
        raw_source = apply_story_selection(raw_source, selected)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Story selection invalid: {exc}") from exc
    outline = build_source_outline(raw_source.model_dump(mode="json"))
    if outline.get("story_count", 0) <= 0:
        raise HTTPException(status_code=400, detail="No valid story outline was detected. Please clean or re-parse the source first.")
    invalidate_downstream_after_source_change(project_id, episode_id, run_id)
    write_payload(source_path, raw_source, overwrite=True)
    update_source_progress(
        project_id,
        raw_source.model_dump(mode="json"),
        {selected: episode_id},
    )
    if not has_valid_raw_source(raw_source.model_dump(mode="json")):
        raise HTTPException(status_code=400, detail="raw_source.json does not contain valid text.")

    mark_source_confirmed(project_id, episode_id, run_id, source_path)
    next_job = try_start_director_engine(project_id, episode_id, run_id) if auto_start_next else None

    return JSONResponse(
        {
            "status": "confirmed",
            "next_job": next_job,
            "dashboard": dashboard_snapshot(project_id, episode_id, run_id),
        }
    )


@app.post("/api/source/confirm-batch")
async def api_source_confirm_batch(request: Request) -> JSONResponse:
    payload = await request.json()
    project_id = payload.get("project_id")
    episode_id = payload.get("episode_id")
    run_id = payload.get("run_id", "web_ui")
    selected_story_uids = payload.get("selected_story_uids")
    if not project_id or not episode_id:
        raise HTTPException(status_code=400, detail="project_id and episode_id are required.")
    if not isinstance(selected_story_uids, list) or not selected_story_uids:
        raise HTTPException(status_code=400, detail="selected_story_uids must be a non-empty list.")

    source_path = raw_source_path(episode_id)
    if not source_path.exists():
        raise HTTPException(status_code=400, detail="raw_source.json does not exist yet.")
    try:
        base_source = RawSource.model_validate_json(source_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"raw_source.json is invalid: {exc}") from exc

    outline = build_source_outline(base_source.model_dump(mode="json"))
    if outline.get("story_count", 0) <= 0:
        raise HTTPException(status_code=400, detail="No valid story outline was detected. Please clean or re-parse the source first.")

    target_episodes = next_episode_ids(episode_id, len(selected_story_uids))
    batch: list[dict[str, Any]] = []
    progress_map: dict[str, str] = {}
    for idx, story_uid in enumerate(selected_story_uids):
        try:
            selected = apply_story_selection(base_source, story_uid)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Invalid story uid {story_uid}: {exc}") from exc

        target_episode = target_episodes[idx]
        target_path = raw_source_path(target_episode)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        invalidate_downstream_after_source_change(project_id, target_episode, run_id)
        write_payload(target_path, selected, overwrite=True)
        mark_source_confirmed(project_id, target_episode, run_id, target_path)
        progress_map[story_uid] = target_episode
        batch.append({"episode_id": target_episode, "story_uid": story_uid, "raw_source_path": str(target_path)})

    update_source_progress(project_id, base_source.model_dump(mode="json"), progress_map)

    return JSONResponse(
        {
            "status": "confirmed_batch",
            "batch": batch,
            "dashboard": dashboard_snapshot(project_id, target_episodes[0], run_id),
        }
    )


@app.post("/api/source/reset")
async def api_source_reset(request: Request) -> JSONResponse:
    payload = await request.json()
    project_id = payload.get("project_id")
    episode_id = payload.get("episode_id")
    run_id = payload.get("run_id", "web_ui")
    confirmed = bool(payload.get("confirmed", False))
    if not project_id or not episode_id:
        raise HTTPException(status_code=400, detail="project_id and episode_id are required.")
    if not confirmed:
        raise HTTPException(status_code=400, detail="Reset requires confirmed=true.")

    source_dir = workspace_root() / "data" / "staged" / episode_id / "source_ingester"
    if source_dir.exists():
        for path in source_dir.glob("*"):
            if path.is_file():
                path.unlink()

    invalidate_downstream_after_source_change(project_id, episode_id, run_id)

    ctx = build_context(project_id=project_id, episode_id=episode_id, run_id=run_id, prompt_review=False)
    hub = MasterHubModule()
    manifest = hub.load_manifest(ctx)
    source_stage = hub.stage_record(manifest, ModuleName.SOURCE_INGESTER)
    source_stage.status = ModuleStatus.PENDING
    source_stage.error_message = None
    source_stage.output_files = []
    source_stage.report_path = None
    manifest.current_stage = ModuleName.SOURCE_INGESTER
    manifest.last_completed_stage = None
    manifest.overall_status = ModuleStatus.PENDING
    manifest.review_gate_pending = None
    hub.save_manifest(ctx, manifest)

    return JSONResponse(
        {
            "status": "reset",
            "dashboard": dashboard_snapshot(project_id, episode_id, run_id),
        }
    )


@app.post("/api/director/save")
async def api_director_save(request: Request) -> JSONResponse:
    payload = await request.json()
    project_id = payload.get("project_id")
    episode_id = payload.get("episode_id")
    run_id = payload.get("run_id", "web_ui")
    project_bible_data = payload.get("project_bible")
    beat_sheet_data = payload.get("beat_sheet")
    if not project_id or not episode_id:
        raise HTTPException(status_code=400, detail="project_id and episode_id are required.")
    if not project_bible_data or not beat_sheet_data:
        raise HTTPException(status_code=400, detail="project_bible and beat_sheet are required.")

    try:
        project_bible = ProjectBible.model_validate(project_bible_data)
        beat_sheet = BeatSheet.model_validate(beat_sheet_data)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Director payload is invalid: {exc}") from exc

    project_bible_path, beat_sheet_path = director_paths(episode_id)
    project_bible_path.parent.mkdir(parents=True, exist_ok=True)
    write_payload(project_bible_path, project_bible, overwrite=True)
    write_payload(beat_sheet_path, beat_sheet, overwrite=True)

    ctx = build_context(project_id=project_id, episode_id=episode_id, run_id=run_id, prompt_review=False)
    hub = MasterHubModule()
    manifest = hub.load_manifest(ctx)
    stage = hub.stage_record(manifest, ModuleName.DIRECTOR_ENGINE)
    if stage.status == ModuleStatus.PENDING:
        stage.status = ModuleStatus.RUNNING
    stage.error_message = None
    stage.output_files = sorted({*stage.output_files, str(project_bible_path), str(beat_sheet_path)})
    manifest.current_stage = ModuleName.DIRECTOR_ENGINE
    manifest.overall_status = ModuleStatus.RUNNING
    hub.save_manifest(ctx, manifest)

    return JSONResponse(
        {
            "status": "saved",
            "dashboard": dashboard_snapshot(project_id, episode_id, run_id),
        }
    )


@app.post("/api/approve")
async def api_approve(request: Request) -> JSONResponse:
    payload = await request.json()
    project_id = payload.get("project_id")
    episode_id = payload.get("episode_id")
    run_id = payload.get("run_id", "web_ui")
    continue_pipeline = bool(payload.get("continue_pipeline", False))

    if not project_id or not episode_id:
        raise HTTPException(status_code=400, detail="project_id and episode_id are required.")

    ctx = build_context(project_id=project_id, episode_id=episode_id, run_id=run_id, prompt_review=False)
    hub = MasterHubModule()
    manifest = hub.load_manifest(ctx)
    gate_no = manifest.review_gate_pending
    if gate_no is None:
        raise HTTPException(status_code=400, detail="No review gate is currently pending for this episode.")

    if gate_no == 1:
        project_bible_data = payload.get("project_bible")
        beat_sheet_data = payload.get("beat_sheet")
        if not project_bible_data or not beat_sheet_data:
            raise HTTPException(status_code=400, detail="project_bible and beat_sheet are required for Gate 1 approval.")
        project_bible = ProjectBible.model_validate(project_bible_data)
        beat_sheet = BeatSheet.model_validate(beat_sheet_data)
        director_root = workspace_root() / "data" / "staged" / episode_id / "director_engine"
        director_root.mkdir(parents=True, exist_ok=True)
        write_payload(director_root / "project_bible.json", project_bible, overwrite=True)
        write_payload(director_root / "beat_sheet.json", beat_sheet, overwrite=True)

    completed_stage = GATE_STAGE_MAP[gate_no]
    manifest.review_gate_pending = None
    manifest.last_completed_stage = completed_stage
    manifest.current_stage = hub.next_stage_after(completed_stage)
    manifest.overall_status = ModuleStatus.RUNNING if manifest.current_stage else ModuleStatus.SUCCESS
    stage = hub.stage_record(manifest, completed_stage)
    stage.status = ModuleStatus.SUCCESS
    stage.error_message = None
    hub.save_manifest(ctx, manifest)

    job = None
    if continue_pipeline and manifest.current_stage is not None:
        queued = queue_module_job(
            {
                "project_id": project_id,
                "episode_id": episode_id,
                "run_id": run_id,
                "module_key": PIPELINE_KEY,
                "execution_mode": manifest.execution_mode.value,
            }
        )
        job = queued["job"]

    return JSONResponse(
        {
            "status": "approved",
            "gate_no": gate_no,
            "continued": continue_pipeline,
            "job": job,
            "dashboard": dashboard_snapshot(project_id, episode_id, run_id),
        }
    )


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="movai-web", description="Run the MOVAI web studio.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args(argv)
    uvicorn.run("movai.web.app:app", host=args.host, port=args.port, reload=False)


@app.post("/api/translate")
async def api_translate(request: Request) -> JSONResponse:
    """自动翻译 API - 将中文文本翻译为英文"""
    try:
        payload = await request.json()
        translation_data = payload.get("translation", {})
        
        if not translation_data:
            return JSONResponse({"translations": {}})
        
        translations = {
            "entities": {},
            "world_rules": [],
            "beats": {}
        }
        
        # 翻译实体字段
        if translation_data.get("entities"):
            for entity_id, fields in translation_data["entities"].items():
                translations["entities"][entity_id] = {}
                for field, cn_text in fields.items():
                    en_text = simple_translate(cn_text)
                    translations["entities"][entity_id][field] = en_text
        
        # 翻译世界规则
        if translation_data.get("world_rules"):
            for item in translation_data["world_rules"]:
                en_text = simple_translate(item["cn"])
                translations["world_rules"].append({
                    "index": item["index"],
                    "en": en_text
                })
        
        # 翻译节拍分镜描述
        if translation_data.get("beats"):
            for beat_id, fields in translation_data["beats"].items():
                translations["beats"][beat_id] = {}
                for field, cn_text in fields.items():
                    en_text = simple_translate(cn_text)
                    translations["beats"][beat_id][field] = en_text
        
        return JSONResponse({"translations": translations})
    
    except Exception as exc:
        return JSONResponse(
            {"error": f"Translation failed: {str(exc)}"},
            status_code=500
        )
