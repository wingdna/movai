(function () {
  const pageData = window.MOVAI_PAGE_DATA || {};
  const dashboard = pageData.dashboard || {};
  const documents = dashboard.documents || {};
  const stageUrls = pageData.stage_urls || {};
  const gate = dashboard.gate || null;

  const roleMap = {
    "Primary Character": "主角",
    "Supporting Character": "配角",
    "Antagonist": "对立角色",
    "Observer": "观察者",
    "Witness": "见证者",
    "Unknown": "未知",
  };

  const moodMap = {
    Calm: "平静",
    Tension: "紧张",
    Horror: "惊悚",
    Action: "行动",
  };

  function el(id) {
    return document.getElementById(id);
  }

  function pretty(value) {
    return JSON.stringify(value || {}, null, 2);
  }

  function hasChinese(value) {
    return /[\u4e00-\u9fff]/.test(String(value || ""));
  }

  function esc(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll("\"", "&quot;")
      .replaceAll("'", "&#39;");
  }

  async function fetchJson(url, options = {}) {
    const response = await fetch(url, options);
    let payload = {};
    try {
      payload = await response.json();
    } catch (_error) {
      payload = {};
    }
    if (!response.ok) {
      throw new Error(payload.detail || payload.message || response.statusText || "Request failed");
    }
    return payload;
  }

  function setBusyState(busy, label) {
    const runButton = el("director-run-button");
    const reloadButton = el("director-reload-button");
    const saveButton = el("director-save-button");
    const approveButton = el("director-approve-button");
    const stageStatus = el("director-stage-status");
    const jobLabel = el("director-job-label");

    [runButton, reloadButton, saveButton, approveButton].forEach((button) => {
      if (!button) return;
      button.disabled = busy && button !== reloadButton;
    });

    if (runButton) {
      runButton.textContent = busy ? (label || "导演生成中...") : "重新生成导演结果";
    }
    if (stageStatus && busy) {
      stageStatus.textContent = "running";
      stageStatus.classList.remove("ready");
      stageStatus.classList.add("running");
    }
    if (jobLabel && label) {
      jobLabel.textContent = label;
    }
  }

  function setToggleState(prefix, rawVisible) {
    const toggleButton = el(`${prefix}-toggle`);
    const treePanel = el(`${prefix}-tree`);
    const rawPanel = el(`${prefix}-raw`);
    if (!toggleButton || !treePanel || !rawPanel) return;
    rawPanel.hidden = !rawVisible;
    treePanel.hidden = rawVisible;
    toggleButton.textContent = rawVisible ? "切换到树形卡片" : "切换到 JSON 原文";
  }

  function renderItems(items) {
    if (!items.length) {
      return `<div class="director-empty">当前没有可展示的中文导演资产。</div>`;
    }

    return items.map((item) => `
      <div class="director-kv">
        <span>${esc(item.label)}</span>
        <strong>${esc(item.value)}</strong>
      </div>
    `).join("");
  }

  function renderItemsWithTranslation(items, parentId, parentType) {
    if (!items.length) {
      return `<div class="director-empty">当前没有可展示的中文导演资产。</div>`;
    }

    return items.map((item, index) => {
      if (item.hasTranslation && item.enValue) {
        const fieldId = `${parentType}-${parentId}-field-${index}`;
        return `
          <div class="director-kv director-kv--bilingual">
            <span>${esc(item.label)}</span>
            <div class="director-bilingual">
              <input type="text" class="director-input-cn" 
                     data-parent-id="${parentId}" 
                     data-parent-type="${parentType}"
                     data-field-key="${item.key}"
                     data-field-index="${index}"
                     value="${esc(item.value)}"
                     placeholder="中文描述" />
              <input type="text" class="director-input-en" 
                     id="${fieldId}-en"
                     value="${esc(item.enValue)}"
                     placeholder="English description for AI generation" />
            </div>
          </div>`;
      }
      return `
        <div class="director-kv">
          <span>${esc(item.label)}</span>
          <strong>${esc(item.value)}</strong>
        </div>`;
    }).join("");
  }

  function renderListBlock(title, items) {
    if (!items.length) return "";
    return `
      <section class="director-tree__block">
        <header class="director-tree__block-head">
          <h4>${esc(title)}</h4>
        </header>
        <div class="director-tree__list">
          ${items.map((value) => `<div class="director-tag">${esc(value)}</div>`).join("")}
        </div>
      </section>`;
  }

  function projectBibleTree(projectBible) {
    const entities = Object.entries(projectBible?.entities || {});
    const styleMatrix = projectBible?.style_matrix || {};
    const glossary = Object.entries(projectBible?.glossary || {}).filter(([key, value]) => hasChinese(key) || hasChinese(value));
    const worldRules = (projectBible?.world_rules || []).filter((rule) => hasChinese(rule));

    const topItems = [];
    if (hasChinese(projectBible?.project_id)) topItems.push({ label: "项目标识", value: projectBible.project_id });
    if (projectBible?.created_at) topItems.push({ label: "生成时间", value: String(projectBible.created_at).slice(0, 19).replace("T", " ") });
    if (styleMatrix?.visual_lut) topItems.push({ label: "视觉风格", value: "已配置" });
    if (styleMatrix?.narrator_voice_id) topItems.push({ label: "旁白音色", value: "已分配" });

    const entityBlocks = entities.map(([entityId, entity]) => {
      const items = [];
      items.push({ label: "角色名称", value: entity.name || entityId, key: "name" });
      if (entity.role) items.push({ label: "角色定位", value: roleMap[entity.role] || (hasChinese(entity.role) ? entity.role : "已定义"), key: "role" });
      if (entity.core_personality) items.push({ label: "核心性格", value: hasChinese(entity.core_personality) ? entity.core_personality : "已写入角色性格", key: "core_personality" });
      if (entity.audio_tts_id) items.push({ label: "角色音色", value: "普通话音色已分配", key: "audio_tts_id" });
      if (entity.visual_prompt_lock) {
        items.push({ 
          label: "视觉锁定", 
          value: "英文视觉锁定词已配置", 
          key: "visual_prompt_lock",
          enValue: entity.visual_prompt_lock,
          hasTranslation: true
        });
      }
      return `
        <section class="director-tree__block">
          <header class="director-tree__block-head">
            <h4>${esc(entity.name || entityId)}</h4>
            <span>${esc(entityId)}</span>
          </header>
          <div class="director-tree__kv">
            ${renderItemsWithTranslation(items, entityId, 'entity')}
          </div>
        </section>`;
    }).join("");

    const glossaryBlock = glossary.length
      ? `
        <section class="director-tree__block">
          <header class="director-tree__block-head">
            <h4>术语表</h4>
          </header>
          <div class="director-tree__kv">
            ${glossary.map(([key, value]) => `
              <div class="director-kv">
                <span>${esc(key)}</span>
                <strong>${esc(value)}</strong>
              </div>`).join("")}
          </div>
        </section>`
      : "";

    const worldRulesBlock = worldRules.length
      ? `
        <section class="director-tree__block">
          <header class="director-tree__block-head">
            <h4>世界规则</h4>
          </header>
          <div class="director-tree__list">
            ${worldRules.map((rule, idx) => `
              <div class="director-tag director-tag--multiline">
                <span class="director-tag__cn">${esc(rule)}</span>
                <textarea class="director-tag__en" placeholder="英文翻译（用于 AI 生成）">${esc(rule)}</textarea>
              </div>`).join("")}
          </div>
        </section>`
      : "";

    return `
      ${topItems.length ? `
        <section class="director-tree__block">
          <header class="director-tree__block-head">
            <h4>项目概览</h4>
          </header>
          <div class="director-tree__kv">
            ${renderItems(topItems)}
          </div>
        </section>` : ""}
      ${worldRulesBlock}
      ${entityBlocks || `<div class="director-empty">当前还没有角色资产。</div>`}
      ${glossaryBlock}`;
  }

  function resolveCharacterNames(characterIds, projectBible) {
    return (characterIds || []).map((entityId) => {
      const entity = projectBible?.entities?.[entityId];
      return entity?.name || entityId;
    });
  }

  function beatSheetTree(beatSheet, projectBible) {
    const beats = beatSheet?.beats || [];
    const inherited = beatSheet?.inherited_from_episode_id;
    const metaItems = [];
    if (beatSheet?.episode_id && hasChinese(beatSheet.episode_id)) metaItems.push({ label: "集数", value: beatSheet.episode_id });
    if (inherited) metaItems.push({ label: "跨集继承", value: inherited });

    const beatBlocks = beats.map((beat, index) => {
      const items = [];
      if (beat.title && hasChinese(beat.title)) items.push({ label: "标题", value: beat.title, key: "title" });
      if (beat.summary) items.push({ label: "概要", value: hasChinese(beat.summary) ? beat.summary : "已生成节拍概要", key: "summary" });
      if (beat.objective) items.push({ label: "目标", value: hasChinese(beat.objective) ? beat.objective : "已定义节拍目标", key: "objective" });
      if (beat.mood) items.push({ label: "情绪", value: moodMap[beat.mood] || beat.mood, key: "mood" });
      if (beat.estimated_duration_ms) items.push({ label: "预计时长", value: `${Math.round(Number(beat.estimated_duration_ms) / 1000)} 秒`, key: "estimated_duration_ms" });

      const characters = resolveCharacterNames(beat.characters_present, projectBible).filter((name) => hasChinese(name));
      return `
        <section class="director-tree__block">
          <header class="director-tree__block-head">
            <h4>${esc(beat.title || `节拍 ${String(index + 1).padStart(2, "0")}`)}</h4>
            <span>${esc(beat.beat_id || "")}</span>
          </header>
          <div class="director-tree__kv">
            ${renderItemsWithTranslation(items, beat.beat_id || `beat_${index}`, 'beat')}
          </div>
          ${renderListBlock("出场角色", characters)}
          ${beat.summary ? `
            <div class="director-beat-prompt">
              <label>分镜描述（英文，用于 AI 生图）：</label>
              <textarea class="director-beat-prompt-textarea" 
                        data-beat-id="${esc(beat.beat_id || `beat_${index}`)}"
                        placeholder="Visual prompt for this beat (in English)">${esc(beat.visual_prompt || '')}</textarea>
            </div>
          ` : ''}
        </section>`;
    }).join("");

    return `
      ${metaItems.length ? `
        <section class="director-tree__block">
          <header class="director-tree__block-head">
            <h4>本集信息</h4>
          </header>
          <div class="director-tree__kv">
            ${renderItems(metaItems)}
          </div>
        </section>` : ""}
      ${beatBlocks || `<div class="director-empty">当前还没有节拍资产。</div>`}`;
  }

  function fillPanels() {
    if (el("project-bible-editor")) el("project-bible-editor").value = pretty(documents.project_bible);
    if (el("beat-sheet-editor")) el("beat-sheet-editor").value = pretty(documents.beat_sheet);

    if (el("project-bible-tree")) {
      el("project-bible-tree").innerHTML = projectBibleTree(documents.project_bible || {});
    }
    if (el("beat-sheet-tree")) {
      el("beat-sheet-tree").innerHTML = beatSheetTree(documents.beat_sheet || {}, documents.project_bible || {});
    }

    setToggleState("project-bible", false);
    setToggleState("beat-sheet", false);

    const canApprove = Boolean(gate && gate.gate_no === 1);
    if (el("director-approve-button")) el("director-approve-button").disabled = !canApprove;
    if (el("director-dock-title")) {
      el("director-dock-title").textContent = canApprove ? "Gate 1 已就绪，可以审核通过" : "当前不是 Gate 1，请先检查或重生成";
    }
    if (el("director-dock-body")) {
      el("director-dock-body").textContent = canApprove
        ? "树形卡片已经准备好，确认世界观与节拍骨架无误后即可批准继续。"
        : "如果导演资产为空，界面会保持空白；系统不会再自动填入任何占位 JSON。";
    }
  }

  function readPayload() {
    try {
      // 收集树形卡片中的修改
      const updatedProjectBible = collectProjectBibleFromTree();
      const updatedBeatSheet = collectBeatSheetFromTree();
      
      return {
        project_bible: updatedProjectBible || JSON.parse(el("project-bible-editor")?.value || "{}"),
        beat_sheet: updatedBeatSheet || JSON.parse(el("beat-sheet-editor")?.value || "{}"),
      };
    } catch (error) {
      throw new Error(`JSON 解析失败：${error.message}`);
    }
  }

  function collectProjectBibleFromTree() {
    const projectBible = documents.project_bible || {};
    if (!projectBible.entities) return null;

    // 收集实体字段的中英文更新
    const cnInputs = document.querySelectorAll('.director-input-cn');
    cnInputs.forEach(input => {
      const { parentType, parentId, fieldKey } = input.dataset;
      const enInput = document.querySelector(`.director-input-en[data-parent-id="${parentId}"][data-field-key="${fieldKey}"]`);
      
      if (parentType === 'entity' && projectBible.entities[parentId]) {
        const entity = projectBible.entities[parentId];
        if (fieldKey === 'name') entity.name = input.value;
        if (fieldKey === 'role') entity.role = input.value;
        if (fieldKey === 'core_personality') entity.core_personality = input.value;
        if (fieldKey === 'visual_prompt_lock' && enInput) entity.visual_prompt_lock = enInput.value;
      }
    });

    // 收集世界规则的翻译
    const worldRuleInputs = document.querySelectorAll('.director-tag__en');
    if (worldRuleInputs.length && projectBible.world_rules) {
      projectBible.world_rules = Array.from(worldRuleInputs).map(input => input.value);
    }

    return projectBible;
  }

  function collectBeatSheetFromTree() {
    const beatSheet = documents.beat_sheet || {};
    if (!beatSheet.beats) return null;

    const cnInputs = document.querySelectorAll('.director-input-cn');
    cnInputs.forEach(input => {
      const { parentType, parentId, fieldKey } = input.dataset;
      const enInput = document.querySelector(`.director-input-en[data-parent-id="${parentId}"][data-field-key="${fieldKey}"]`);
      
      if (parentType === 'beat') {
        const beat = beatSheet.beats.find(b => b.beat_id === parentId);
        if (!beat) return;
        
        if (fieldKey === 'title') beat.title = input.value;
        if (fieldKey === 'summary') beat.summary = input.value;
        if (fieldKey === 'objective') beat.objective = input.value;
        if (fieldKey === 'mood') beat.mood = input.value;
      }
    });

    // 收集节拍分镜描述
    const promptInputs = document.querySelectorAll('.director-beat-prompt-textarea');
    promptInputs.forEach(textarea => {
      const beatId = textarea.dataset.beatId;
      const beat = beatSheet.beats.find(b => b.beat_id === beatId);
      if (beat) {
        beat.visual_prompt = textarea.value;
      }
    });

    return beatSheet;
  }

  async function saveDraft() {
    let parsed;
    try {
      parsed = readPayload();
    } catch (error) {
      alert(error.message);
      return;
    }

    // 自动翻译：收集需要翻译的字段
    const translationNeeded = collectTranslationNeeds(parsed);
    
    try {
      // 如果有需要翻译的字段，先调用翻译 API
      if (translationNeeded && Object.keys(translationNeeded).length > 0) {
        setBusyState(true, '正在自动翻译...');
        const translations = await autoTranslate(translationNeeded);
        applyTranslations(parsed, translations);
      }
      
      await fetchJson("/api/director/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          project_id: pageData.project_id || "default",
          episode_id: pageData.episode_id || "EP_01",
          run_id: pageData.run_id || "web_ui",
          project_bible: parsed.project_bible,
          beat_sheet: parsed.beat_sheet,
        }),
      });
      window.location.reload();
    } catch (error) {
      alert(`保存失败：${error.message}`);
      setBusyState(false);
    }
  }

  function collectTranslationNeeds(payload) {
    const translation = {
      entities: {},
      world_rules: [],
      beats: {}
    };
    let hasTranslation = false;

    // 收集实体的视觉锁定词翻译
    const projectBible = payload.project_bible || {};
    if (projectBible.entities) {
      Object.entries(projectBible.entities).forEach(([entityId, entity]) => {
        const cnInputs = document.querySelectorAll(`.director-input-cn[data-parent-type="entity"][data-parent-id="${entityId}"]`);
        cnInputs.forEach(input => {
          if (input.dataset.fieldKey === 'visual_prompt_lock' || input.dataset.fieldKey === 'core_personality') {
            const cnValue = input.value;
            const enInput = document.querySelector(`.director-input-en[data-parent-id="${entityId}"][data-field-key="${input.dataset.fieldKey}"]`);
            const enValue = enInput?.value || '';
            
            // 如果中文被修改过，或者英文标记为需要翻译
            if (cnValue && (!enValue || enInput?.classList.contains('needs-translation'))) {
              translation.entities[entityId] = translation.entities[entityId] || {};
              translation.entities[entityId][input.dataset.fieldKey] = cnValue;
              hasTranslation = true;
            }
          }
        });
      });
    }

    // 收集世界规则的翻译
    if (projectBible.world_rules) {
      const ruleInputs = document.querySelectorAll('.director-tag__en');
      ruleInputs.forEach((input, index) => {
        const cnValue = projectBible.world_rules[index];
        const enValue = input.value;
        if (cnValue && (!enValue || input.classList.contains('needs-translation'))) {
          translation.world_rules.push({
            index,
            cn: cnValue,
            en: enValue
          });
          hasTranslation = true;
        }
      });
    }

    // 收集节拍的分镜描述翻译
    const beatSheet = payload.beat_sheet || {};
    if (beatSheet.beats) {
      beatSheet.beats.forEach((beat, index) => {
        const promptInput = document.querySelector(`.director-beat-prompt-textarea[data-beat-id="${beat.beat_id}"]`);
        if (promptInput && promptInput.classList.contains('edited')) {
          translation.beats[beat.beat_id] = {
            visual_prompt: promptInput.value
          };
          hasTranslation = true;
        }
      });
    }

    return hasTranslation ? translation : null;
  }

  async function autoTranslate(translation) {
    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ translation })
      });
      
      if (!response.ok) {
        throw new Error('翻译服务不可用');
      }
      
      const result = await response.json();
      return result.translations || {};
    } catch (error) {
      console.warn('自动翻译失败，将保留英文原样:', error);
      return {};
    }
  }

  function applyTranslations(payload, translations) {
    if (!translations) return;

    // 应用实体翻译
    if (translations.entities && payload.project_bible?.entities) {
      Object.entries(translations.entities).forEach(([entityId, entityTranslations]) => {
        const entity = payload.project_bible.entities[entityId];
        if (entity) {
          if (entityTranslations.visual_prompt_lock) {
            entity.visual_prompt_lock = entityTranslations.visual_prompt_lock;
          }
          if (entityTranslations.core_personality) {
            entity.core_personality = entityTranslations.core_personality;
          }
        }
      });
    }

    // 应用世界规则翻译
    if (translations.world_rules && payload.project_bible?.world_rules) {
      translations.world_rules.forEach(item => {
        if (item.en) {
          payload.project_bible.world_rules[item.index] = item.en;
        }
      });
    }

    // 应用节拍分镜描述翻译
    if (translations.beats && payload.beat_sheet?.beats) {
      Object.entries(translations.beats).forEach(([beatId, beatTranslation]) => {
        const beat = payload.beat_sheet.beats.find(b => b.beat_id === beatId);
        if (beat && beatTranslation.visual_prompt) {
          beat.visual_prompt = beatTranslation.visual_prompt;
        }
      });
    }
  }

  async function approveAndContinue() {
    let parsed;
    try {
      parsed = readPayload();
    } catch (error) {
      alert(error.message);
      return;
    }

    try {
      await fetchJson("/api/approve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          project_id: pageData.project_id || "default",
          episode_id: pageData.episode_id || "EP_01",
          run_id: pageData.run_id || "web_ui",
          continue_pipeline: true,
          project_bible: parsed.project_bible,
          beat_sheet: parsed.beat_sheet,
        }),
      });
      window.location.href = stageUrls.Writer_Engine || "/";
    } catch (error) {
      alert(`审核失败：${error.message}`);
    }
  }

  async function pollJob(jobId) {
    const params = new URLSearchParams({
      project_id: pageData.project_id || "default",
      episode_id: pageData.episode_id || "EP_01",
      run_id: pageData.run_id || "web_ui",
    });
    const startedAt = Date.now();

    while (Date.now() - startedAt < 120000) {
      const payload = await fetchJson(`/api/jobs/${jobId}?${params.toString()}`);
      const job = payload.job || {};
      if (job.status === "success") {
        window.location.reload();
        return;
      }
      if (job.status === "failed") {
        setBusyState(false);
        alert(`导演引擎生成失败：${job.error || "未知错误"}`);
        window.location.reload();
        return;
      }
      await new Promise((resolve) => window.setTimeout(resolve, 1200));
    }

    setBusyState(false);
    alert("导演引擎仍在运行中，页面先保持当前状态；你也可以稍后手动刷新。");
  }

  async function rerunDirector() {
    try {
      setBusyState(true, "director-engine queued");
      const payload = await fetchJson("/api/run-module", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          project_id: pageData.project_id || "default",
          episode_id: pageData.episode_id || "EP_01",
          run_id: pageData.run_id || "web_ui",
          module_key: "director-engine",
        }),
      });
      const jobId = payload.job?.job_id;
      if (!jobId) {
        window.location.reload();
        return;
      }
      await pollJob(jobId);
    } catch (error) {
      setBusyState(false);
      alert(`启动失败：${error.message}`);
    }
  }

  function bindToggles() {
    el("project-bible-toggle")?.addEventListener("click", () => {
      const rawPanel = el("project-bible-raw");
      setToggleState("project-bible", rawPanel ? rawPanel.hidden : false);
    });
    el("beat-sheet-toggle")?.addEventListener("click", () => {
      const rawPanel = el("beat-sheet-raw");
      setToggleState("beat-sheet", rawPanel ? rawPanel.hidden : false);
    });
  }

  function bindBilingualInputs() {
    // 监听中文输入变化，自动翻译为英文
    document.addEventListener('input', (event) => {
      if (event.target.classList.contains('director-input-cn')) {
        const cnInput = event.target;
        const enInput = document.getElementById(`${cnInput.dataset.parentType}-${cnInput.dataset.parentId}-field-${cnInput.dataset.fieldIndex}-en`);
        if (enInput) {
          // 简单翻译：中文变化时，英文保持原样或标记为需要翻译
          enInput.classList.add('needs-translation');
          enInput.placeholder = '需要翻译 / Needs translation';
        }
      }
    });

    // 监听节拍分镜描述
    document.addEventListener('input', (event) => {
      if (event.target.classList.contains('director-beat-prompt-textarea')) {
        const textarea = event.target;
        textarea.classList.add('edited');
      }
    });
  }

  function bind() {
    bindToggles();
    bindBilingualInputs();
    el("director-save-button")?.addEventListener("click", saveDraft);
    el("director-approve-button")?.addEventListener("click", approveAndContinue);
    el("director-reload-button")?.addEventListener("click", () => {
      window.location.href = `${window.location.pathname}${window.location.search}${window.location.search ? "&" : "?"}refresh=${Date.now()}`;
    });
    el("director-run-button")?.addEventListener("click", rerunDirector);
  }

  document.addEventListener("DOMContentLoaded", () => {
    fillPanels();
    bind();
    bindBilingualInputs();
    if ((dashboard.job || {}).status === "running" && (dashboard.job || {}).module_key === "director-engine") {
      setBusyState(true, "director-engine running");
    }
  });
})();
