(function () {
  const panel = document.getElementById("log-panel");
  const collapsedTrigger = document.getElementById("log-collapsed-trigger");
  const content = document.getElementById("log-content");
  const compact = document.getElementById("log-compact");
  const full = document.getElementById("log-full");
  const detailButton = document.getElementById("expand-log-detail");
  const toggleButton = document.getElementById("toggle-log-button");

  if (!panel || !collapsedTrigger || !content || !compact || !full || !detailButton || !toggleButton) return;

  let open = false;
  let detailOpen = false;

  function sync() {
    panel.classList.toggle("collapsed", !open);
    collapsedTrigger.style.display = open ? "none" : "block";
    content.style.display = open ? "" : "none";
    toggleButton.textContent = open ? "v" : ">";
    detailButton.textContent = detailOpen ? "收起详情" : "展开详情";
    compact.style.display = detailOpen ? "none" : "";
    full.style.display = detailOpen ? "" : "none";
  }

  detailButton.addEventListener("click", function () {
    detailOpen = !detailOpen;
    sync();
  });

  toggleButton.addEventListener("click", function () {
    open = !open;
    sync();
  });

  collapsedTrigger.addEventListener("click", function () {
    open = true;
    sync();
  });

  sync();
})();
