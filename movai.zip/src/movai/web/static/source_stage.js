(function () {
  const pageData = window.MOVAI_PAGE_DATA || {};
  const dashboard = pageData.dashboard || {};
  const outline = (dashboard.documents || {}).raw_outline || { volumes: [], story_count: 0 };
  const rawSource = (dashboard.documents || {}).raw_source || {};
  const sourceProgress = (dashboard.documents || {}).source_progress || {
    processed_story_uids: [],
    story_episode_map: {},
  };
  const processedStorySet = new Set(sourceProgress.processed_story_uids || []);
  const processedEpisodeMap = sourceProgress.story_episode_map || {};
  const stageUrls = pageData.stage_urls || {};

  let rawSourceData = JSON.parse(JSON.stringify(rawSource || {}));
  let selectedVolumeId = "";
  let selectedStoryUid = "";
  let selectedSubstoryUid = "";
  let selectedStoryUids = new Set();
  let expandedVolumes = new Set();
  let expandedStories = new Set();

  function el(id) {
    return document.getElementById(id);
  }

  function esc(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll("\"", "&quot;")
      .replaceAll("'", "&#39;");
  }

  function escTextarea(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;");
  }

  function fetchJson(url, options = {}) {
    return fetch(url, options).then(async (response) => {
      let payload = {};
      try {
        payload = await response.json();
      } catch (_error) {
        payload = {};
      }
      if (!response.ok) {
        throw new Error(payload.detail || payload.message || response.statusText || "Request failed");
      }
      return payload;
    });
  }

  function hasValidText(source) {
    return Boolean((source.source_partitions || []).some((partition) =>
      (partition.text_chunks || []).some((chunk) => String(chunk.text || "").trim().length > 0)
    ));
  }

  function stage1Ready() {
    return hasValidText(rawSourceData) && Array.isArray(outline.volumes) && outline.volumes.length > 0;
  }

  function readControls() {
    const value = (el("source-uri")?.value || "").trim();
    const isUrl = /^https?:\/\//i.test(value);
    return {
      project_id: pageData.project_id || "default",
      episode_id: pageData.episode_id || "EP_01",
      run_id: pageData.run_id || "web_ui",
      source_uri: isUrl ? value : "",
      source_keywords: isUrl ? "" : value,
      source_type_hint: isUrl ? "web_url" : undefined,
    };
  }

  function findVolume(volumeId) {
    return (outline.volumes || []).find((volume) => volume.partition_id === volumeId) || null;
  }

  function findStory(storyUid) {
    for (const volume of outline.volumes || []) {
      for (const story of volume.stories || []) {
        if (story.story_uid === storyUid) {
          return { volume, story };
        }
      }
    }
    return null;
  }

  function ensureDefaultSelection() {
    if (!outline.volumes.length) return;
    if (!selectedVolumeId) {
      selectedVolumeId = outline.volumes[0].partition_id;
      expandedVolumes.add(selectedVolumeId);
    }
    if (selectedStoryUid) return;
    const activeVolume = findVolume(selectedVolumeId) || outline.volumes[0];
    const firstStory =
      (activeVolume.stories || []).find((story) => !processedStorySet.has(story.story_uid)) ||
      (activeVolume.stories || [])[0];
    if (!firstStory) return;
    selectedStoryUid = firstStory.story_uid;
    expandedVolumes.add(activeVolume.partition_id);
    if ((firstStory.substories || []).length > 0) {
      expandedStories.add(firstStory.story_uid);
    }
  }

  function currentStoryState() {
    const direct = selectedStoryUid ? findStory(selectedStoryUid) : null;
    if (direct) return direct;
    const firstSelected = Array.from(selectedStoryUids)[0];
    return firstSelected ? findStory(firstSelected) : null;
  }

  function storyIdsForVolume(volume) {
    return (volume?.stories || []).map((story) => story.story_uid);
  }

  function volumeCheckState(volume) {
    const storyIds = storyIdsForVolume(volume);
    if (!storyIds.length) return "unchecked";
    const selectedCount = storyIds.filter((storyUid) => selectedStoryUids.has(storyUid)).length;
    if (selectedCount === 0) return "unchecked";
    if (selectedCount === storyIds.length) return "checked";
    return "partial";
  }

  function isStoryChecked(story) {
    return selectedStoryUids.has(story.story_uid);
  }

  function toggleVolumeExpanded(volumeId) {
    if (expandedVolumes.has(volumeId)) expandedVolumes.delete(volumeId);
    else expandedVolumes.add(volumeId);
  }

  function toggleStoryExpanded(storyUid) {
    if (expandedStories.has(storyUid)) expandedStories.delete(storyUid);
    else expandedStories.add(storyUid);
  }

  function setVolumeFocus(volumeId) {
    selectedVolumeId = volumeId;
    expandedVolumes.add(volumeId);
  }

  function setStoryFocus(storyUid, volumeId) {
    selectedStoryUid = storyUid;
    selectedVolumeId = volumeId;
    selectedSubstoryUid = "";
    expandedVolumes.add(volumeId);
    expandedStories.add(storyUid);
  }

  function setSubstoryFocus(substoryUid, storyUid, volumeId) {
    selectedSubstoryUid = substoryUid;
    selectedStoryUid = storyUid;
    selectedVolumeId = volumeId;
    expandedVolumes.add(volumeId);
    expandedStories.add(storyUid);
  }

  function toggleVolumeSelection(volumeId) {
    const volume = findVolume(volumeId);
    if (!volume) return;
    const nextChecked = volumeCheckState(volume) !== "checked";
    for (const story of volume.stories || []) {
      if (nextChecked) selectedStoryUids.add(story.story_uid);
      else selectedStoryUids.delete(story.story_uid);
    }
    setVolumeFocus(volumeId);
    if (!nextChecked && selectedStoryUid && !selectedStoryUids.has(selectedStoryUid)) {
      selectedStoryUid = "";
      selectedSubstoryUid = "";
    }
  }

  function toggleStorySelection(storyUid, volumeId) {
    if (selectedStoryUids.has(storyUid)) selectedStoryUids.delete(storyUid);
    else selectedStoryUids.add(storyUid);
    setStoryFocus(storyUid, volumeId);
  }

  function toggleSubstorySelection(substoryUid, storyUid, volumeId) {
    if (selectedStoryUids.has(storyUid)) selectedStoryUids.delete(storyUid);
    else selectedStoryUids.add(storyUid);
    setSubstoryFocus(substoryUid, storyUid, volumeId);
  }

  function renderTree() {
    ensureDefaultSelection();
    const root = el("chapter-tree");
    if (!root) return;

    if (!outline.volumes.length) {
      root.innerHTML = `
        <div class="tree-empty">
          <strong>等待素材进入</strong>
          <p>提取并清洗完成后，这里会生成卷 / 故事 / 片段三级目录树。</p>
        </div>`;
      return;
    }

    root.innerHTML = outline.volumes.map((volume) => {
      const volumeFocused = selectedVolumeId === volume.partition_id;
      const volumeExpanded = expandedVolumes.has(volume.partition_id);
      const volumeState = volumeCheckState(volume);

      const storiesHtml = (volume.stories || []).map((story) => {
        const storyFocused = selectedStoryUid === story.story_uid;
        const storyExpanded = expandedStories.has(story.story_uid);
        const storyChecked = isStoryChecked(story);
        const processedEpisode = processedEpisodeMap[story.story_uid];
        const hasChildren = Boolean((story.substories || []).length);
        const substoriesHtml = (story.substories || []).map((substory) => {
          const subFocused = selectedSubstoryUid === substory.substory_uid;
          return `
            <div class="tree-group">
              <div class="tree-node tree-substory ${subFocused ? "selected" : ""}">
                <span class="tree-spacer" aria-hidden="true"></span>
                <button
                  class="tree-check ${storyChecked ? "checked" : ""}"
                  type="button"
                  data-toggle-substory-check="${esc(substory.substory_uid)}"
                  data-parent-story="${esc(story.story_uid)}"
                  data-parent-volume="${esc(volume.partition_id)}"
                  aria-label="选择片段"></button>
                <button
                  class="tree-body"
                  type="button"
                  data-focus-substory="${esc(substory.substory_uid)}"
                  data-parent-story="${esc(story.story_uid)}"
                  data-parent-volume="${esc(volume.partition_id)}">
                  <span class="tree-label">
                    <strong>${esc(substory.label || substory.chunk_id || "片段")}</strong>
                    <small>${esc(substory.chunk_id || "")}</small>
                  </span>
                </button>
              </div>
            </div>`;
        }).join("");

        return `
          <div class="tree-group">
            <div class="tree-node tree-story ${storyFocused ? "selected" : ""}">
              ${
                hasChildren
                  ? `<button
                      class="tree-toggle"
                      type="button"
                      data-toggle-story="${esc(story.story_uid)}"
                      aria-label="${storyExpanded ? "收起故事" : "展开故事"}">
                      <span class="tree-chevron ${storyExpanded ? "expanded" : ""}"></span>
                    </button>`
                  : `<span class="tree-spacer" aria-hidden="true"></span>`
              }
              <button
                class="tree-check ${storyChecked ? "checked" : ""}"
                type="button"
                data-toggle-story-check="${esc(story.story_uid)}"
                data-parent-volume="${esc(volume.partition_id)}"
                aria-label="选择故事"></button>
              <button
                class="tree-body"
                type="button"
                data-focus-story="${esc(story.story_uid)}"
                data-parent-volume="${esc(volume.partition_id)}">
                <span class="tree-label">
                  <strong>
                    ${esc(story.label || story.story_uid)}
                    ${processedEpisode ? `<em class="story-done">已处理 · ${esc(processedEpisode)}</em>` : ""}
                  </strong>
                  <small>${esc(`${story.chunk_count || 0} 段`)}</small>
                </span>
              </button>
            </div>
            ${hasChildren && storyExpanded ? `<div class="tree-children">${substoriesHtml}</div>` : ""}
          </div>`;
      }).join("");

      return `
        <div class="tree-group">
          <div class="tree-node ${volumeFocused ? "selected" : ""}">
            <button
              class="tree-toggle"
              type="button"
              data-toggle-volume="${esc(volume.partition_id)}"
              aria-label="${volumeExpanded ? "收起卷" : "展开卷"}">
              <span class="tree-chevron ${volumeExpanded ? "expanded" : ""}"></span>
            </button>
            <button
              class="tree-check ${volumeState === "checked" ? "checked" : ""} ${volumeState === "partial" ? "partial" : ""}"
              type="button"
              data-toggle-volume-check="${esc(volume.partition_id)}"
              aria-label="选择卷"></button>
            <button
              class="tree-body"
              type="button"
              data-focus-volume="${esc(volume.partition_id)}">
              <span class="tree-label">
                <strong>${esc(volume.label || volume.partition_id)}</strong>
                <small>${esc(`${volume.chunk_count || 0} 段`)}</small>
              </span>
            </button>
          </div>
          ${volumeExpanded ? `<div class="tree-children">${storiesHtml}</div>` : ""}
        </div>`;
    }).join("");

    root.querySelectorAll("[data-toggle-volume]").forEach((node) => {
      node.addEventListener("click", () => {
        toggleVolumeExpanded(node.dataset.toggleVolume || "");
        renderTree();
      });
    });

    root.querySelectorAll("[data-toggle-story]").forEach((node) => {
      node.addEventListener("click", () => {
        toggleStoryExpanded(node.dataset.toggleStory || "");
        renderTree();
      });
    });

    root.querySelectorAll("[data-toggle-volume-check]").forEach((node) => {
      node.addEventListener("click", () => {
        toggleVolumeSelection(node.dataset.toggleVolumeCheck || "");
        renderTree();
        renderPreview();
        renderStatus();
      });
    });

    root.querySelectorAll("[data-toggle-story-check]").forEach((node) => {
      node.addEventListener("click", () => {
        toggleStorySelection(node.dataset.toggleStoryCheck || "", node.dataset.parentVolume || "");
        renderTree();
        renderPreview();
        renderStatus();
      });
    });

    root.querySelectorAll("[data-toggle-substory-check]").forEach((node) => {
      node.addEventListener("click", () => {
        toggleSubstorySelection(
          node.dataset.toggleSubstoryCheck || "",
          node.dataset.parentStory || "",
          node.dataset.parentVolume || ""
        );
        renderTree();
        renderPreview();
        renderStatus();
      });
    });

    root.querySelectorAll("[data-focus-volume]").forEach((node) => {
      node.addEventListener("click", () => {
        const volumeId = node.dataset.focusVolume || "";
        setVolumeFocus(volumeId);
        const volume = findVolume(volumeId);
        const firstStory = (volume?.stories || [])[0];
        if (firstStory) setStoryFocus(firstStory.story_uid, volumeId);
        renderTree();
        renderPreview();
        renderStatus();
      });
    });

    root.querySelectorAll("[data-focus-story]").forEach((node) => {
      node.addEventListener("click", () => {
        setStoryFocus(node.dataset.focusStory || "", node.dataset.parentVolume || "");
        renderTree();
        renderPreview();
        renderStatus();
      });
    });

    root.querySelectorAll("[data-focus-substory]").forEach((node) => {
      node.addEventListener("click", () => {
        setSubstoryFocus(
          node.dataset.focusSubstory || "",
          node.dataset.parentStory || "",
          node.dataset.parentVolume || ""
        );
        renderTree();
        renderPreview();
        renderStatus();
      });
    });
  }

  function renderPreview() {
    const titleNode = el("preview-title");
    const metaNode = el("preview-meta");
    const countNode = el("preview-count");
    const contentNode = el("preview-content");
    if (!titleNode || !metaNode || !countNode || !contentNode) return;

    const storyState = currentStoryState();
    if (!storyState) {
      titleNode.textContent = "请先在左侧选择故事";
      metaNode.textContent = "-";
      countNode.textContent = "0 段文本";
      contentNode.innerHTML = `<div class="preview-empty">选中一个故事后，这里会显示正文并支持可编辑校对。</div>`;
      return;
    }

    const { volume, story } = storyState;
    const partition = (rawSourceData.source_partitions || []).find((item) => item.partition_id === volume.partition_id);
    const selectedChunkIds = new Set(story.chunk_ids || []);
    let chunks = (partition?.text_chunks || []).filter((chunk) => selectedChunkIds.has(chunk.chunk_id));
    if (selectedSubstoryUid) {
      const substory = (story.substories || []).find((item) => item.substory_uid === selectedSubstoryUid);
      if (substory) {
        chunks = chunks.filter((chunk) => chunk.chunk_id === substory.chunk_id);
      }
    }

    titleNode.textContent = story.label || "原文预览";
    metaNode.textContent = volume.label || volume.partition_id;
    countNode.textContent = `${chunks.length} 段文本`;

    if (!chunks.length) {
      contentNode.innerHTML = `<div class="preview-empty">这个故事当前没有可显示的正文片段。</div>`;
      return;
    }

    contentNode.innerHTML = chunks.map((chunk) => `
      <section class="text-fragment">
        <header>
          <span>${esc(chunk.chapter_label || story.label || chunk.chunk_id || "")}</span>
          <span>${esc(chunk.chunk_id || "")}</span>
        </header>
        <textarea class="proofread-editor" data-chunk-id="${esc(chunk.chunk_id || "")}">${escTextarea(chunk.text || "")}</textarea>
      </section>`).join("");

    contentNode.querySelectorAll("[data-chunk-id]").forEach((node) => {
      node.addEventListener("input", (event) => {
        const chunkId = event.currentTarget.dataset.chunkId || "";
        const nextText = event.currentTarget.value;
        for (const partitionItem of rawSourceData.source_partitions || []) {
          const chunk = (partitionItem.text_chunks || []).find((item) => item.chunk_id === chunkId);
          if (chunk) {
            chunk.text = nextText;
            break;
          }
        }
      });
    });
  }

  function renderStatus() {
    const statusTitle = el("status-title");
    const statusBody = el("status-body");
    const confirmButton = el("confirm-next-button");
    const sourceStatus = el("source-status");
    if (!statusTitle || !statusBody || !confirmButton || !sourceStatus) return;

    const selectedCount = selectedStoryUids.size;
    const ready = stage1Ready();
    sourceStatus.textContent = ready ? "可进入下一步" : "前置资产未就绪";
    sourceStatus.classList.toggle("ready", ready);
    sourceStatus.classList.toggle("running", !ready && Boolean((dashboard.job || {}).status === "running"));

    if (!ready) {
      statusTitle.textContent = "前置资产未就绪";
      statusBody.textContent = "只有 raw_source.json 包含有效正文并成功解析出真实故事目录后，才能进入导演阶段。";
      confirmButton.disabled = true;
      return;
    }

    if (!selectedCount) {
      statusTitle.textContent = "请至少勾选一个具体故事";
      statusBody.textContent = "确认后会把所选故事推进到 Director_Engine，并记录当前书籍的处理进度。";
      confirmButton.disabled = true;
      return;
    }

    statusTitle.textContent =
      selectedCount === 1
        ? "已勾选 1 个故事，可以推进到导演引擎"
        : `已勾选 ${selectedCount} 个故事，可以批量推进`;
    statusBody.textContent = `当前书籍已处理 ${processedStorySet.size}/${outline.story_count || 0} 个故事。`;
    confirmButton.disabled = false;
  }

  async function extractAndClean() {
    const controls = readControls();
    if (!controls.source_uri && !controls.source_keywords) {
      alert("请先输入 URL 或书名 / 关键词。");
      return;
    }

    const extractButton = el("extract-button");
    const status = el("upload-status");
    if (extractButton) {
      extractButton.disabled = true;
      extractButton.textContent = "处理中...";
    }
    if (status) status.textContent = "正在提取并清洗，请稍候...";

    try {
      await fetchJson("/api/source/extract", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(readControls()),
      });
      window.location.reload();
    } catch (error) {
      if (status) status.textContent = `采集失败：${error.message}`;
      alert(`采集失败：${error.message}`);
    } finally {
      if (extractButton) {
        extractButton.disabled = false;
        extractButton.textContent = "提取并清洗";
      }
    }
  }

  async function uploadSelectedFile(file) {
    if (!file) return;
    const status = el("upload-status");
    if (status) status.textContent = `正在上传 ${file.name}...`;

    const formData = new FormData();
    formData.append("project_id", pageData.project_id || "default");
    formData.append("episode_id", pageData.episode_id || "EP_01");
    formData.append("run_id", pageData.run_id || "web_ui");
    formData.append("file", file);

    try {
      await fetchJson("/api/source/upload", {
        method: "POST",
        body: formData,
      });
      window.location.reload();
    } catch (error) {
      if (status) status.textContent = `上传失败：${error.message}`;
      alert(`上传失败：${error.message}`);
    }
  }

  function bindFileTray() {
    const dropzone = el("file-dropzone");
    const fileInput = el("file-input");
    const pickButton = el("pick-file-button");
    if (!dropzone || !fileInput || !pickButton) return;

    const openPicker = () => fileInput.click();
    dropzone.addEventListener("click", openPicker);
    dropzone.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        openPicker();
      }
    });
    pickButton.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      openPicker();
    });
    fileInput.addEventListener("change", (event) => {
      const file = (event.target.files || [])[0];
      if (file) uploadSelectedFile(file);
      fileInput.value = "";
    });

    ["dragenter", "dragover"].forEach((eventName) => {
      dropzone.addEventListener(eventName, (event) => {
        event.preventDefault();
        dropzone.classList.add("dragover");
      });
    });
    ["dragleave", "dragend", "drop"].forEach((eventName) => {
      dropzone.addEventListener(eventName, (event) => {
        event.preventDefault();
        dropzone.classList.remove("dragover");
      });
    });
    dropzone.addEventListener("drop", (event) => {
      const file = event.dataTransfer?.files?.[0];
      if (file) uploadSelectedFile(file);
    });
  }

  async function saveProofread() {
    if (!rawSourceData.source_partitions || !rawSourceData.source_partitions.length) {
      alert("当前没有可保存的正文内容。");
      return;
    }

    try {
      await fetchJson("/api/source/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          project_id: pageData.project_id || "default",
          episode_id: pageData.episode_id || "EP_01",
          run_id: pageData.run_id || "web_ui",
          source_partitions: rawSourceData.source_partitions,
        }),
      });
      window.location.reload();
    } catch (error) {
      alert(`保存失败：${error.message}`);
    }
  }

  async function confirmNextStep() {
    if (!stage1Ready()) {
      alert("上一阶段资产尚未就绪，请先完成采集、清洗和目录确认。");
      return;
    }
    if (!selectedStoryUids.size) {
      alert("请先勾选至少一个故事。");
      return;
    }

    const isBatch = selectedStoryUids.size > 1;
    try {
      await fetchJson(isBatch ? "/api/source/confirm-batch" : "/api/source/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          project_id: pageData.project_id || "default",
          episode_id: pageData.episode_id || "EP_01",
          run_id: pageData.run_id || "web_ui",
          auto_start_next: true,
          selected_story_uid: isBatch ? undefined : Array.from(selectedStoryUids)[0],
          selected_story_uids: Array.from(selectedStoryUids),
        }),
      });
      window.location.href = stageUrls.Director_Engine || "/";
    } catch (error) {
      alert(`确认失败：${error.message}`);
    }
  }

  async function resetSource() {
    if (!window.confirm("确定要擦除当前采集结果吗？")) return;
    if (!window.confirm("二次确认：这会删除 Stage 1 结果并清空后续阶段产物，继续吗？")) return;

    try {
      await fetchJson("/api/source/reset", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          project_id: pageData.project_id || "default",
          episode_id: pageData.episode_id || "EP_01",
          run_id: pageData.run_id || "web_ui",
          confirmed: true,
        }),
      });
      window.location.reload();
    } catch (error) {
      alert(`重置失败：${error.message}`);
    }
  }

  function bindGlobalButtons() {
    el("extract-button")?.addEventListener("click", extractAndClean);
    el("save-proofread-button")?.addEventListener("click", saveProofread);
    el("reload-button")?.addEventListener("click", () => window.location.reload());
    el("confirm-next-button")?.addEventListener("click", confirmNextStep);
    el("reset-button")?.addEventListener("click", resetSource);
    el("source-uri")?.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        extractAndClean();
      }
    });
  }

  function init() {
    renderTree();
    renderPreview();
    renderStatus();
    bindFileTray();
    bindGlobalButtons();
  }

  document.addEventListener("DOMContentLoaded", init);
})();
