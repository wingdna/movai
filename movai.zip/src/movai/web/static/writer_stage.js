(function () {
  const pageData = window.MOVAI_PAGE_DATA || {};
  const dashboard = pageData.dashboard || {};
  const documents = dashboard.documents || {};
  const stageUrls = pageData.stage_urls || {};

  function el(id) {
    return document.getElementById(id);
  }

  function esc(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll("\"", "&quot;")
      .replaceAll("'", "&#39;");
  }

  function pretty(value) {
    return JSON.stringify(value || {}, null, 2);
  }

  function hasChinese(value) {
    return /[\u4e00-\u9fff]/.test(String(value || ""));
  }

  async function fetchJson(url, options = {}) {
    const response = await fetch(url, options);
    let payload = {};
    try {
      payload = await response.json();
    } catch (_error) {
      payload = {};
    }
    if (!response.ok) {
      throw new Error(payload.detail || payload.message || response.statusText || "Request failed");
    }
    return payload;
  }

  function setToggleState(prefix, rawVisible) {
    const toggleButton = el(`${prefix}-toggle`);
    const treePanel = el(`${prefix}-tree`);
    const rawPanel = el(`${prefix}-raw`);
    if (!toggleButton || !treePanel || !rawPanel) return;
    rawPanel.hidden = !rawVisible;
    treePanel.hidden = rawVisible;
    toggleButton.textContent = rawVisible ? "切换到卡片视图" : "切换到 JSON 原文";
  }

  function entityLabel(projectBible, entityId) {
    const entity = projectBible?.entities?.[entityId];
    return entity?.name || entityId;
  }

  function renderSceneBlocks(masterScript, projectBible) {
    const scenes = masterScript?.scenes || [];
    if (!scenes.length) return `<div class="director-empty">当前没有分镜资产。</div>`;

    return scenes.map((scene, index) => {
      const dialogue = (scene.dialogue || []).map((line) => {
        const name = line.character_id ? entityLabel(projectBible, line.character_id) : "旁白";
        return `<div class="director-kv"><span>${esc(name)}</span><strong>${esc(line.text || "")}</strong></div>`;
      }).join("");
      const entityTags = (scene.visual_render?.entity_ids || []).map((entityId) => esc(entityLabel(projectBible, entityId)));
      const promptValue = scene.visual_render?.base_prompt || "";
      const promptLabel = hasChinese(promptValue) ? promptValue : "英文视觉提示词已生成";
      return `
        <section class="director-tree__block">
          <header class="director-tree__block-head">
            <h4>${esc(scene.scene_id || `场景 ${index + 1}`)}</h4>
            <span>${esc(scene.beat_id || "")}</span>
          </header>
          <div class="director-tree__kv">
            <div class="director-kv"><span>序号</span><strong>${esc(scene.sequence_no ?? "")}</strong></div>
            <div class="director-kv"><span>摘要</span><strong>${esc(scene.scene_summary || "")}</strong></div>
            <div class="director-kv"><span>动作</span><strong>${esc(scene.action_description || "")}</strong></div>
            <div class="director-kv"><span>旁白</span><strong>${esc(scene.narration_text || "")}</strong></div>
            <div class="director-kv"><span>镜头</span><strong>${esc(scene.camera_move || "")}</strong></div>
            <div class="director-kv"><span>时长</span><strong>${esc(scene.duration_ms ? `${scene.duration_ms} ms` : "")}</strong></div>
            ${dialogue}
            <div class="director-kv"><span>视觉提示</span><strong>${esc(promptLabel)}</strong></div>
          </div>
          <div class="director-tree__list">
            ${entityTags.map((tag) => `<div class="director-tag">${tag}</div>`).join("")}
          </div>
        </section>`;
    }).join("");
  }

  function renderStateLedger(ledger, projectBible) {
    if (!ledger) return `<div class="director-empty">当前没有状态台账。</div>`;
    const entityStates = Object.entries(ledger.entity_states || {});
    const items = [
      { label: "当前时间", value: ledger.current_time_ms ? `${ledger.current_time_ms} ms` : "" },
      { label: "当前场景", value: ledger.active_scene || "" },
      { label: "上一节拍", value: ledger.last_completed_beat || "" },
      { label: "跨集继承", value: ledger.inherited_from_episode_id || "" },
      { label: "承接摘要", value: ledger.carry_over_summary || "" },
    ].filter((item) => item.value);

    const entityBlocks = entityStates.map(([entityId, state]) => `
      <section class="director-tree__block">
        <header class="director-tree__block-head">
          <h4>${esc(entityLabel(projectBible, entityId))}</h4>
          <span>${esc(entityId)}</span>
        </header>
        <div class="director-tree__kv">
          <div class="director-kv"><span>位置</span><strong>${esc(state.location || "")}</strong></div>
          <div class="director-kv"><span>姿态</span><strong>${esc(state.posture || "")}</strong></div>
          <div class="director-kv"><span>生命</span><strong>${esc(state.health_level ?? "")}</strong></div>
          <div class="director-kv"><span>理智</span><strong>${esc(state.sanity_level ?? "")}</strong></div>
          <div class="director-kv"><span>备注</span><strong>${esc(state.notes || "")}</strong></div>
        </div>
      </section>
    `).join("");

    const environment = ledger.environment_state || {};
    return `
      ${items.length ? `
        <section class="director-tree__block">
          <header class="director-tree__block-head">
            <h4>台账概览</h4>
          </header>
          <div class="director-tree__kv">
            ${items.map((item) => `<div class="director-kv"><span>${esc(item.label)}</span><strong>${esc(item.value)}</strong></div>`).join("")}
          </div>
        </section>` : ""}
      ${entityBlocks}
      <section class="director-tree__block">
        <header class="director-tree__block-head">
          <h4>环境状态</h4>
        </header>
        <div class="director-tree__kv">
          <div class="director-kv"><span>位置</span><strong>${esc(environment.location || "")}</strong></div>
          <div class="director-kv"><span>威胁</span><strong>${esc(environment.threat_level || "")}</strong></div>
          <div class="director-kv"><span>氛围</span><strong>${esc(environment.atmosphere || "")}</strong></div>
        </div>
      </section>`;
  }

  function renderProductionLedger(ledger) {
    if (!ledger) return `<div class="director-empty">当前没有生产台账。</div>`;
    const stages = ledger.scene_statuses || [];
    return `
      <section class="director-tree__block">
        <header class="director-tree__block-head">
          <h4>生产概览</h4>
        </header>
        <div class="director-tree__kv">
          <div class="director-kv"><span>当前阶段</span><strong>${esc(ledger.current_stage || "")}</strong></div>
          <div class="director-kv"><span>活跃场景</span><strong>${esc(ledger.active_scene || "")}</strong></div>
        </div>
      </section>
      ${stages.map((scene) => `
        <section class="director-tree__block">
          <header class="director-tree__block-head">
            <h4>${esc(scene.scene_id || "场景")}</h4>
            <span>${esc(scene.status || "")}</span>
          </header>
          <div class="director-tree__kv">
            <div class="director-kv"><span>更新时间</span><strong>${esc(scene.updated_at || "")}</strong></div>
            <div class="director-kv"><span>备注</span><strong>${esc(scene.notes || "")}</strong></div>
          </div>
        </section>
      `).join("")}`;
  }

  function fillPanels() {
    const projectBible = documents.project_bible || {};
    const masterScript = documents.master_script || {};
    const stateLedger = documents.state_ledger || {};
    const productionLedger = documents.production_ledger || {};

    if (el("writer-master-editor")) el("writer-master-editor").value = pretty(masterScript);
    if (el("writer-state-editor")) el("writer-state-editor").value = pretty(stateLedger);
    if (el("writer-production-editor")) el("writer-production-editor").value = pretty(productionLedger);

    if (el("writer-master-tree")) el("writer-master-tree").innerHTML = renderSceneBlocks(masterScript, projectBible);
    if (el("writer-state-tree")) el("writer-state-tree").innerHTML = renderStateLedger(stateLedger, projectBible);
    if (el("writer-production-tree")) el("writer-production-tree").innerHTML = renderProductionLedger(productionLedger);

    setToggleState("writer-master", false);
    setToggleState("writer-state", false);
    setToggleState("writer-production", false);

    if (el("writer-dock-title")) {
      el("writer-dock-title").textContent = masterScript?.scenes?.length ? "可按场景长卷审核分镜" : "当前没有分镜资产";
    }
    if (el("writer-dock-body")) {
      el("writer-dock-body").textContent = masterScript?.scenes?.length
        ? "需要原文时可切换 JSON，当前默认显示卡片视图。"
        : "如果 Writer 还未生成资产，这里会保持空白，而不是伪造示例内容。";
    }
  }

  async function rerunWriter() {
    try {
      const payload = await fetchJson("/api/run-module", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          project_id: pageData.project_id || "default",
          episode_id: pageData.episode_id || "EP_01",
          run_id: pageData.run_id || "web_ui",
          module_key: "writer-engine",
        }),
      });
      if (payload.job?.job_id) {
        window.location.reload();
        return;
      }
      window.location.reload();
    } catch (error) {
      alert(`启动失败：${error.message}`);
    }
  }

  function bindToggles() {
    el("writer-master-toggle")?.addEventListener("click", () => {
      const rawPanel = el("writer-master-raw");
      setToggleState("writer-master", rawPanel ? rawPanel.hidden : false);
    });
    el("writer-state-toggle")?.addEventListener("click", () => {
      const rawPanel = el("writer-state-raw");
      setToggleState("writer-state", rawPanel ? rawPanel.hidden : false);
    });
    el("writer-production-toggle")?.addEventListener("click", () => {
      const rawPanel = el("writer-production-raw");
      setToggleState("writer-production", rawPanel ? rawPanel.hidden : false);
    });
  }

  function bind() {
    bindToggles();
    el("writer-reload-button")?.addEventListener("click", () => {
      window.location.href = `${window.location.pathname}${window.location.search}${window.location.search ? "&" : "?"}refresh=${Date.now()}`;
    });
    el("writer-run-button")?.addEventListener("click", rerunWriter);
  }

  document.addEventListener("DOMContentLoaded", () => {
    fillPanels();
    bind();
  });
})();
