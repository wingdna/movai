"""
Translation utilities for MOVAI Studio
Provides automatic translation from Chinese to English for director assets
Using SiliconFlow API with DeepSeek model
"""
import os
import re
from typing import Any
import requests


def call_siliconflow_translate(cn_text: str, target_lang: str = "en") -> str:
    """
    Call SiliconFlow API to translate text using DeepSeek model
    
    Args:
        cn_text: Source text (Chinese)
        target_lang: Target language code (default: "en" for English)
        
    Returns:
        Translated text
        
    Raises:
        Exception: If API call fails
    """
    # Get API key from environment variable
    api_key = os.getenv("MOVAI_SILICONFLOW_API_KEY")
    
    if not api_key:
        raise ValueError(
            "SiliconFlow API key not found. "
            "Please set MOVAI_SILICONFLOW_API_KEY in .env file."
        )
    
    # SiliconFlow API endpoint
    url = "https://api.siliconflow.cn/v1/chat/completions"
    
    # Build translation prompt
    system_prompt = (
        "You are a professional translator. "
        "Translate the following text accurately while preserving the original meaning. "
        "Output ONLY the translation, no explanations."
    )
    
    user_prompt = f"Translate this Chinese text to English:\n\n{cn_text}"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": "deepseek-ai/DeepSeek-R1-0528-Qwen3-8",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.3,  # Lower temperature for more consistent translations
        "max_tokens": 2048
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        
        result = response.json()
        
        if "choices" in result and len(result["choices"]) > 0:
            translated_text = result["choices"][0]["message"]["content"].strip()
            return translated_text
        else:
            raise ValueError(f"Unexpected API response format: {result}")
            
    except requests.exceptions.RequestException as e:
        raise Exception(f"SiliconFlow API request failed: {str(e)}")
    except Exception as e:
        raise Exception(f"Translation failed: {str(e)}")


def simple_translate(cn_text: str) -> str:
    """
    Translate Chinese text to English using SiliconFlow API
    
    Args:
        cn_text: Chinese text to translate
        
    Returns:
        English translation
    """
    # Check if text contains Chinese characters
    if re.search(r'[\u4e00-\u9fff]', cn_text):
        try:
            return call_siliconflow_translate(cn_text)
        except Exception as e:
            # Fallback: return original text with error marker
            # This ensures save operation can still proceed
            print(f"Translation warning: {str(e)}")
            return cn_text
    
    # If no Chinese characters, return as-is (may already be English)
    return cn_text


def translate_entity_field(field_name: str, cn_text: str) -> str:
    """
    Translate entity field with context awareness
    
    Args:
        field_name: Field name (e.g., 'visual_prompt_lock', 'core_personality')
        cn_text: Chinese text to translate
        
    Returns:
        English translation
    """
    # For visual prompts, we might want more detailed translation
    if field_name == "visual_prompt_lock":
        # Could use a specialized prompt for visual descriptions
        return simple_translate(cn_text)
    
    return simple_translate(cn_text)


def translate_world_rule(cn_text: str) -> str:
    """
    Translate world rule with context awareness
    
    Args:
        cn_text: Chinese world rule text
        
    Returns:
        English translation
    """
    return simple_translate(cn_text)


def translate_visual_prompt(cn_text: str) -> str:
    """
    Translate visual prompt for AI image generation
    
    Args:
        cn_text: Chinese visual description
        
    Returns:
        English translation optimized for AI image generation
    """
    # Visual prompts may need special handling
    # For now, use standard translation
    return simple_translate(cn_text)
