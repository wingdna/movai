from __future__ import annotations

from .modules import (
    AudioAnchorForgeModule,
    DirectorEngineModule,
    GlobalDistributorModule,
    MasterHubModule,
    RenderEngineModule,
    SourceIngesterModule,
    VisualAssetFoundryModule,
    WriterEngineModule,
)


def build_registry() -> dict[str, object]:
    modules = [
        SourceIngesterModule(),
        DirectorEngineModule(),
        WriterEngineModule(),
        AudioAnchorForgeModule(),
        VisualAssetFoundryModule(),
        RenderEngineModule(),
        GlobalDistributorModule(),
        MasterHubModule(),
    ]
    return {module.spec.key: module for module in modules}
