from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from schemas import ExecutionMode, ModuleName, ModuleReport, ModuleStatus

from .context import ModuleContext
from .io_utils import ensure_directory, write_payload


@dataclass(frozen=True, slots=True)
class ModuleSpec:
    key: str
    module_name: ModuleName
    description: str
    default_output_subdir: str


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    report_path: Path
    output_files: list[Path]
    template_files: list[Path]


class ScaffoldModule:
    spec: ModuleSpec

    def __init__(self) -> None:
        self._last_retry_count = 0

    def build_template_payloads(self, ctx: ModuleContext) -> dict[str, Any]:
        return {}

    def build_warnings(self) -> list[str]:
        return []

    def get_retry_count(self) -> int:
        return self._last_retry_count

    def resolve_output_dir(self, ctx: ModuleContext) -> Path:
        if ctx.output_dir is not None:
            return ctx.output_dir
        return ctx.workspace / "data" / "staged" / ctx.episode_id / self.spec.default_output_subdir

    def report_file_name(self, ctx: ModuleContext) -> str:
        return f"{self.spec.key}_{ctx.episode_id}_{ctx.run_id}_report.json"

    def run(self, ctx: ModuleContext) -> ExecutionResult:
        self._last_retry_count = 0
        started_at = datetime.now(timezone.utc)
        output_dir = self.resolve_output_dir(ctx)
        reports_dir = ctx.resolved_reports_dir()
        output_files: list[Path] = []
        template_files: list[Path] = []

        if not ctx.dry_run:
            ensure_directory(output_dir)
            ensure_directory(reports_dir)

        template_payloads = self.build_template_payloads(ctx) if ctx.emit_templates and ctx.dry_run else {}
        if ctx.emit_templates:
            for file_name, payload in template_payloads.items():
                file_path = output_dir / file_name
                template_files.append(file_path)
                if not ctx.dry_run:
                    write_payload(file_path, payload, overwrite=ctx.force)

        for file_name, payload in self.build_mock_outputs(ctx).items():
            file_path = output_dir / file_name
            output_files.append(file_path)
            if not ctx.dry_run:
                write_payload(file_path, payload, overwrite=ctx.force)

        finished_at = datetime.now(timezone.utc)
        report = ModuleReport(
            project_id=ctx.project_id,
            episode_id=ctx.episode_id,
            run_id=ctx.run_id,
            module_name=self.spec.module_name,
            status=ModuleStatus.SUCCESS,
            started_at=started_at,
            finished_at=finished_at,
            retry_count=self.get_retry_count(),
            warnings=self.build_warnings(),
            output_files=[str(path) for path in [*template_files, *output_files]],
            execution_mode=ctx.execution_mode,
        )

        report_path = reports_dir / self.report_file_name(ctx)
        if not ctx.dry_run:
            write_payload(report_path, report, overwrite=ctx.force)

        return ExecutionResult(report_path=report_path, output_files=output_files, template_files=template_files)
