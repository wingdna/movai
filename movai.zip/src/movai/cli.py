from __future__ import annotations

import argparse
from pathlib import Path

from schemas import ExecutionMode

from .config import load_env_file
from .context import ModuleContext
from .registry import build_registry


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="movai", description="MOVAI scaffold CLI.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("list-modules", help="List available module skeletons.")

    run_parser = subparsers.add_parser("run", help="Run a scaffolded module entry point.")
    run_parser.add_argument("module", help="Module key, for example: source-ingester")
    run_parser.add_argument("--project-id", default="demo_project")
    run_parser.add_argument("--episode-id", default="EP_01")
    run_parser.add_argument("--run-id", default="run_001")
    run_parser.add_argument("--workspace", default=".")
    run_parser.add_argument("--source-uri")
    run_parser.add_argument("--source-type-hint", choices=["web_url", "local_txt", "local_epub"])
    run_parser.add_argument("--chapter-range")
    run_parser.add_argument("--source-keywords")
    run_parser.add_argument("--style-label")
    run_parser.add_argument("--visual-lut")
    run_parser.add_argument("--narrator-voice-id")
    run_parser.add_argument("--output-dir")
    run_parser.add_argument("--reports-dir")
    run_parser.add_argument("--execution-mode", choices=[mode.value for mode in ExecutionMode], default=ExecutionMode.LOCAL.value)
    run_parser.add_argument("--emit-templates", action="store_true")
    run_parser.add_argument("--force", action="store_true")
    run_parser.add_argument("--dry-run", action="store_true")

    return parser


def main(argv: list[str] | None = None) -> int:
    load_env_file()
    parser = build_parser()
    args = parser.parse_args(argv)
    registry = build_registry()

    if args.command == "list-modules":
        for key, module in registry.items():
            print(f"{key}: {module.spec.description}")
        return 0

    module = registry.get(args.module)
    if module is None:
        parser.error(f"Unknown module: {args.module}")

    ctx = ModuleContext(
        project_id=args.project_id,
        episode_id=args.episode_id,
        run_id=args.run_id,
        workspace=Path(args.workspace).resolve(),
        execution_mode=ExecutionMode(args.execution_mode),
        source_uri=args.source_uri,
        source_type_hint=args.source_type_hint,
        chapter_range=args.chapter_range,
        source_keywords=args.source_keywords,
        style_label=args.style_label,
        visual_lut=args.visual_lut,
        narrator_voice_id=args.narrator_voice_id,
        output_dir=Path(args.output_dir).resolve() if args.output_dir else None,
        reports_dir=Path(args.reports_dir).resolve() if args.reports_dir else None,
        emit_templates=args.emit_templates,
        force=args.force,
        dry_run=args.dry_run,
    )
    result = module.run(ctx)

    print(f"Module: {module.spec.key}")
    print(f"Report: {result.report_path}")
    if result.template_files:
        print("Templates:")
        for template_file in result.template_files:
            print(f"  - {template_file}")
    if result.output_files:
        print("Outputs:")
        for output_file in result.output_files:
            print(f"  - {output_file}")
    elif not result.template_files:
        print("Outputs: none")
    return 0
