from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel


def ensure_directory(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def payload_to_data(payload: BaseModel | dict[str, Any] | list[Any] | str | bytes) -> BaseModel | dict[str, Any] | list[Any] | str | bytes:
    return payload


def write_payload(path: Path, payload: BaseModel | dict[str, Any] | list[Any] | str | bytes, overwrite: bool = False) -> None:
    if path.exists() and not overwrite:
        raise FileExistsError(f"Refusing to overwrite existing file: {path}")

    ensure_directory(path.parent)

    if isinstance(payload, BaseModel):
        data = payload.model_dump(mode="json", by_alias=True)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return

    if isinstance(payload, (dict, list)):
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return

    if isinstance(payload, bytes):
        path.write_bytes(payload)
        return

    path.write_text(payload, encoding="utf-8")


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def read_model(path: Path, model_type: type[BaseModel]) -> BaseModel:
    return model_type.model_validate_json(path.read_text(encoding="utf-8"))
