@echo off
echo 正在同步修复文件到 F:\scd\movai...

echo 1. 备份原始文件...
copy "F:\scd\movai\src\movai\web\static\source_stage.js" "F:\scd\movai\src\movai\web\static\source_stage.js.backup" >nul 2>&1

echo 2. 读取原始文件并替换 confirmNextStep 函数...
powershell -Command ^
    "(Get-Content 'F:\scd\movai\src\movai\web\static\source_stage.js' -Raw) -replace 'async function confirmNextStep\(\) \{[^}]*\}', (Get-Content 'C:\Users\Administrator\.windsurf\worktrees\movai\movai-9501c3f2\fix_source_stage.js' -Raw).Trim() | Set-Content 'F:\scd\movai\src\movai\web\static\source_stage.js'"

echo 3. 同步完成！
echo.
echo 修复内容：
echo - confirmNextStep 函数现在会直接跳转到导演引擎页面
echo - 不再依赖可能未定义的 stageUrls 变量
echo - 使用实际的 project_id、episode_id、run_id 参数
echo.
echo 请重启 movai-web 服务以应用修复。
pause
