# MOVAI 翻译功能配置指南

## 概述
MOVAI 系统现已集成**硅基流动（SiliconFlow）API**，使用 **DeepSeek-R1-0528-Qwen3-8** 模型实现高质量的中英自动翻译功能。

## 快速开始

### 1. 获取 API Key

#### 步骤 1: 访问硅基流动官网
打开浏览器访问：https://siliconflow.cn/

#### 步骤 2: 注册/登录账号
- 新用户需要注册账号
- 已有账号直接登录

#### 步骤 3: 创建 API Key
1. 登录后进入**控制台**
2. 找到 **API Keys** 或 **密钥管理** 页面
3. 点击**创建新的 API Key**
4. 复制生成的 API Key（格式类似：`sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`）

### 2. 配置环境变量

#### Windows 系统
编辑项目根目录下的 `.env` 文件（如不存在则创建）：

```bash
# 硅基流动 API 配置
MOVAI_SILICONFLOW_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# 可选：指定翻译服务类型
MOVAI_TRANSLATION_SERVICE=siliconflow
```

保存文件后重启 MOVAI Web 服务使配置生效。

### 3. 验证配置

启动 MOVAI Web 服务：
```bash
movai-web
```

访问导演引擎页面，修改任意中文内容并保存，系统应自动调用翻译 API。

## 使用场景

### 场景 1: 角色视觉锁定词翻译

**中文输入：**
```
一个穿着蓝色长袍的年轻道士，手持拂尘，站在云雾缭绕的山巅，眼神深邃而坚定
```

**自动翻译结果：**
```
A young Taoist priest wearing a blue robe, holding a whisk, standing on a misty mountain peak, with deep and determined eyes
```

### 场景 2: 节拍分镜描述翻译

**中文输入：**
```
镜头从远山缓缓推进，穿过云层，聚焦在主角身上。夕阳的余晖洒在他的脸上，营造出一种悲壮的氛围
```

**自动翻译结果：**
```
The camera slowly pushes in from distant mountains, passing through clouds, focusing on the protagonist. The afterglow of the setting sun falls on his face, creating a tragic atmosphere
```

### 场景 3: 世界规则翻译

**中文输入：**
```
在这个世界中，灵力是万物运行的基础。修士通过吸收天地灵气来提升修为
```

**自动翻译结果：**
```
In this world, spiritual power is the foundation of all operations. Cultivators improve their cultivation by absorbing the spiritual energy of heaven and earth
```

## 翻译质量优化

### 温度参数调整

在 `src/movai/web/translations.py` 中可调整温度参数：

```python
payload = {
    "model": "deepseek-ai/DeepSeek-R1-0528-Qwen3-8",
    "temperature": 0.3,  # 降低可提高一致性，升高可增加创造性
    # ...
}
```

- **temperature=0.1-0.3**: 翻译更保守、一致性强（推荐）
- **temperature=0.5-0.7**: 翻译更灵活、可能有变化
- **temperature>0.8**: 不推荐用于翻译任务

### System Prompt 优化

可根据不同场景定制 system prompt：

```python
# 文学翻译风格
system_prompt = (
    "You are a professional literary translator specializing in Chinese fantasy novels. "
    "Translate with high accuracy while preserving the artistic style and cultural nuances. "
    "Output ONLY the translation."
)

# 技术文档风格
system_prompt = (
    "You are a technical translator. "
    "Provide precise and concise translations. "
    "Use standard terminology. "
    "Output ONLY the translation."
)
```

## 故障排查

### 问题 1: 提示 "API key not found"

**原因：** 未配置环境变量或配置未生效

**解决方案：**
1. 检查 `.env` 文件是否存在
2. 确认 `MOVAI_SILICONFLOW_API_KEY` 拼写正确
3. 重启 MOVAI Web 服务
4. 检查环境变量是否正确加载：
   ```python
   import os
   print(os.getenv("MOVAI_SILICONFLOW_API_KEY"))
   ```

### 问题 2: 翻译失败但保存成功

**现象：** 英文字段仍为中文，但保存操作完成

**原因：** API 调用失败触发降级策略

**解决方案：**
1. 检查网络连接是否正常
2. 验证 API Key 是否有效
3. 查看控制台日志中的具体错误信息
4. 确认能够访问 https://api.siliconflow.cn/

### 问题 3: 翻译结果不理想

**可能原因：**
- Model 参数不适合当前文本类型
- Temperature 设置过高或过低
- System Prompt 不够精准

**解决方案：**
1. 尝试调整 temperature 参数（建议范围 0.2-0.5）
2. 优化 system prompt 以匹配文本类型
3. 如问题持续，考虑更换其他 SiliconFlow 模型

### 问题 4: 翻译速度较慢

**可能原因：**
- 网络延迟
- API 服务端处理慢
- 文本过长

**解决方案：**
1. 检查网络连接
2. 将长文本拆分为多个短文本
3. 调整 timeout 参数（默认 30 秒）
4. 考虑批量翻译以减少总请求次数

## 成本与限制

### API 费用
硅基流动 API 按 token 计费，具体价格请参考官网：
- 输入 token：¥X.XX / 1K tokens
- 输出 token：¥X.XX / 1K tokens

### 速率限制
- 免费用户：X 次/分钟
- 付费用户：更高限额

请关注硅基流动官网的最新定价政策。

## 替代方案

如需切换到其他翻译服务，修改 `translations.py`：

### 切换回占位模式（开发测试用）
```python
def simple_translate(cn_text: str) -> str:
    if re.search(r'[\u4e00-\u9fff]', cn_text):
        return f"[Translated] {cn_text}"  # 占位符
    return cn_text
```

### 切换到百度翻译
```python
def simple_translate(cn_text: str) -> str:
    return call_baidu_translate(cn_text)  # 需自行实现
```

## 最佳实践

1. **批量编辑** - 集中修改多处内容后统一保存，减少 API 调用次数
2. **人工校对** - 自动翻译后建议人工核对关键描述
3. **术语一致** - 对专有名词建立术语表，确保翻译一致性
4. **分段翻译** - 长文本建议分段以获得更好效果
5. **异常监控** - 定期检查翻译失败日志，及时解决问题

## 技术支持

- 硅基流动官方文档：https://docs.siliconflow.cn/
- DeepSeek 模型介绍：https://siliconflow.cn/models/deepseek
- MOVAI 项目 Issues: 提交问题反馈

## 更新日志

### v1.0.0 (2026-03-25)
- ✅ 首次集成硅基流动 DeepSeek 模型
- ✅ 支持世界观宪法库和节拍骨架的自动翻译
- ✅ 提供完善的错误处理和降级策略
- ✅ 添加详细的配置和使用文档
