# MOVAI - "Phantom Scroll" 2.5D Cinematic Pipeline

## Overview

This repository contains the software planning documents for the "Phantom Scroll" 2.5D cinematic production pipeline. The system is designed as a modular, file-driven workflow for adapting public-domain text into stylized short-form video content.

The pipeline follows three core ideas:

1. Audio duration drives final video duration.
2. Immutable creative anchors are separated from mutable runtime state.
3. Human review gates prevent silent quality drift across long generation runs.

The architecture is intentionally decomposed into independent modules that communicate through local JSON files and media assets. This keeps the system observable, restartable, and suitable for staged implementation.

## Repo Goals

This documentation set is meant to support:

1. Technical planning
2. AI-assisted implementation by module
3. Schema-first backend design
4. Incremental prototyping and recovery-friendly orchestration

## Documents

1. `README.md`
   Project summary, implementation strategy, and engineering principles.
2. `docs/SRS_v1.0.md`
   Formal Software Requirements Specification for the full pipeline.

## System Summary

The system is built from eight loosely coupled modules:

1. `Source_Ingester`
   Collects and cleans source text from web or local files.
2. `Director_Engine`
   Generates project-level world rules, character anchors, and beat sheets.
3. `Writer_Engine`
   Expands beats into structured scenes, narration, dialogue, and production tags.
4. `Audio_Anchor_Forge`
   Produces TTS and sound assets, then computes authoritative timing.
5. `Visual_Asset_Foundry`
   Generates scene images, depth maps, and poster assets.
6. `Render_Engine`
   Converts still images into 2.5D motion and composites final audio/video.
7. `Global_Distributor`
   Produces multilingual deliverables and uploads platform packages.
8. `Master_Hub`
   Orchestrates execution, pause gates, validation, and recovery.

## Engineering Principles

### 1. Schema-first design

Every module input and output should be defined by strict Pydantic models and versioned JSON contracts. This reduces ambiguity and provides a hard boundary against malformed LLM output.

Recommended baseline:

1. Add `schema_version` to every contract.
2. Reject unexpected fields with `extra="forbid"`.
3. Use enums for constrained attributes like mood, threat level, or camera movement.
4. Add `run_id`, `created_at`, and `source_hash` to generated outputs.

### 2. Immutable vs mutable data separation

The system should distinguish between:

1. Immutable assets
   Stored in `project_bible.json`, never modified after approval.
2. Mutable state
   Stored in `state_ledger.json` and updated after every beat or scene.

This prevents model drift from corrupting long-lived identity anchors such as character appearance, world physics, or voice assignments.

### 3. Pointer-based visual composition

Scene records should store `entity_ids` instead of repeating full visual descriptions. Prompt assembly happens in code by reading the locked character descriptors from `project_bible.json`.

This prevents prompt decay and keeps image consistency stable across long productions.

### 4. Idempotent modules

Each module should be safe to rerun. If outputs already exist and hashes match, the module should skip regeneration unless forced.

This is especially important for:

1. Image generation
2. TTS generation
3. Depth map generation
4. Upload and distribution steps

### 5. Review gates as first-class workflow steps

The system must pause at defined milestones so a human operator can inspect:

1. Project bible and beat sheet
2. Script, audio, and visual batch outputs
3. Final Chinese master render before localization

## Recommended Directory Layout

```text
movai/
  README.md
  docs/
    SRS_v1.0.md
  configs/
    style_profiles.yaml
    model_endpoints.yaml
  schemas/
  src/
    source_ingester/
    director_engine/
    writer_engine/
    audio_anchor_forge/
    visual_asset_foundry/
    render_engine/
    global_distributor/
    master_hub/
  data/
    raw/
    staged/
    final/
  artifacts/
    audio/
    visuals/
    posters/
    subtitles/
  ledgers/
    state_ledger.json
    production_ledger.json
  reports/
  tests/
```

## Recommended Build Order

To reduce risk, implementation should proceed in this order:

1. Define schemas and file contracts.
2. Build a minimal `Master_Hub` orchestrator with validation hooks.
3. Implement `Director_Engine -> Writer_Engine -> Audio_Anchor_Forge`.
4. Verify the text-to-audio-to-timeline loop end to end.
5. Add image generation and depth estimation.
6. Add 2.5D rendering and compositing.
7. Add localization and upload automation.

This sequence proves the timing core early, which is the highest-leverage dependency in the pipeline.

## Suggested First Implementation Targets

If development starts immediately, the best first deliverables are:

1. Pydantic schemas for all major contracts
2. A sample `project_bible.json`, `beat_sheet.json`, and `master_script.json`
3. A minimal orchestration CLI
4. A prototype for Module 4 timing backfill

## Schema Package

The repository now includes a first-pass schema package under `schemas/` with:

1. Contract base models
2. Shared enums
3. Core data contracts for source, bible, beats, state, script, timing, manifest, and reports

Import example:

```python
from schemas import ProjectBible, BeatSheet, MasterScript, TimedScript
```

## CLI Scaffold

The repository now also includes a scaffolded runtime package under `src/movai/` and a minimal CLI.

Install locally:

```bash
pip install -e .
```

Or run without installation from the repo root:

```bash
PYTHONPATH=src python -m movai list-modules
PYTHONPATH=src python -m movai run writer-engine --project-id demo_project --run-id run_001 --emit-templates
```

Current CLI capabilities:

1. List available module skeletons
2. Run a module scaffold
3. Emit template JSON contracts into `data/staged/...`
4. Write module reports into `reports/...`

## Current Real Modules

Two modules now contain real business logic:

1. `Source_Ingester`
   Supports local TXT ingestion, basic public-domain web fetching, cleansing, source partitioning, and chunking.
2. `Director_Engine`
   Reads `raw_source.json` and generates a real `project_bible.json` and `beat_sheet.json` using deterministic planning heuristics and style presets.

Example:

```bash
PYTHONPATH=src python -m movai run source-ingester --project-id demo_project --episode-id EP_01 --run-id run_source --source-uri sample_source_en.txt --source-type-hint local_txt
PYTHONPATH=src python -m movai run director-engine --project-id demo_project --episode-id EP_01 --run-id run_director --style-label mockumentary_alien_horror
```

## Web UI

The project also includes a lightweight studio UI for running the first two modules and inspecting outputs.

Start it with:

```bash
pip install -e .
movai-web
```

Then open [http://127.0.0.1:8000](http://127.0.0.1:8000).

## Current Status

The planning baseline and the first Pydantic contract layer are now in place. The next practical step is to build module stubs and validation utilities around these schemas.
