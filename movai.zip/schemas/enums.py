from enum import Enum


class SourceType(str, Enum):
    WEB_URL = "web_url"
    LOCAL_TXT = "local_txt"
    LOCAL_EPUB = "local_epub"


class PartitionType(str, Enum):
    VOLUME = "volume"
    CHAPTER_RANGE = "chapter_range"
    PAGE_RANGE = "page_range"
    SECTION = "section"


class Mood(str, Enum):
    CALM = "Calm"
    TENSION = "Tension"
    HORROR = "Horror"
    ACTION = "Action"


class ThreatLevel(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    CRITICAL = "Critical"


class SceneStatus(str, Enum):
    DRAFT = "draft"
    GENERATED = "generated"
    REVIEWED = "reviewed"
    FINAL = "final"
    FAILED = "failed"


class TrackType(str, Enum):
    NARRATOR = "narrator"
    DIALOGUE = "dialogue"
    SFX = "sfx"
    MUSIC = "music"


class ModuleStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"
    BLOCKED = "blocked"
    AWAITING_REVIEW = "awaiting_review"


class ModuleName(str, Enum):
    SOURCE_INGESTER = "Source_Ingester"
    DIRECTOR_ENGINE = "Director_Engine"
    WRITER_ENGINE = "Writer_Engine"
    AUDIO_ANCHOR_FORGE = "Audio_Anchor_Forge"
    VISUAL_ASSET_FOUNDRY = "Visual_Asset_Foundry"
    RENDER_ENGINE = "Render_Engine"
    GLOBAL_DISTRIBUTOR = "Global_Distributor"
    MASTER_HUB = "Master_Hub"


class CameraMove(str, Enum):
    STATIC = "Static"
    Z_DOLLY_IN_SLOW = "Z_Dolly_In_Slow"
    Z_DOLLY_OUT_SLOW = "Z_Dolly_Out_Slow"
    PAN_LEFT = "Pan_Left"
    PAN_RIGHT = "Pan_Right"
    TILT_UP = "Tilt_Up"
    TILT_DOWN = "Tilt_Down"
    HANDHELD_DRIFT = "Handheld_Drift"


class ExecutionMode(str, Enum):
    LOCAL = "local"
    CLOUD = "cloud"
