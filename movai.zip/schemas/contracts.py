from __future__ import annotations

from datetime import datetime

from pydantic import Field, model_validator

from .base import ContractModel, EpisodeContractModel, StrictModel
from .enums import (
    CameraMove,
    ExecutionMode,
    ModuleName,
    ModuleStatus,
    Mood,
    PartitionType,
    SceneStatus,
    SourceType,
    ThreatLevel,
    TrackType,
)


def _ensure_unique(values: list[str], label: str) -> None:
    duplicates = {value for value in values if values.count(value) > 1}
    if duplicates:
        duplicate_list = ", ".join(sorted(duplicates))
        raise ValueError(f"{label} must be unique. Duplicate values: {duplicate_list}")


class RawTextChunk(StrictModel):
    chunk_id: str = Field(min_length=1)
    order_index: int = Field(ge=0)
    chapter_label: str | None = None
    text: str = Field(min_length=1)


class SourcePartition(StrictModel):
    partition_id: str = Field(min_length=1)
    partition_type: PartitionType
    order_index: int = Field(ge=0)
    label: str | None = None
    page_range: str | None = None
    chapter_range: str | None = None
    text_chunks: list[RawTextChunk] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_chunk_ids(self) -> "SourcePartition":
        _ensure_unique([chunk.chunk_id for chunk in self.text_chunks], "RawTextChunk.chunk_id")
        return self


class RawSource(ContractModel):
    title: str = Field(min_length=1)
    author: str | None = None
    source_type: SourceType
    source_uri: str = Field(min_length=1)
    chapter_range: str | None = None
    source_partitions: list[SourcePartition] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_partition_ids(self) -> "RawSource":
        _ensure_unique([partition.partition_id for partition in self.source_partitions], "SourcePartition.partition_id")
        return self


class StyleMatrix(StrictModel):
    visual_lut: str = Field(min_length=1)
    narrator_voice_id: str = Field(min_length=1)
    style_label: str | None = None
    color_script: str | None = None


class EntityDefinition(StrictModel):
    name: str = Field(min_length=1)
    role: str | None = None
    core_personality: str | None = None
    visual_prompt_lock: str = Field(min_length=1)
    audio_tts_id: str = Field(min_length=1)


class ProjectBible(ContractModel):
    style_matrix: StyleMatrix
    entities: dict[str, EntityDefinition] = Field(min_length=1)
    world_rules: list[str] = Field(default_factory=list)
    glossary: dict[str, str] = Field(default_factory=dict)


class Beat(StrictModel):
    beat_id: str = Field(min_length=1)
    episode_id: str = Field(min_length=1)
    sequence_no: int = Field(ge=1)
    title: str | None = None
    summary: str = Field(min_length=1)
    objective: str = Field(min_length=1)
    mood: Mood
    characters_present: list[str] = Field(default_factory=list)
    estimated_duration_ms: int | None = Field(default=None, ge=0)


class BeatSheet(EpisodeContractModel):
    beats: list[Beat] = Field(min_length=1)
    inherited_from_episode_id: str | None = None

    @model_validator(mode="after")
    def validate_beats(self) -> "BeatSheet":
        _ensure_unique([beat.beat_id for beat in self.beats], "Beat.beat_id")
        _ensure_unique([str(beat.sequence_no) for beat in self.beats], "Beat.sequence_no")
        for beat in self.beats:
            if beat.episode_id != self.episode_id:
                raise ValueError("All beats must match BeatSheet.episode_id.")
        return self


class EntityState(StrictModel):
    health_level: int | None = Field(default=None, ge=0, le=100)
    sanity_level: int | None = Field(default=None, ge=0, le=100)
    location: str | None = None
    posture: str | None = None
    inventory: list[str] = Field(default_factory=list)
    notes: str | None = None
    is_active: bool = True


class EnvironmentState(StrictModel):
    location: str | None = None
    threat_level: ThreatLevel = ThreatLevel.LOW
    atmosphere: str | None = None


class StateLedger(EpisodeContractModel):
    current_time_ms: int = Field(ge=0)
    episode_time_ms: int = Field(ge=0)
    active_scene: str | None = None
    last_completed_beat: str | None = None
    snapshot_id: str | None = None
    inherited_from_episode_id: str | None = None
    carry_over_summary: str | None = None
    entity_states: dict[str, EntityState] = Field(default_factory=dict)
    environment_state: EnvironmentState = Field(default_factory=EnvironmentState)


class DialogueLine(StrictModel):
    character_id: str = Field(min_length=1)
    text: str = Field(min_length=1)
    emotion: Mood | None = None


class AudioTrack(StrictModel):
    type: TrackType
    text: str | None = None
    tags: list[str] = Field(default_factory=list)
    character_id: str | None = None
    voice_id: str | None = None
    file_path: str | None = None

    @model_validator(mode="after")
    def validate_track_payload(self) -> "AudioTrack":
        if self.type in {TrackType.NARRATOR, TrackType.DIALOGUE} and not self.text:
            raise ValueError("Narrator and dialogue tracks require text.")
        if self.type == TrackType.SFX and not self.tags:
            raise ValueError("SFX tracks require at least one tag.")
        return self


class TimedAudioTrack(AudioTrack):
    file_path: str = Field(min_length=1)
    duration_ms: int = Field(ge=0)


class VisualRenderPlan(StrictModel):
    base_prompt: str = Field(min_length=1)
    entity_ids: list[str] = Field(default_factory=list)
    image_path: str | None = None
    depth_path: str | None = None
    poster_candidate: bool = False


class ResolvedVisualRenderPlan(VisualRenderPlan):
    image_path: str = Field(min_length=1)
    depth_path: str = Field(min_length=1)


class SceneScript(StrictModel):
    scene_id: str = Field(min_length=1)
    episode_id: str = Field(min_length=1)
    beat_id: str = Field(min_length=1)
    sequence_no: int = Field(ge=1)
    status: SceneStatus = SceneStatus.DRAFT
    scene_summary: str = Field(min_length=1)
    action_description: str = Field(min_length=1)
    camera_move: CameraMove
    narration_text: str | None = None
    dialogue: list[DialogueLine] = Field(default_factory=list)
    vfx_layers: list[str] = Field(default_factory=list)
    audio_tracks: list[AudioTrack] = Field(default_factory=list)
    visual_render: VisualRenderPlan
    duration_ms: int | None = Field(default=None, ge=0)


class TimedSceneScript(SceneScript):
    status: SceneStatus = SceneStatus.GENERATED
    audio_tracks: list[TimedAudioTrack] = Field(min_length=1)
    visual_render: ResolvedVisualRenderPlan
    duration_ms: int = Field(ge=0)


class MasterScript(EpisodeContractModel):
    scenes: list[SceneScript] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_scenes(self) -> "MasterScript":
        _ensure_unique([scene.scene_id for scene in self.scenes], "SceneScript.scene_id")
        _ensure_unique([str(scene.sequence_no) for scene in self.scenes], "SceneScript.sequence_no")
        for scene in self.scenes:
            if scene.episode_id != self.episode_id:
                raise ValueError("All scenes must match MasterScript.episode_id.")
        return self


class TimedScript(EpisodeContractModel):
    scenes: list[TimedSceneScript] = Field(min_length=1)
    total_duration_ms: int = Field(ge=0)
    execution_mode: ExecutionMode = ExecutionMode.LOCAL

    @model_validator(mode="after")
    def validate_total_duration(self) -> "TimedScript":
        _ensure_unique([scene.scene_id for scene in self.scenes], "TimedSceneScript.scene_id")
        derived_total = sum(scene.duration_ms for scene in self.scenes)
        if self.total_duration_ms != derived_total:
            raise ValueError(
                f"TimedScript.total_duration_ms must equal the sum of scene durations ({derived_total})."
            )
        for scene in self.scenes:
            if scene.episode_id != self.episode_id:
                raise ValueError("All timed scenes must match TimedScript.episode_id.")
        return self


class SceneProgress(StrictModel):
    scene_id: str = Field(min_length=1)
    episode_id: str = Field(min_length=1)
    status: SceneStatus
    updated_at: datetime
    notes: str | None = None


class ProductionLedger(EpisodeContractModel):
    active_scene: str | None = None
    current_stage: ModuleName | None = None
    scene_statuses: list[SceneProgress] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_scene_progress(self) -> "ProductionLedger":
        _ensure_unique([item.scene_id for item in self.scene_statuses], "SceneProgress.scene_id")
        for item in self.scene_statuses:
            if item.episode_id != self.episode_id:
                raise ValueError("All scene progress items must match ProductionLedger.episode_id.")
        return self


class ModuleReport(EpisodeContractModel):
    module_name: ModuleName
    status: ModuleStatus
    started_at: datetime
    finished_at: datetime | None = None
    retry_count: int = Field(default=0, ge=0)
    error_message: str | None = None
    warnings: list[str] = Field(default_factory=list)
    output_files: list[str] = Field(default_factory=list)
    execution_mode: ExecutionMode = ExecutionMode.LOCAL


class StageRecord(StrictModel):
    stage_name: ModuleName
    status: ModuleStatus
    started_at: datetime | None = None
    finished_at: datetime | None = None
    input_files: list[str] = Field(default_factory=list)
    output_files: list[str] = Field(default_factory=list)
    report_path: str | None = None
    error_message: str | None = None
    gate_after: int | None = Field(default=None, ge=1, le=3)


class Manifest(EpisodeContractModel):
    current_stage: ModuleName | None = None
    overall_status: ModuleStatus = ModuleStatus.PENDING
    review_gate_pending: int | None = Field(default=None, ge=1, le=3)
    last_completed_stage: ModuleName | None = None
    execution_mode: ExecutionMode = ExecutionMode.LOCAL
    payload_path: str | None = None
    payload_ready: bool = False
    awaiting_cloud_return: bool = False
    stages: list[StageRecord] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_stage_names(self) -> "Manifest":
        _ensure_unique([stage.stage_name.value for stage in self.stages], "StageRecord.stage_name")
        return self


class RenderPayloadManifest(EpisodeContractModel):
    execution_mode: ExecutionMode = ExecutionMode.CLOUD
    payload_file: str = Field(min_length=1)
    root_dir: str = Field(min_length=1)
    included_files: list[str] = Field(min_length=1)
