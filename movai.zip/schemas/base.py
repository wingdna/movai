from __future__ import annotations

from datetime import datetime, timezone

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        str_strip_whitespace=True,
        use_enum_values=False,
        populate_by_name=True,
    )


class ContractModel(StrictModel):
    schema_version: str = Field(default="2.0", min_length=1)
    project_id: str = Field(min_length=1)
    run_id: str = Field(min_length=1)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    source_hash: str | None = None


class EpisodeContractModel(ContractModel):
    episode_id: str = Field(min_length=1)
