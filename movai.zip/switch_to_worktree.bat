@echo off
echo 正在切换到 worktree 目录并启动 movai-web...
cd /d C:\Users\Administrator\.windsurf\worktrees\movai\movai-9501c3f2
movai-web
pause
