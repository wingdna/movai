// 修复后的 confirmNextStep 函数，替换 source_stage.js 中的版本
async function confirmNextStep() {
    if (!stage1Ready()) {
      alert("上一阶段资产尚未就绪，请先完成采集、清洗和目录确认。");
      return;
    }
    if (!selectedStoryUids.size) {
      alert("请先勾选至少一个故事。");
      return;
    }

    const isBatch = selectedStoryUids.size > 1;
    try {
      await fetchJson(isBatch ? "/api/source/confirm-batch" : "/api/source/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          project_id: pageData.project_id || "default",
          episode_id: pageData.episode_id || "EP_01",
          run_id: pageData.run_id || "web_ui",
          auto_start_next: true,
          selected_story_uid: isBatch ? undefined : Array.from(selectedStoryUids)[0],
          selected_story_uids: Array.from(selectedStoryUids),
        }),
      });
      // 修复：直接跳转到导演引擎页面，而不是依赖 stageUrls
      const projectId = pageData.project_id || "default";
      const episodeId = pageData.episode_id || "EP_01";
      const runId = pageData.run_id || "web_ui";
      window.location.href = `/stage/director-engine?project_id=${projectId}&episode_id=${episodeId}&run_id=${runId}`;
    } catch (error) {
      alert(`确认失败：${error.message}`);
    }
  }
